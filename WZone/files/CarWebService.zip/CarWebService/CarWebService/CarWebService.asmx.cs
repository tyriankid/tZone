﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;

namespace CarWebService
{
    /// <summary>
    /// Service1 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消对下行的注释。
    // [System.Web.Script.Services.ScriptService]
    public class CarWebService : System.Web.Services.WebService
    {
        //TODO:
        //1.增加是否微信调车的的字段，用来区分哪些是移动端或PC端插入的数据
        //2.增加错误日志，记录报错信息
        
        

        SqlHelper db = new SqlHelper();

        [WebMethod(Description = "写入日志信息，参数optuser:执行用户 optname:执行的方法名 optcontent:执行的内容")]
        public void WriteLogInfo(string optuser,string optname,string optcontent)
        {

            string sql = string.Format(@"INSERT INTO dbo.Base_System_Log(systemname , systemcode ,optuser , optname , optcontent  )
                                        VALUES  ('微信调车系统','UsingCarsByPhone','{0}','{1}','{2}')", optuser, optname, optcontent.Replace("'", "“"));
            
            db.ExecuteBySQL(sql);
        
        }



        [WebMethod(Description = "写入调车单信息，0：成功　1：失败")]
        public int WriteUseCarInfo(string appuser,string appdep,string othdep,string outdate,string indate,int usercount,string reason,
            string chargeuser,string chargeusertel,string cartype,string memo,string prjid,string goalcity,int state,int isbd,string appuserpy,string chkuser)
            
        {
            try
            {
                string sql = "";
                sql = string.Format(@"insert into CAR_UseCall(AppUser,AppDep,OthDep,OutDate,InDate,UserCount,Reason,
                                ChargeUser,ChargeUserTel,CarType,Memo,prjid,GoalCity,state,isbd,appuserpy,chkuser,isAPI) 
                                values('{0}','{1}','{2}','{3}','{4}',{5},'{6}','{7}','{8}','{9}','{10}','{11}','{12}',{13},{14},'{15}','{16}',{17})",
                    appuser, appdep, othdep, outdate, indate, usercount, reason, chargeuser, chargeusertel, cartype, memo, prjid, goalcity, state, isbd, appuserpy, chkuser, 1);

                int rtn = db.ExecuteBySQL(sql);
                if (rtn <= 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "写入调车单信息", "异常：" + ex.Message);
                throw ex;
            }
        }

        [WebMethod(Description = "更新调车单的状态。    参数rowid：调车单id 参数state：调车单状态   0：成功，1：失败"  )]
        public int UpdateUseCarState(string rowid,int state)
        {
            string sql = string.Format(@"update car_usecall set state={0} where rowid='{1}'",state,rowid);
            try
            {
                int rtn = db.ExecuteBySQL(sql);
                if (rtn <= 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "更新调车单状态", "异常："+ex.Message);
                throw ex;
            }
        }


        [WebMethod(Description = "获得调车单信息。 state：调车单的状态  appuser：调车人   rowid：调车单id"  )]
        public DataSet GetUseCarInfo(int state,string appuser,string rowid)
        {
            DataSet ds = null;
            string sql = "";
            try
            {
                sql = string.Format(@"select a.rowid,appuser,appdep,chargeuser,a.goalcity,reason,b.carid,outdate,indate,usercount,
                    case a.state when 1 then '待派车'  when 2 then '已派车' when 0 then '待审核' when 3 then '已结算' when 4 then '作废'
                                 when 5 then '已考评' when 6 then '被合并' when 7 then '部门审批' when 8 then '打回修改' end state
                    from CAR_UseCall a  left join car_usecall_car b on a.rowid=b.callid
                    where 1 = 1 ");
                if (state != -1)
                {
                    sql += string.Format(@"and a.state = {0}", state);
                }
                if (!string.IsNullOrEmpty(appuser))
                {
                    sql += string.Format(@"and appuser like '%{0}%'", appuser);
                }
                if (!string.IsNullOrEmpty(rowid))
                {
                    sql += string.Format(@"and a.rowid ='{0}'", rowid);
                }
                
                ds = db.GetDataSetBySQL(sql);
                return ds;
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "获得调车单信息", "异常：" + ex.Message);
                throw ex;
            }
        }


        [WebMethod(Description = "获取车辆信息。 参数state：车辆的状态 carid：车牌号")]
        public DataSet GetCars(int state,string carid)
        {
            DataSet ds = null;
            try
            {
                string sql = string.Format
                    (@"select carid,typeid,rideusers,driver,drivertel = (select phonetel from car_driverinfo b where b.username=a.driver),
                          case a.state when 0 then '空闲' when 4 then '检修中' else '已派车' end state
                   from car_baseinfo a
                   where 1 = 1 ");
                if (state != -1)
                {
                    sql += string.Format(@"and state = {0}", state);
                }
                if (!string.IsNullOrEmpty(carid))
                {
                    sql += string.Format(@"and carid = '{0}'", carid);
                }
                ds = db.GetDataSetBySQL(sql);

                return ds;
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "获取所有车辆信息", "异常：" + ex.Message);
                throw ex;
            }
        }

        [WebMethod(Description = "更新车辆的状态。 参数CarId：车牌号  参数state：车辆状态")]
        public int UpdateCarsState(string CarId,int state)
        {
            try
            {
                string sql = string.Format(@"update car_baseinfo set state={0} where CarId='{1}'", state, CarId);
                int rtn = db.ExecuteBySQL(sql);
                if (rtn <= 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "更新车辆的状态", "异常：" + ex.Message);
                throw ex;
            }
        }

        [WebMethod(Description = "写入派车单信息。")]
        public int WriteSendCarInfo(string callid,string cartype,string goaltype,string drivername,string goalcity,string drivertel,
            string carid, int state, string outtime, string intime, int hhs, string usedep)
                
        {

            try
            {
                string sql = string.Format(@"insert into 
                                       car_usecall_car(callid,cartype,goaltype,drivername,goalcity,
                                       drivertel,carid,state,outtime,intime,hhs,usedep,usetype)
                                       values('{0}','{1}','{2}','{3}','{4}','{5}','{6}',{7},'{8}','{9}',{10},'{11}',{12})"
                                            , callid, cartype, goaltype, drivername, goalcity, drivertel, carid, state, outtime, intime, hhs, usedep,0);
                int rtn = db.ExecuteBySQL(sql);
                if (rtn <= 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "写入派车单信息", "异常：" + ex.Message);
                throw ex;
            }
        }

        [WebMethod(Description = "删除派车单信息")]
        public int DeleteSendCarInfo(string callid)
        {
            try
            {
                string sql = string.Format(@"DELETE FROM car_usecall_car WHERE callid= '{0}'",callid);
                int rtn = db.ExecuteBySQL(sql);
                if (rtn <= 0)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogInfo("后台调用", "删除派车单信息", "异常：" + ex.Message);
                throw ex;
            }
        }

        //[WebMethod(Description = "获得申请人的调车信息")]
        //public DataSet GetApplyUserCarInfo(string uid)
        //{
        //    DataSet ds = null;
        //    return ds;
        //}

    }
}
