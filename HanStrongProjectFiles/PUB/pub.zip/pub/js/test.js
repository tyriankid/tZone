﻿function _FormLoad() {
    
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function gg() {
    dialog.show("PUB_Arch_Info_Edit.aspx?rowid=A035872C44FB43FD92BEA40200FD05D7",990,510,function(s) {
        
    });
}
