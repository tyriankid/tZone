快速搭建Web环境 Angularjs + Express3 + Bootstrap3
========================

[快速搭建Web环境 Angularjs + Express3 + Bootstrap3](http://blog.fens.me/angularjs-express3-bootstrap3/)

## Install

```{bash}
git clone https://github.com/bsspirit/angular-basic
npm install
bower install
```

## Running

```{bash}
node app.js
```
## Author

Blog: http://blog.fens.me

## License
MIT

