'use strict';

function WelcomeCtrl($scope){
    $scope.username = 'Conan_Z';
}