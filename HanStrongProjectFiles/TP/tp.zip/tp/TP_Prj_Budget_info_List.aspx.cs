﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DevExpress.Web.ASPxTreeList;

public partial class TP_Prj_Budget_info_List : BasePage {
    private const string pagerowid = "";
    private string psid = "";
    protected void Page_Load(object sender, EventArgs e) {
        psid = Request.PhysicalPath.Substring(3).Replace("\\", "-").Replace(".aspx", "");
        SetPageRowid(pagerowid);
        
        GetTreeListData(tv,"SELECT %qt;0000%qt; rowid, %qt;%qt; prowid, %qt;立项经费科目%qt; title, 0 iswork, 0 lev, %qt;%qt; isworks, 1 type UNION ALL SELECT %qt;0001%qt; rowid, %qt;%qt; prowid, %qt;计划经费科目%qt; title, 0 iswork, 0 lev, %qt;%qt; isworks, 2 type UNION ALL SELECT rowid,prowid,title,iswork,Lev,case iswork when 0 then %qt;否%qt; else %qt;是%qt; end isworks,type FROM TP_Prj_Budget_info");
    }
    

    //树数据自定义查询
    protected void tv_CustomCallback(object sender, TreeListCustomCallbackEventArgs e) {
        string SqlCmd = "SELECT %qt;0000%qt; rowid, %qt;%qt; prowid, %qt;立项经费科目%qt; title, 0 iswork, 0 lev, %qt;%qt; isworks, 1 type UNION ALL SELECT %qt;0001%qt; rowid, %qt;%qt; prowid, %qt;计划经费科目%qt; title, 0 iswork, 0 lev, %qt;%qt; isworks, 2 type UNION ALL SELECT rowid,prowid,title,iswork,Lev,case iswork when 0 then %qt;否%qt; else %qt;是%qt; end isworks,type FROM TP_Prj_Budget_info";
        if (e.Argument.IndexOf("select ") == -1) {
            SqlCmd = RiaBase.GetDynamicValue(SqlCmd);
            if (SqlCmd.IndexOf(" where ") == -1) SqlCmd += " where 1=1 ";
            SqlCmd += "and " + e.Argument;
        } else {
            SqlCmd = e.Argument;
        }
        Session.Remove(psid + "_" + tv.ID + "_sql");
        Session.Add(psid + "_" + tv.ID + "_sql", SqlCmd);
        GetTreeListData(tv,SqlCmd);
    }
    

    //TreeList数据绑定
    private void GetTreeListData(DevExpress.Web.ASPxTreeList.ASPxTreeList oTree, string SqlCmd) {
        DataSet ds = null;
        if (!IsPostBack) Session.Remove(psid + "_" + oTree.ID + "_sql");
        if (Session[psid + "_" + oTree.ID + "_sql"] == null) {
            SqlCmd = RiaBase.GetDynamicValue(SqlCmd);
        } else {
            SqlCmd = Session[psid + "_" + oTree.ID + "_sql"].ToString();
        }
        ds = DBHelper.GetDataSetBySql(SqlCmd);
        oTree.DataSource = ds;
        oTree.DataBind();
        ds = null;
    }
}
