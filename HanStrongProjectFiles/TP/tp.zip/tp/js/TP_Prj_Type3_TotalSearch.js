﻿function _FormLoad() {
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Search() {
    var sqlCmd="SELECT appdate,state,rowid,prjcode,prjname,dbo.clip(prjuser,':',1) prjuser,dbo.clip(appdep,':',1) appdep,dbo.clip(participants,':',1) participants,prjstartdate,prjenddate,";
    sqlCmd+="case state when 0 then '新建' when 1 then '审批中' when 2 then '退回修改' when 3 then'结束' end states,";
    sqlCmd+="case prjstate when 0 then '新建' when 1 then '立项中' when 2 then '已立项' when 3 then '实施中' when 4 then '已实施' when 5 then'上报中' ";
    sqlCmd+="when 6 then '已上报' when 7 then '检查中' when 8 then '已检查' when 9 then '终止中' when 10 then '已终止' when 11 then '验收中' ";
    sqlCmd+="when 12 then '验收完成' when 13 then '课题验收中' when 14 then '课题验收完成' when 15 then '结题验收中' when 16 then '结题验收完成' when 17 then '不立项' ";
    sqlCmd+=" end prjstate,wfid,ReportFilePath,";
    sqlCmd+="projectCode =(select ProjectCode from Tp_Prj_Relation where prjid = a.rowid), ";
    sqlCmd+="projectName =(select ProjectName from Tp_Prj_Relation where prjid = a.rowid) ";
    sqlCmd+=" FROM tp_prj_baseinfo a where prjtype = '3' "; 
    if(txtPrjCode.GetText()!="")
    {
        sqlCmd +=" and prjcode like '%"+ txtPrjCode.GetText().Trim()  +"%'";
    }
    if(txtPrjName.GetText()!="")
    {
        sqlCmd +=" and prjname like '%"+ txtPrjName.GetText().Trim()  +"%'";
    }
    if(txtAppDep.GetText()!="")
    {
        sqlCmd +=" and AppDep like '%"+ txtAppDep.GetText().Trim()  +"%'";
    }
    if(txtPrjUser.GetText()!="")
    {
        sqlCmd +=" and PrjUser like '%"+ txtPrjUser.GetText().Trim()  +"%'";
    }
    if(txtSDate.GetText()!="")
    {
        sqlCmd +=" and PrjStartDate >= '"+ txtSDate.GetText().Trim()  +"'";
    }
    if(txtEDate.GetText()!="")
    {
        sqlCmd +=" and PrjEndDate <= '"+ txtEDate.GetText().Trim()  +"'";
    }
    if(txtAppDate.GetText()!="")
    {
        sqlCmd +=" and AppDate >= '"+ txtAppDate.GetText().Trim()  +"'";
    }
    if(txtAppDateE.GetText()!="")
    {
        sqlCmd +=" and AppDate <= '"+ txtAppDateE.GetText().Trim()  +"'";
    }
    jq.Open(sqlCmd);
}

function Excel() {
    var sql="";
    var sqlwhere = "";
    var _ExOption = null;
    if(txtPrjCode.GetText()!="")
    {
        sqlwhere +=" and prjcode like '%"+ txtPrjCode.GetText().Trim()  +"%'";
    }
    if(txtPrjName.GetText()!="")
    {
        sqlwhere +=" and prjname like '%"+ txtPrjName.GetText().Trim()  +"%'";
    }
    if(txtAppDep.GetText()!="")
    {
        sqlwhere +=" and AppDep like '%"+ txtAppDep.GetText().Trim()  +"%'";
    }
    if(txtPrjUser.GetText()!="")
    {
        sqlwhere +=" and PrjUser like '%"+ txtPrjUser.GetText().Trim()  +"%'";
    }
    if(txtSDate.GetText()!="")
    {
        sqlwhere +=" and PrjStartDate >= '"+ txtSDate.GetText().Trim()  +"'";
    }
    if(txtEDate.GetText()!="")
    {
        sqlwhere +=" and PrjEndDate <= '"+ txtEDate.GetText().Trim()  +"'";
    }
    if(txtAppDate.GetText()!="")
    {
        sqlwhere +=" and AppDate >= '"+ txtAppDate.GetText().Trim()  +"'";
    }
    if(txtAppDateE.GetText()!="")
    {
        sqlwhere +=" and AppDate <= '"+ txtAppDateE.GetText().Trim()  +"'";
    }
    
    sql ="select PrjCode,PrjName,dbo.clip(PrjUser,':',1) PrjUser,dbo.clip(Appdep,':',1) Appdep,AppDate,dbo.clip(Participants,':',1) Participants,";
    sql +="PrjStartDate,PrjEndDate FROM Tp_Prj_Baseinfo T where prjtype = '3' ";
    sql += sqlwhere;
    _ExOption = {sql:sql, fldname:"prjcode,prjname,prjuser,appdep,appdate,participants,prjstartdate,prjenddate", fldesc:"项目编号,项目名称,项目负责人,申请部门,申请日期,参加人员,项目开始日期,项目结束日期", fldict:"", xlsdesc:"三类科技项目信息表"};
    //alert(sql,_ExOpion);
    ExportExcel(_ExOption);
    
    /*
    sql="select Staff_name,Age,staff_sex,ID_number,Literacy,Political_landscape,Towork_date_Now,Seniority,CompanyAge,ConvertCompanyAge,bussiness_deps,dbo.__GetObjName(GroupName) GroupName,dbo.Clip(Current_position,':',1) Current_position,FPositionSequence,PositionLevel,SalaryLevel from (select *,dbo.__GetObjName(bussiness_dep)bussiness_deps from HR_Staff_Details)T where iswork=0 ";
        //sql += sqlwhere;
        _ExOption = {sql:sql, fldname:"staff_name,age,staff_sex,id_number,literacy,political_landscape,towork_date_now,seniority,companyAge,convertcompanyage,bussiness_deps,groupname,current_position,fpositionsequence,positionlevel,salarylevel", fldesc:"姓名,年龄,性别,身份证号,学历,政治面貌,进院时间,工龄,院龄,折算院龄,所属部门,组别,岗位,岗位序列,职级,薪档", fldict:"", xlsdesc:"人员信息表"};
        ExportExcel(_ExOption);
    */
}


function Reset() {
    txtPrjCode.SetText("");
    txtPrjName.SetText("");
    txtAppDep.SetText("");
    txtPrjUser.SetText("");
    txtSDate.SetText("");
    txtEDate.SetText("");
    txtAppDate.SetText("");
    txtAppDateE.SetText("");
    Search();
}

function Detail() {
    if(jq.RowIndex<1)
    {
      alert("请选择一行");
      return;
    }
    dialog.show("TP_Prj_Type3_TotalSearch_Detail.aspx?rowid=" + jq.item("rowid"),900,480,function(s) {
        
    });
}
