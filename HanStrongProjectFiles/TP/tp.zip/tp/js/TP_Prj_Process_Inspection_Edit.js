﻿function _FormLoad() {
    button4.SetEnabled(false);
    if(Req("type") == "add") {
        dbDate.SetText(S.date.day);
        _txtUser.SetText(uinfo);
        txtUser.SetText(uname);
        txtRowid.SetText(S.guid);
        var sql = "select bussiness_dep from hr_staff_details where staff_rowid = '" + uid + "'";
        var oData = GetData(sql) || [];
        if(oData.length > 0)
        {
            _txtDep.SetText(oData[0].bussiness_dep);       //当前用户所在部门为申请部门
            txtDep.SetText($ONM(oData[0].bussiness_dep));
        }
    } else {
        var sql = "select *,dbo.Clip(PrjUser, ':', 1) PrjUsers from TP_Prj_Process_Info where PcsID = '" + Req("rowid") + "'";
        gd.Open(sql);

        txtOldTitle.SetText(txtTitle.GetText());
        txtUser.SetText($ONM(_txtUser.GetText()));
        txtDep.SetText($ONM(_txtDep.GetText()));

        if (Req("type") == "view") {
            button1.SetVisible(false);
            button2.SetVisible(false);
            button4.SetVisible(false);
        }
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击一行
function gdClick() {
    button4.SetEnabled(true);
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        var type = "add";
        if (Req("type") == "view") type = "view";
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=" + type + "&rowid=" + txtRowid.GetText());
    }
}

function SelectPrj() {
    dialog.show("TP_Prj_SelectPrjs.aspx?type=1,2",680,500,function(s){
        if (s !== "close" && s.length > 0) {
            for (var i = 0; i < s.length; i++) {
                var isexist = false;
                for (var j = 1; j <= gd.RowCount(); j++) {
                    if (gd.Item("PrjID", j) == s[i].prjid) {
                        isexist = true;
                        break;
                    }
                }
                if (!isexist) {
                    gd.AddRow({ rowid:"",
                                PrjID:s[i].prjid,
                                PrjYear:s[i].prjyear,
                                PrjCode:s[i].prjcode,
                                PrjName:s[i].
                                prjname,PrjUser:s[i].prjuser,
                                PrjUsers:$ONM(s[i].prjuser) 
                              });
                }
            }
        }
    });
}

function DelPrj() {
    gd.DelRow(gd.RowIndex);
    button4.SetEnabled(false);
}

function Save() {
    gd.UptCell();
    if (Req("type") == "add") {
        if(isExist()) { 
            dsInfo.Insert(Data); 
        }
    } else if (Req("type") == "edit") {
        if (txtTitle.GetText() != txtOldTitle.GetText()) {
            if(isExist()) { 
                dsInfo.Update(Data); 
            }
        } else {
            dsInfo.Update(Data);
        }
    }
}

function Data(s){
    if(s == "") {
        var sql = "delete from TP_Prj_Process_Info where PcsID = '" + txtRowid.GetText() + "'";
        Sql.AddCmd(sql);
        var prjusers = "";
        for(var i = 1; i <= gd.RowCount(); i++) {
            sql = "INSERT INTO TP_Prj_Process_Info(PcsID ,PrjID ,PrjCode ,PrjName ,PrjUser ,PrjYear)";
            sql += "values('" + txtRowid.GetText() + "','" + gd.item("PrjID", i) + "','" + gd.item("PrjCode", i) + "','" + gd.item("PrjName", i) + "', '" + gd.item("PrjUser", i) + "', '" + gd.item("PrjYear", i) + "')";
            Sql.AddCmd(sql);
            prjusers += "," + gd.item("PrjUser", i);
        }
        if (prjusers != "") prjusers = prjusers.substring(1);
        sql = "update TP_Prj_Process_Inspection set PrjUsers = '" + prjusers + "' where rowid = '" + txtRowid.GetText() + "'";
        Sql.AddCmd(sql);
        var rtn = ExecSql();
        if (rtn != "") {
           alert("保存失败，原因：\n\n" + rtn);
        }else {
            alert("保存成功！");
            dialog.close("OK");
        }
    } else {
        alert(s);
        return;
    }
}

function isExist(){
    var title = txtTitle.GetText();
    var sql = "SELECT * FROM TP_Prj_Process_Inspection WHERE Title ='"+ title +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) {
        alert("项目中期检查标题重复!");
        return false;
    } else{
        return true;
    }
}
function CompareDate(){
	if(dbDate.GetText()!="")
	{
		if(Endate.GetText()<dbDate.GetText())
		{
			alert("截止日期必须大于申请日期");
			Endate.SetText("");
			return;
			
		}
	}
}
