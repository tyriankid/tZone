﻿function _FormLoad() {
    combox1.SetSelectedIndex(0);
    combox2.SetSelectedIndex(0);
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    dialog.show("TP_Prj_BaseInfo_View.aspx?rowid="+jq.Item("rowid"),1040,502,function(s) {
        
    });
}
function Add() {
    dialog.show("TP_Prj_BaseInfo_Edit.aspx",1040,502,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Edit(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
    if(jq.item("state")!=0)
    {
        alert("已启动的流程无法修改");
        return;
    }
    dialog.show("TP_Prj_BaseInfo_Edit.aspx?rowid="+jq.Item("rowid"),1040,502,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Del(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
     if(jq.item("state")!=0)
    {
        alert("非新建状态的信息无法删除");
        return;
    }
    if(!confirm("是否确定删除?")) return;
     Sql.AddCmd("delete from TP_Prj_BaseInfo where rowid='"+ jq.Item("rowid") +"'");
     Sql.AddCmd("delete from TP_Prj_Content where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Appropriation_Budget where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Players_Info where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Planning_Progress where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Contract_Info where prjid='"+ jq.Item("rowid") +"'");
    

    ExecSql(function(s){
        if(s=="")
        {
            alert("删除成功");
            jq.Refresh();
        }
        else
        {
            alert(s);
            return;
        }
    });

}
function  StartFlow(){
    if(jq.RowIndex<1){
        alert("请选择一行记录");
        return;
    }
     flow.StartFlow("TP_Prj_BaseInfo",jq.Item("rowid"),function(wfid){
        if(wfid.length==32){
            var sql="update TP_Prj_BaseInfo set State=1,prjstate=1 where wfid='"+wfid+"'";
            ExecSql(sql,function(s){
                if(s===""){
                    jq.Refresh();
                }
            });
        }
     });
} 
function FlowView(){
     if(jq.RowIndex === 0){
        alert("请选定要查看的记录");
        return;
    }
    if (jq.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(jq.item("wfid"));
}
function PrintReport(){
     if(jq.RowIndex<1){
        alert("请选择一行");
        return;
    }
    if (jq.Item("ReportFilePath") == "" || (jq.Item("state") > 0 && jq.Item("state") <= 2)) {
        ajax.run("TP_Prj_Report.aspx",{cmd:"apply",rowid:jq.Item("rowid")},function(o){
            //alert(o.split("<-->")[0]);
            //alert(o);
            if (o.split("<-->")[0] == "") {
                dialog.show("word.aspx?docid=" + jq.Item("rowid") + "&type=apply" ,800,600,function(s) {
                });   
            } else {
                alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
                return;
            }
        });
    } else {
        dialog.show("word.aspx?docid=" + jq.Item("rowid") + "&type=apply" ,800,600,function(s) {
        });
    }
}
function Change(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
    dialog.show("TP_Prj_BaseInfo_Edit.aspx?rowid="+jq.Item("rowid"),1040,502,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Query(){
    var sql="select *,dbo.Clip(PrjUser,':',1)PrjUsers,dbo.Clip(AppDep,':',1)AppDeps,case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' else '结束' end states,case prjstate when 0 then '新建' when 1 then '立项中' when 2 then '已立项' when 3 then '实施中' when 4 then '已实施' when 5 then'上报中' when 6 then '已上报' when 7 then '检查中' when 8 then '已检查' when 9 then '终止中' when 10 then '已终止' when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 14 then '课题验收完成' when 15 then '结题验收中' when 16 then '结题验收完成' when 17 then '不同意立项' when 18 then '课题验收不通过' end prjstates from TP_Prj_BaseInfo where  prjtype<>3";
    if(txtbh.GetText()!="")
    {
        sql+="and PrjCode like '%"+ txtbh.GetText() +"%'";
    }
    if(txtmc.GetText()!="")
    {
        sql+="and PrjName like '%"+ txtmc.GetText() +"%'";
    }
    if(datebox1.GetText()==""&&datebox2.GetText()!="")
    {
        sql+="and PrjEndDate<='"+datebox2.GetText()+"'";
    }
    if(datebox1.GetText()!=""&&datebox2.GetText()=="")
    {
        sql+="and PrjStartDate>='"+datebox1.GetText()+"'";
    }
    if(datebox1.GetText()!=""&&datebox2.GetText()!="")
    {
        sql+="and PrjStartDate>='"+datebox1.GetText()+"' and PrjEndDate<'"+datebox2.GetText()+"' ";
    }
    if(combox1.GetText()!="全部")
    {
        sql+="and State like '%"+ combox1.GetValue() +"%'";
    }
    if(combox2.GetText()!="全部")
    {
        sql+="and prjstate like '%"+ combox2.GetValue() +"%'";
    }
    //alert(sql);
    jq.Open(sql);
}
function ReSet(){
    txtbh.SetText("");
    txtmc.SetText("");
    datebox1.SetText("");
    datebox2.SetText("");
    combox1.SetSelectedIndex(0);
    combox2.SetSelectedIndex(0);
    Query();
}