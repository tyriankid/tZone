﻿function _FormLoad() {
    //cbPrjType.SetSelectedIndex(0)
    Init();
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//页面载入根据传来的参数判断新建对象准备传回
function Init() {
    cbPrjType.ClearItems();
    if (Req("type") != "1,2") {
        cbPrjType.AddItem("全部", "全部");
        cbPrjType.AddItem("一类", "1");
        cbPrjType.AddItem("二类", "2");
        cbPrjType.AddItem("三类", "3");
        cbPrjType.SetSelectedIndex(Req("prjtype"));     
        cbPrjType.SetEnabled(false);
    } else {
        cbPrjType.AddItem("全部", "全部");
        cbPrjType.AddItem("一类", "1");
        cbPrjType.AddItem("二类", "2");
        cbPrjType.SetSelectedIndex(0);     
    }

    
}

function Search() {
    var sql = "SELECT prjstate,rowid,PrjCode,PrjName,dbo.Clip(PrjUser,':',1) PrjUsers,PrjUser,LEFT(PrjStartDate, 4) PrjYear,AppDep,dbo.Clip(AppDep,':',1) AppDeps,";
    sql += "case prjstate when 0 then '新建' when 1 then '立项中' when 2 then '已立项' when 3 then '实施中' when 4 then '已实施' when 5 then'上报中' ";
    sql += "when 6 then '已上报' when 7 then '检查中' when 8 then '已检查' when 9 then '终止中' when 10 then '已终止' when 11 then '验收中' ";
    sql += "when 12 then '验收完成' when 13 then '课题验收中' when 14 then '课题验收完成' when 15 then '结题验收中' when 16 then '结题验收完成' when 17 then '不同意立项' when 18 then '课题验收不通过' ";
    sql += "end prjstates FROM TP_Prj_BaseInfo ";
    sql += "where prjstate not in (0,1,3,5,7,9,11,13,15,10,12,16,17,18) and CHARINDEX(PrjType,'" + Req("type") + "')>0";
    if (txtPrjCode.GetText() != "")
    {
        sql +=" and prjcode like '%"+ txtPrjCode.GetText().Trim() +"%'";
    }
    if (txtPrjName.GetText() != "")
    {
        sql +=" and prjname like '%"+ txtPrjName.GetText().Trim() +"%'";
    }
    if (cbPrjType.GetText() != "全部")
    {
        sql += " and prjtype = '"+ cbPrjType.GetValue() +"'";
    }
    if (cbPrjType.GetText() == "全部" && Req("prjtype") == "1.2")
    {
        sql += " and prjtype in ("+ Req("prjtype") +")";
    }
    if (txtAppDep.GetText() != "")
    {
        sql += " and appdep like '%"+ txtAppDep.GetText() +"%'";
    }
    if (txtPrjUser.GetText() != "")
    {
        sql += " and prjuser like '%"+ txtPrjUser.GetText() +"%'";
    }
    gd.Open(sql);
}

function Save() {
    var obj = [];
    for (var i = 1; i <= gd.RowCount(); i++) {
        if (gd.RowChecked(i)) {
            var tep = {
                        prjid: gd.Item("rowid", i),
                        prjyear: gd.Item("PrjYear", i),
                        prjcode: gd.Item("PrjCode", i),
                        prjname: gd.Item("PrjName", i),
                        prjuser: gd.Item("PrjUser", i),
                        prjdep: gd.Item("AppDep", i)
                      };
            obj.push(tep);
        }
    }
    if (obj.length == 0) {
        alert("请至少勾选一行");
        return;
    }
    dialog.close(obj);
}

function ReSet(){
    txtPrjCode.SetText("");
    txtAppDep.SetText("");
    txtPrjName.SetText("");
    txtPrjUser.SetText("");
    Init();
    Search();
}
