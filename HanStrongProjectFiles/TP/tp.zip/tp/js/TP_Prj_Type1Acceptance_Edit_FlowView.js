﻿
var baseid = "";
var tabname="TP_Prj_Acceptance";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(1); //默认2类
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    baseid=Req("wfid");
    if(Req("wfid") != "")
    {
        txtTitle.SetEnabled(false);
        btntxtPrjCode.SetEnabled(false);
        txtAppDate.SetEnabled(false);
        txaMemo.SetEnabled(false);
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.sopt != "打回修改")
    {
        if(obj.nodeid.indexOf("p001")>0 ) 
        {
            psChange(tabname,3,12) 
        }
        else if(obj.nodeid.indexOf("p002")>0)
        {
            sChange(tabname,1); 
        }
    }
    else 
    {
        sChange(tabname,2); 
    }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}



function psChange(tablename,state,pstate) {
    var sql2="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    var sql ="update tp_prj_baseinfo set prjstate = "+ pstate +" where rowid='"+ txtPrjId.GetText() +"'"; 
    
    Sql.AddCmd(sql);
    Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function sChange(tablename,state) {
    var sql="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    
    ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function GetValues() {
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}



var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      
    }
}
