﻿function _FormLoad() {
    
    Init();
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//页面载入根据传来的参数判断新建对象准备传回
function Init() {
    cbPrjType.ClearItems();
    if (Req("prjtype") != "1,2") {
        cbPrjType.AddItem("全部", "全部");
        cbPrjType.AddItem("一类", "1");
        cbPrjType.AddItem("二类", "2");
        cbPrjType.AddItem("三类", "3");
        cbPrjType.SetSelectedIndex(Req("prjtype"));     
        cbPrjType.SetEnabled(false);
    } else {
        cbPrjType.AddItem("全部", "全部");
        cbPrjType.AddItem("一类", "1");
        cbPrjType.AddItem("二类", "2");
        cbPrjType.SetSelectedIndex(0);     
    }

    
}

function Okay(){
    if(gd.RowIndex<1)
    {
        alert("请选择一行!");
        return;
    }
    
    var obj = { prjid:gd.Item("rowid"),
                prjcode:gd.Item("prjcode"),
                prjname:gd.Item("prjname"),
                prjtype:gd.Item("prjtype"),
                prjuser:gd.Item("prjuser"),
                prjstartdate:gd.Item("prjstartdate"),
                prjenddate:gd.Item("prjenddate")
               };
    dialog.close(obj);
}

function Search(){
    
    var sql="SELECT rowid,prjcode,prjname,prjuser,prjtype,case prjtype when '1' then '一类' when '2' then '二类' when '3' then '三类' end prjtypes"
    sql += ",dbo.clip(prjuser,':',1) prjusers,dbo.clip(appdep,':',1) appdep,prjstartdate,prjenddate FROM tp_prj_baseinfo where state = 3";/*立项的流程状态必须为3[结束]才能被选中 */
    sql += " and prjstate not in (1,3,5,7,9,11,13,15,12,10,16,17,18)";
	/* **中的项目不能被操作, 10[已终止]12[验收完成]17[不同意立项] 18[验收不通过]的项目不能被选择*/
    if (txtPrjCode.GetText() != "")
    {
        sql +=" and prjcode like '%"+ txtPrjCode.GetText().Trim() +"%'";
    }
    if (txtPrjName.GetText() != "")
    {
        sql +=" and prjname like '%"+ txtPrjName.GetText().Trim() +"%'";
    }
    if (cbPrjType.GetText() != "全部")
    {
        sql += " and prjtype = '"+ cbPrjType.GetValue() +"'";
    }
    if (cbPrjType.GetText() == "全部" && Req("prjtype") == "1,2")
    {
        sql += " and prjtype in ("+ Req("prjtype") +")";
    }
    if (txtAppDep.GetText() != "")
    {
        sql += " and appdep like '%"+ txtAppDep.GetText() +"%'";
    }
    if (txtPrjUser.GetText() != "")
    {
        sql += " and prjuser like '%"+ txtPrjUser.GetText() +"%'";
    }
    //alert(sql);
    gd.Open(sql);

}

function ReSet(){
    txtPrjCode.SetText("");
    txtAppDep.SetText("");
    txtPrjName.SetText("");
    txtPrjUser.SetText("");
    Init();
    Search();
}