﻿var deptname = "";
function _FormLoad() {
    button2.SetEnabled(false);
	var sql = "SELECT bussiness_dep FROM HR_Staff_Details hsd WHERE staff_rowid='" + uid + "'";
    var oData2 = GetData(sql) || [];
    if(oData2.length > 0) {
        deptname = oData2[0].bussiness_dep;
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击一行
function gdClick() {
    button2.SetEnabled(true);
}

//添加一行
function AddRow() {
	var odx = 1 + gd.RowCount();
	var date = S.date.day;
    gd.AddRow({rowid:"",Ordidx:odx,AppDate:date,CurMoney:0});
}

//删除一行
function DelRow() {
	gd.DelRow(gd.RowIndex);
    button2.SetEnabled(false);
}

//保存
function Save() {
	var sql = "";
	var blance = (txtMoney.GetText() - 0.00) * 10000;
    gd.UptCell();

    sql = "delete from TP_Prj_Registration_Prices where PrjID = '" + Req("prjid") + "'";
    Sql.AddCmd(sql);
    for(var i = 1; i <= gd.RowCount(); i++) {
		//验证金额
		var curmoney = gd.item("CurMoney", i);
		if (curmoney == "") {
			alert("第" + gd.item("Ordidx", i) + "行的金额不能为空");
			return;
		}
		if (isNaN(curmoney)) {
			alert("第" + gd.item("Ordidx", i) + "行的金额不是数字");
			return;
		}
		//计算余额
		blance = blance - (curmoney - 0.00);
		if (blance < 0) {
			alert("第" + gd.item("Ordidx", i) + "行的金额过大，余额已经不足，请重新填写");
			return;
		}
        sql = "INSERT INTO dbo.TP_Prj_Registration_Prices(PrjID ,PrjCode ,PrjName ,SelfMoney ,SubsidizeMoney ,Balance ,AppDate ,AppUser ,AppDep ,CurMoney ,Purpose ,Memo ,Ordidx)";
        sql += "values('" + Req("prjid") + "','" + txtCode.GetText() + "','" + txtName.GetText() + "','" + txtSelf.GetText() + "'";
        sql += ",'" + txtSelf.GetText() + "','" + blance + "','" + gd.item("AppDate", i) + "','" + uinfo + "'";
        sql += ",'" + deptname + "','" + gd.item("CurMoney", i) + "','" + gd.item("Purpose", i) + "','" + gd.item("Memo", i) + "', " + gd.item("Ordidx", i) + ")";
        Sql.AddCmd(sql);
    }
    sql = "update TP_Prj_BaseInfo set PrjBalance = '" + blance + "' where rowid = '" + Req("prjid") + "'";
    Sql.AddCmd(sql);

    var rtn = ExecSql();
    if (rtn != "") {
       alert("保存失败，原因：\n\n" + rtn);
    }else {
        alert("保存成功！");
        gd.Refresh();
		txtBlance.SetText(blance);
    }
}
