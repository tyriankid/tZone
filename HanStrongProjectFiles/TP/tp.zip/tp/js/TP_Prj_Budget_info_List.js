﻿var NodeKey = "";
var PnodeKey = "";
var Type = 1;
function _FormLoad() {
    button1.SetEnabled(false) 
    button2.SetEnabled(false) 
    button3.SetEnabled(false) 
    tv.ExpandAll();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击树节点
function GetFocusNodeKey(s,e) {
    s.GetNodeValues(e.nodeKey,["rowid","prowid","type"],function(t){
        PnodeKey = t[1];
		NodeKey = e.nodeKey;
		if (NodeKey == "0000") {
			Type = 1;
		} else if (NodeKey == "0001") {
			Type = 2;
		} else {
			Type = t[2];
		}
	    if (NodeKey == "0000" || NodeKey == "0001") {
	        button1.SetEnabled(true) 
	        button2.SetEnabled(false) 
	        button3.SetEnabled(false) 
	    } else {
	        button1.SetEnabled(true) 
	        button2.SetEnabled(true) 
	        button3.SetEnabled(true) 
	    }
	});
    
}

//添加或编辑
function Add(flag) {
    var rowid = "";
    var prowid = "";
    if (flag == "Edit") {
        rowid = NodeKey;
        prowid = PnodeKey;
    } else {
        prowid = NodeKey;
    }
    dialog.show("TP_Prj_Budget_Info_Edit.aspx?rowid=" + rowid + "&prowid=" + prowid + "&type=" + Type, 400,320,function(s) {
        if (s == "OK") {
            tv.ExpandNode(flag == "New" ? prowid : rowid);
        }
    });
}

function Delete() {
    var rowid = NodeKey;
    if (!confirm("警告!!!\n\n系统将删除该科目及科目下的所有子科目信息\n\n请谨慎操作!")) return;
    var sql1 = "delete from TP_Prj_Budget_info where prowid = '" + rowid + "'";
    var sql2 = "delete from TP_Prj_Budget_info where rowid = '" + rowid + "'";
    Sql.AddCmd(sql1);
    Sql.AddCmd(sql2);
    var rtn = ExecSql();
    if (rtn != "") {
        alert("删除失败, 原因:\n\n" + rtn);
    }else {
        tv.ExpandNode(PnodeKey);
        button1.SetEnabled(false) 
        button2.SetEnabled(false) 
        button3.SetEnabled(false)         
    }
}



