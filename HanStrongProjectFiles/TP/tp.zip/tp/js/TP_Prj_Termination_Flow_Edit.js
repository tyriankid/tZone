﻿
var baseid="";
function _FormLoad() {
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
	btntxtPrjCode.SetEnabled(false);
    baseid = Req("wfid");
    if(baseid != ""){
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    var sql=[];
    sql.push("update TP_Prj_Termination set state = 1 where wfid = '" + obj.FlowID + "'");
    flow.BSSQL = sql;
    return Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
    var rtn = ds.Update();
	if (rtn != "") {
		alert("保存失败，原因：" + rtn);
	 	return false;
	} else {
		return true;
	}
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText().Trim();
    var sql="SELECT * FROM TP_Prj_Termination WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var prj3_S_Rowid="";
var prjType=0;
var prjCode="";
var prjName="";
var prjUser="";
var appDep="";
//选择三类还没有验收的项目
function SelectPrj(){
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=3",680,500,function(s) {
        prj3_S_Rowid=s.prj3_S_Rowid;
        prjType=s.prjtype;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjUser=s.prjuser;
        appDep=s.appdep;
        //alert(prj3_S_Rowid+prjType+prjCode+prjName+prjUser+appDep);
    if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
    else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
    else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
    else{cbPrjType.SetSelectedIndex(0);}
    btntxtPrjCode.SetText(prjCode);
    txtPrjName.SetText(prjName);
    _txtAppUser.SetText(prjUser);
    _txtAppDep.SetText(appDep);
    txtRowid.SetText(prj3_S_Rowid);
    GetValues();
    });
}

function GetValues(){
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}


var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?&type=add&rowid=" + baseid);
    }
}