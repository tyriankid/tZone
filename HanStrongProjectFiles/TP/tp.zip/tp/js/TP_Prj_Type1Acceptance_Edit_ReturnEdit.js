﻿
var baseid = "";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(1); //默认1类
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    baseid=Req("wfid");
    if(baseid != ""){
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.nodeid.indexOf("p002")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            var sql="update TP_Prj_Acceptance set state = 1 where wfid='"+ baseid/*此时为wfid*/ +"'";
            ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
        }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
      
            ds.Update(Data); 
    
}

function Data(s){
    if(s=="")
    {
        //alert("保存成功");
        dialog.close("ok");
    }
    else
    {
        alert(s);
        return;
    }
}

var prj1_S_Rowid="";
var prjCode="";
var prjName="";
var prjType=0;
function SelectPrj() {
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=1&type=ktacceptance",680,500,function(s){
        prj1_S_Rowid=s.prjid;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjType=s.prjtype;

        if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
        else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
        else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
        else{cbPrjType.SetSelectedIndex(0);}  //type
        btntxtPrjCode.SetText(prjCode); //code
        txtPrjName.SetText(prjName);  //name
        txtPrjId.SetText(prj1_S_Rowid);  //prjid
    });
}

function GetValues() {
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText();
    var sql="SELECT prjcode FROM TP_Prj_Acceptance WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}
