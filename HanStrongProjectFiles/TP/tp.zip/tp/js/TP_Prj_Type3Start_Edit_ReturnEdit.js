﻿
function _FormLoad() {
    init();
}
var prjcode ="" ;//该项目选用的工程code
var prjid= "";    //该项目选用的工程id "SELECT rowid FROM prj_baseinfo"
var prjname= "";//该项目选用的工程name
var baseid= ""; //该项目id
var prjNo="";//存储当前项目编号,用来在判断是否已经存在
//流程保存操作调用的方法
function _SaveForm() {
	Save();
}

//流程提交操作调用的方法
function _SubmitForm() {
     Save();

}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
        if(obj.nodeid.indexOf("p004")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            var sql="update tp_prj_baseinfo set state = 1 where wfid='"+ txtwfid.GetText() +"'";
            ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            }
            );  
        }
    
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//判断日期信息是否合理化
function checkdate(){
    var sDate = new Date (DateStart.GetText().replace(/\-/g, "\/"));
    var eDate = new Date (DateEnd.GetText().replace(/\-/g, "\/"));
    var oDate = new Date (Date1.GetText().replace(/\-/g, "\/"));
    //alert(sDate +" " +eDate);
    if((eDate <= sDate) )
    {
        alert("结束日期不能早于或等于开始日期!");
        return false;
    }
    /*
    else if(oDate > sDate )
    {
        alert("申请日期不能晚于开始日期和结束日期!");
        return false;
    }
    */
    else{
        return true;
    }
}

//判断项目编号是否重复
function isRight(){
    prjNo=tbPrjNum.GetText().Trim();
    var sql="SELECT * FROM tp_prj_baseinfo WHERE prjcode ='"+ prjNo +"'";
    var oData = GetData(sql) || [];
    
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

function Save(){
    
    ds.Update(Data);
}

//选择申请部门
function selectAppBumen(){
        var rt=SelObject({type:"d",selcount:1,modal:"div",ctrl:"btntxtboxappbumen"},function(str)
    {
        if(str == "" || str == null)
        {
            return;
        }
    });
}

//选择参加人员
function SelectJoinUsers(){
    var temp=_txaChosenPeople.GetText();

    var rt=SelObject({type:"u",selcount:0,modal:"div",ctrl:"txaChosenPeople"},function(str)
    {
          if(str==""){
            _txaChosenPeople.SetText(temp);
             txaChosenPeople.SetText($ONM(temp));
            }

    });
}

//选择项目负责人
function selectPrjUser(){
    var rt=SelObject({type:"u",selcount:1,modal:"div",ctrl:"btntxtboxprjuser"},function(str){

        var sqlCmd="SELECT dbo.clip(GroupName,':',1) zhuanye FROM HR_Staff_Details WHERE staff_rowid='"+ str[0].id +"'";
        var oData = GetData(sqlCmd) || [];
        if(oData.length > 0)
        {             //自动填写专业txtbox的内容
            tbZhuanye.SetText(oData[0].zhuanye.substring(0,oData[0].zhuanye.length - 1));
        }
        var sqlCmd2="SELECT bussiness_dep FROM HR_Staff_Details hsd WHERE staff_rowid='"+ str[0].id +"'";
        var oData2 = GetData(sqlCmd2) || [];
        if(oData2.length > 0)
        {               //自动填写申请部门txtbox的内容

            btntxtboxappbumen.SetText($ONM(oData2[0].bussiness_dep));
            _btntxtboxappbumen.SetText(oData2[0].bussiness_dep);
            
        }
    });
}

//选择工程名称
function selectPrjName(){
    dialog.show("TP_Prj_ProjectSearch.aspx",590,380,function(s) {
        prjcode=s.prjcode;//传回工程项目的三项属性
        prjname=s.prjname;
        prjid=s.prjid;
        btntxtboxprjname.SetText(prjname);
    });
}

function Data(s){
    if(s=="")
    {
        if(checkIsSC.GetChecked() && btntxtboxprjname.GetText().Trim() != ""){  
    //如果勾选了工程项目,开始进行判断是否存在当前项目和工程项目的关系(from tp_prj_relation)
        var sql="SELECT * FROM tp_prj_relation WHERE prjid = '"+ baseid +"'";
        var oData= GetData(sql) || [];
        //alert(oData);

        if(oData.length == 0){         //如果没查到,执行insert语句
            var sql="INSERT INTO tp_prj_relation (prjid,projectid,projectcode,projectname)";
            sql +=" values('"+ baseid +"','"+ prjid +"','"+ prjcode +"','"+ prjname +"')";
            ExecSql(sql,function(s){
                    if(s == ""){    //表示成功
                        //alert("保存成功prjadd");
                    }
                    else{
                        alert(s);
                        return;
                    }
                });
        }
        else if(oData.length > 0){                  //如果查到,执行update语句
            var sql="update tp_prj_relation set projectid= '"+ prjid +"',projectcode= '"+ prjcode +"',projectname= '"+ prjname +"'";
            sql += " where prjid='"+ baseid +"'";  //根据页面载入时获取的本项目id来进行更改
            ExecSql(sql,function(s){
                if(s == ""){
                    //alert("修改成功prjedit");
                }
                else{
                    alert(s);
                    return;
                }
            });
        }
    }

        window.frames["iframe2"].Save();
    }
    else
    {
        alert(s);
        return;
    }
}


//如果选择了是生产项目:
function checkboxChanged(){
        if(!checkIsSC.GetChecked()){
            btntxtboxprjname.SetEnabled(false);
            if(btntxtboxprjname.GetText() != "")
            {
                if(!confirm("是否删除该工程与该项目的关系?")) return;
                Sql.AddCmd("DELETE FROM tp_prj_relation WHERE prjid='"+ baseid +"'");
                Sql.AddCmd("UPDATE tp_prj_baseinfo SET isproduct=0 WHERE rowid = '"+ baseid +"'");
                ExecSql(function(s){
                    if(s=="")
                    {
                        alert("删除成功!");
                    }
                    else
                    {
                        alert(s);
                        return;
                    }
                });
                btntxtboxprjname.SetText("");
            }
        }
        else{
            btntxtboxprjname.SetEnabled(true);
        }
}

//页面载入方法
function init(){
    txtPrjType.SetText("3");
    txtPrjTypeName.SetText("三类");
    btntxtboxprjname.SetEnabled(false);
    tbPrjNum.SetEnabled(false);
    tbPrjName1.SetEnabled(false);
    Date1.SetEnabled(false);
    baseid = Req("wfid");
    
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_baseinfo&col=PrjContent&rowid="+txtrowidDs1.GetText());
    
    if(baseid != "")
    {
        GetValues();
    }
    
}

function GetValues(){
        /*如果是编辑or查看模式,工程项目信息必须根据当前项目的rowid来获得*/
        tbPrjNum.SetEnabled(false); /*不允许更改项目编号*/
        /*根据隐藏控件绑定的ds字段来在相应的控件里显示出相应的数据 txaChosenPeople btntxtboxappbumen btntxtboxprjuser*/
        txaChosenPeople.SetText($ONM(_txaChosenPeople.GetText().Trim()));
        btntxtboxappbumen.SetText($ONM(_btntxtboxappbumen.GetText().Trim()));
        btntxtboxprjuser.SetText($ONM(_btntxtboxprjuser.GetText().Trim()));
        /*
        var sql="SELECT projectid,projectcode,projectname FROM tp_prj_relation WHERE prjid = ";
        sql +="(SELECT rowid FROM TP_Prj_BaseInfo WHERE wfid = '"+ baseid +"')";
        */
        var sql="SELECT projectid,projectcode,projectname FROM tp_prj_relation WHERE prjid = '"+ txtrowidDs1.GetText() +"'";
        var oData= GetData(sql) || [];
        if(oData.length > 0){       
            //如果当前的项目id在关系表tp_prj_relation可以查出消息,表示这个项目是工程项目
            checkIsSC.SetChecked(true);
            btntxtboxprjname.SetEnabled(true);
            prjcode=oData[0].projectcode;
            prjname=oData[0].projectname;
            prjid=oData[0].projectid;
            btntxtboxprjname.SetText(prjname);
        }
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}



