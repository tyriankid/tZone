﻿function _FormLoad() {
    var sql = "select *,dbo.Clip(PrjUser,':',1) PrjUsers,dbo.Clip(PrjDep,':',1) PrjDeps from TP_Prj_Completion_Info where CRID = '" + txtRowid.GetText() + "'";
    var sql1 = "select *,dbo.Clip(PrjUser,':',1) PrjUsers,dbo.Clip(PrjDep,':',1) PrjDeps from TP_Prj_Request_Info where CRID = '" + txtRowid.GetText() + "'";
    if (Req("rowid")!="") {
        sql += " and PrjUser = '" + uinfo + "'";
        sql1 += " and PrjUser = '" + uinfo + "'";
    } /*else if (Req("nid").indexOf("p001") > 0) {
        sql += " and PrjUser = (SELECT FWTITLE FROM dbo.WFOBJ_FLOW_STEP WHERE WFOBJID = '" + Req("wfid") + "' AND Nodemid = '" + Req("nid") + "' AND EXEUSER = '" + uinfo + "')";
        sql1 += " and PrjUser = (SELECT FWTITLE FROM dbo.WFOBJ_FLOW_STEP WHERE WFOBJID = '" + Req("wfid") + "' AND Nodemid = '" + Req("nid") + "' AND EXEUSER = '" + uinfo + "')";
    }*/
    gd.Open(sql);
    jq.Open(sql1);

    txtOldTitle.SetText(txtTitle.GetText());
    txtUser.SetText($ONM(_txtUser.GetText()));
    txtDep.SetText($ONM(_txtDep.GetText()));
	 if (Req("type") == "view") {
            button1.SetVisible(false);
       
        }
}

//流程保存操作调用的方法
function _SaveForm(obj) {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    var sql=[];
    if (obj.NodeID.indexOf("p001") > 0) {
        sql.push("update TP_Prj_Completion_Request set state = 3 where wfid = '" + obj.FlowID + "'");
        for(var i = 1; i <= gd.RowCount(); i++) {
            sql.push("update TP_Prj_BaseInfo set prjstate = 6 where rowid = '" + gd.Item("PrjID", i) + "'");
        }
    }
    flow.BSSQL = sql;
    return Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击一行
function gdClick() {
    
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        var type = "add";
        if (Req("type") == "view") type = "view";
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=" + type + "&rowid=" + txtRowid.GetText());
    }
}

function Save() {
    gd.UptCell();
    jq.UptCell();
    var sql = "";
    for(var i = 1; i <= gd.RowCount(); i++) {
        if (gd.Item("Completion", i) == "") {
            alert(gd.Item("PrjCode", i) + "项目没有填写完成情况！");
            return false;
        }
        sql = "update TP_Prj_Completion_Info set Completion = '" + gd.Item("Completion", i) + "' where rowid = '" + gd.Item("rowid", i) + "'";
        Sql.AddCmd(sql);
    }
    for(var j = 1; j <= jq.RowCount(); j++) {
        if (jq.Item("Purpose", j) == "") {
            alert(jq.Item("PrjCode", j) + "项目没有填写经费用途！");
            return false;
        }
        //验证金额
        var curmoney = jq.Item("PrjMoney", j);
        if (curmoney == "") {
            alert(jq.Item("PrjCode", j) + "项目没有填写金额");
            return false;
        }
        if (isNaN(curmoney)) {
            alert(jq.Item("PrjCode", j) + "项目所填写的金额不是数字");
            return false;
        }
        sql = "update TP_Prj_Request_Info set Purpose = '" + jq.Item("Purpose", j) + "', PrjMoney = '" + curmoney + "' where rowid = '" + jq.Item("rowid", j) + "'";
        Sql.AddCmd(sql);
    }
    var rtn = ExecSql();
    if (rtn != "") {
        alert("保存失败，原因：\n\n" + rtn);
        return ;
    } else {
        alert("操作成功");
        dialog.close("ok");
    }
}
