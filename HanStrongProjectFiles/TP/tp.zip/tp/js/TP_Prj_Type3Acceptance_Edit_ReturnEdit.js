﻿
var baseid = "";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(3);
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtPrjUser.SetEnabled(false);
    txtPrjStartDate.SetEnabled(false);
    txtPrjEndDate.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    btntxtPrjCode.SetEnabled(false);
    baseid=Req("wfid");
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_results_acceptance&col=Content&rowid="+txtBaseId.GetText());
    if(baseid != "")
    {
        GetValues();
    }
    
}

//流程保存操作调用的方法
function _SaveForm() {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm() {
    Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
        if(obj.nodeid.indexOf("p004")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            var sql="update tp_prj_results_acceptance set state = 1 where wfid='"+ baseid/*此时为wfid*/ +"'";
            ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
        }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
        
        ds.Update(Data);
}

function Data(s){
    if(s=="")
    {
        window.frames["iframe2"].Save();
    }
    else
    {
        alert(s);
        return;
    }
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText();
    var sql="SELECT * FROM TP_Prj_results_acceptance WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var prj3_S_Rowid="";
var prjCode="";
var prjName="";
var prjUser="";
var prjType=0;
var prjStartDate="";
var prjEndDate="";
function SelectPrj() {
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=3",680,500,function(s){
        prj3_S_Rowid=s.prjid;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjUser=s.prjuser;
        prjType=s.prjtype;
        prjStartDate=s.prjstartdate;
        prjEndDate=s.prjenddate;
        if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
        else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
        else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
        else{cbPrjType.SetSelectedIndex(0);}  //type

        btntxtPrjCode.SetText(prjCode); //code
        txtPrjName.SetText(prjName);  //name
        _txtPrjUser.SetText(prjUser); //user
        txtPrjStartDate.SetText(prjStartDate); //sdate
        txtPrjEndDate.SetText(prjEndDate); //edate
        txtPrjId.SetText(prj3_S_Rowid);  //prjid

        txtPrjUser.SetText($ONM(prjUser));
    });
}

function selectAppBumen(){
        var rt=SelObject({type:"d",selcount:1,modal:"div",ctrl:"txtAppDep"},function(str)
    {});
}

//选择参加人员
function SelectJoinUsers(){
    var temp=_txaParticipants.GetText();
    var rt=SelObject({type:"u",selcount:0,modal:"div",ctrl:"txaParticipants"},function(str)
    {
        if(str=="")
        {
            _txaParticipants.SetText(temp);
            txaParticipants.SetText($ONM(temp));
        }
    });
}

function GetValues() {
    txtPrjUser.SetText($ONM(_txtPrjUser.GetText()));
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
    txaParticipants.SetText($ONM(_txaParticipants.GetText().Trim()));
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}
