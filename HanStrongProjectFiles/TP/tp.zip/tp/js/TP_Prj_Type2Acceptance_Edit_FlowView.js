﻿
var baseid = "";
var tabname="tp_prj_subject_acceptance";
function _FormLoad() {
    
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    baseid=Req("wfid");
    if(Req("wfid") != "")
    {
        txtTitle.SetEnabled(false);
        btntxtPrjCode.SetEnabled(false);
        txtAppDate.SetEnabled(false);
        txaMemo.SetEnabled(false);
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.sopt != "打回修改")
    {
        if(obj.nodeid.indexOf("p001")>0) 
        /*当前节点p001是最后一个审核节点,通过了后状态为结束,同时如果勾选了验收不通过也会结束*/
        {

           sChange(tabname,3); //state=3[结束]
           /*如果是以走完最后一个流程结束,prjState变更为14[课题验收完成] 否则18 [验收不通过]]*/
           if(obj.sopt != "验收不通过") 
		   { 
				psChange(tabname,3,14);
		   } 
		   else
		   {
				psChange(tabname,3,18);
		   }
        }
        else if(obj.nodeid.indexOf("p002")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            sChange(tabname,1); //state=1[审核中]
        }
    }
    else //打回修改
    {
        sChange(tabname,2); //state=2[打回修改]
    }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}



function psChange(tablename,state,pstate) {
    var sql2="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    var sql ="update tp_prj_baseinfo set prjstate = "+ pstate +" where rowid='"+ txtPrjId.GetText() +"'"; 
    
    Sql.AddCmd(sql);
    Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function sChange(tablename,state) {
    var sql="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    
    ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function GetValues() {
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
    var sql ="select prjtype,prjtypename from tp_prj_baseinfo where rowid = '"+ txtPrjId.GetText() +"'";
        
        var obj = GetData(sql)||[];
        if(obj.length > 0) {
            if(obj[0].prjtype == "1")
            {
                cbPrjType.SetSelectedIndex(1);
            }
            if(obj[0].prjtype == "2")
            {
                cbPrjType.SetSelectedIndex(2);
            }
        }
    cbPrjType.SetEnabled(false);
}



var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      
    }
}
