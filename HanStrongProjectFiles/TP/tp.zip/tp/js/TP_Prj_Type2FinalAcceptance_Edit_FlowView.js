﻿
var baseid = "";
var tabname="TP_Prj_Final_Acceptance";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(0); //1，二类
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtPrjUser.SetEnabled(false);
    txtPrjStartDate.SetEnabled(false);
    txtPrjEndDate.SetEnabled(false);
    baseid=Req("wfid");
    if(baseid != ""){
        btntxtPrjCode.SetEnabled(false);
        txtAppAddress.SetEnabled(false);
        txtAppDate.SetEnabled(false);
        btnSelectPeople.SetEnabled(false);
        txaParticipants.SetEnabled(false);
        //txaContent.SetEnabled(false);
        GetValues();
    }
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Final_Acceptance&col=Content&rowid="+txtBaseId.GetText());

}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    var sql =[];
    if(obj.SubmitOption != "打回修改")
    {
        if(Req("nid").indexOf("p000") >0) //专家组验收意见(安质部科技专责)Experts
        {
            sql.push("update TP_Prj_Final_Acceptance set Experts={IDEA} where wfid='"+obj.FlowID+"'");
        }
        flow.BSSQL = sql;
        return true;
    }
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.sopt != "打回修改")
    {
        if(obj.nodeid.indexOf("p001")>0 ) 
        {
           psChange(tabname,3,16);
        }
        else if(obj.nodeid.indexOf("p002")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            sChange(tabname,1); 
        }
    }
    else 
    {
        sChange(tabname,2); 
    }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}



function psChange(tablename,state,pstate) {
    var sql2="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    var sql ="update tp_prj_baseinfo set prjstate = "+ pstate +" where rowid='"+ txtPrjId.GetText() +"'"; 
    
    Sql.AddCmd(sql);
    Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function sChange(tablename,state) {
    var sql="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
   
    ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}



function GetValues() {
    txtPrjUser.SetText($ONM(_txtPrjUser.GetText()));
    txaParticipants.SetText($ONM(_txaParticipants.GetText()));
    var sql ="select prjtype,prjtypename from tp_prj_baseinfo where rowid = '"+ txtPrjId.GetText() +"'";
        
        var obj = GetData(sql)||[];
        if(obj.length > 0) {
            if(obj[0].prjtype == "1")
            {
                cbPrjType.SetSelectedIndex(1);
            }
            if(obj[0].prjtype == "2")
            {
                cbPrjType.SetSelectedIndex(2);
            }
        }
    cbPrjType.SetEnabled(false);
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      
    }
}
