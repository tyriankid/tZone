﻿function _FormLoad() {
    if (Req("rowid") == "") {
        txtProwid.SetText(Req("prowid"));
        npLev.SetValue(1);
		txtRowid.SetText(S.guid);
		txtProwid.SetText(Req("prowid"));
		txtType.SetText(Req("type"));
		txtIsWork.SetText("1");
		var odata = GetData("SELECT ISNULL(MAX(ordidx), 0) + 1 lastidx FROM TP_Prj_Budget_info WHERE type = " + Req("type")) || [];
        if (odata.length > 0) {
			npIdx.SetValue(odata[0].lastidx - 0);
		}
    } else {
    } 
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save() {
    var rtn = "";
	
	if (txtName.GetText() == "") {
		alert("科目名称不能为空");
		return;
	}
    if (Req("rowid") == "") {
        rtn = ds.Insert();
    } else {
        rtn = ds.Update();
    }

    if (rtn == "") {
        alert("保存成功！");
        dialog.close("OK");
    } else {
        alert("保存失败，原因：" + rtn);
    }
}
