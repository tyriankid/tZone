﻿var deptname = "";
function _FormLoad() {
    button2.SetEnabled(false);
	button1.SetEnabled(false);
    var sql = "SELECT bussiness_dep FROM HR_Staff_Details hsd WHERE staff_rowid='" + uid + "'";
    var oData2 = GetData(sql) || [];
    if(oData2.length > 0) {
        deptname = oData2[0].bussiness_dep;
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    switch(Cmd) {
		case "查看":
			showContract();
			break;
		default:
			break;
	}
}

function showContract() {
	var sql = "SELECT rowid FROM ContractInfo WHERE ContractID = '" + gdContract.Item("ContractID") + "'";
	var obj = GetData(sql) || [];
	if (obj.length > 0) {
		dialog.show("../htgl/ht_ContractInfo_Edit.aspx?flag=" + obj[0].rowid + "&act=view",652,643,function(s){
	        
	    });
	}

}

//单击一行
function gdContractClick() {
    button1.SetEnabled(true);
	var sql = "SELECT * FROM dbo.TP_Prj_Contract_Prices WHERE ContractID = '" + gdContract.Item("ContractID") + "'";
	gd.open(sql);
}

//单击一行
function gdClick() {
    button2.SetEnabled(true);
}

//添加一行
function AddRow() {
    var odx = 1 + gd.RowCount();
    var date = S.date.day;
    gd.AddRow({rowid:"",AppDate:date,CurMoney:0});
}

//删除一行
function DelRow() {
    gd.DelRow(gd.RowIndex);
    button2.SetEnabled(false);
}

function Save() {
	if(gdContract.RowIndex < 1) {
        alert("没有选择合同信息，无法进行保存操作！");
        return;
    }
	var contractid = gdContract.Item("ContractID");
	var sql = "";
    var blance = gdContract.Item("ContractMeony") - 0.00;
    gd.UptCell();

    sql = "delete from TP_Prj_Contract_Prices where ContractID = '" + contractid + "'";
    Sql.AddCmd(sql);
    for(var i = 1; i <= gd.RowCount(); i++) {
        //验证标题
		var title = gd.item("Title", i);
		if (title == "") {
			alert("第" + i + "行的付款次数不能为空");
			return;
		}
		//验证金额
        var curmoney = gd.item("CurMoney", i);
        if (curmoney == "") {
            alert(title + "的金额不能为空");
            return;
        }
        if (isNaN(curmoney)) {
            alert(title + "的金额不是数字");
            return;
        }
        //计算余额
        blance = blance - (curmoney - 0.00);
        if (blance < 0) {
            alert(title + "的金额过大，余额已经不足，请重新填写");
            return;
        }
        sql = "INSERT INTO dbo.TP_Prj_Contract_Prices( ContractID ,Title ,CurMoney ,Balance ,AppDate)";
        sql += "values('" + contractid + "','" + title + "','" + curmoney + "','" + blance + "','" + gd.item("AppDate", i) + "')";
        Sql.AddCmd(sql);
    }

    var rtn = ExecSql();
    if (rtn != "") {
       alert("保存失败，原因：\n\n" + rtn);
    }else {
        alert("保存成功！");
        gd.Refresh();
    }
}
