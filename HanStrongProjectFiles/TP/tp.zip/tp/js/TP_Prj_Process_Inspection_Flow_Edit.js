﻿function _FormLoad() {
    var sql = "select *,dbo.Clip(PrjUser,':',1) PrjUsers from TP_Prj_Process_Info where PcsID = '" + txtRowid.GetText() + "'";
    if (Req("nid").indexOf("p000") > 0) {
        sql += " and PrjUser = '" + uinfo + "'";
    } else if (Req("nid").indexOf("p001") > 0) {
        sql += " and charindex (PrjUser , (SELECT FWTITLE FROM dbo.WFOBJ_FLOW_STEP WHERE WFOBJID = '" + Req("wfid") + "' AND Nodemid = '" + Req("nid") + "' AND EXEUSER = '" + uinfo + "') ) > 0";
		
	}
    
    
    gd.Open(sql);

    txtOldTitle.SetText(txtTitle.GetText());
    txtUser.SetText($ONM(_txtUser.GetText()));
    txtDep.SetText($ONM(_txtDep.GetText()));

}

//流程保存操作调用的方法
function _SaveForm(obj) {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    Save();
    if (obj.NodeID.indexOf("p006") > 0) {
        var sql=[];     
        sql.push("update TP_Prj_Process_Inspection set state = 1 where wfid = '" + obj.FlowID + "'");
        flow.BSSQL = sql;
    }
    return true;
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击一行
function gdClick() {
    
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        var type = "add";
        if (Req("type") == "view") type = "view";
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=" + type + "&rowid=" + txtRowid.GetText());
    }
}

function Save() {
    gd.UptCell();
    for(var i = 1; i <= gd.RowCount(); i++) {
        //sql = "update TP_Prj_Process_Info set Content = '" + gd.Item("Content", i) + "' where rowid = '" + gd.Item("rowid", i) + "'";
        Sql.AddCmd("update TP_Prj_Process_Info set Content = '" + gd.Item("Content", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set OldPlan = '" + gd.Item("OldPlan", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set MoneyUsed = '" + gd.Item("MoneyUsed", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set NextPlan = '" + gd.Item("NextPlan", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        //Sql.AddCmd(sql);
        if (Req("nid").indexOf("p000") > 0) {
            sql = "update TP_Prj_Process_Info set AppDate = '" + S.date.day + "' where rowid = '" + gd.Item("rowid", i) + "'";
            Sql.AddCmd(sql);
        }
    }
    var rtn = ExecSql();
    if (rtn != "") {
       alert("保存失败，原因：\n\n" + rtn);
       return;
    }
}

function isExist(){
    var title = txtTitle.GetText();
    var sql = "SELECT * FROM TP_Prj_Process_Inspection WHERE Title ='"+ title +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) {
        alert("项目中期检查标题重复!");
        return false;
    } else{
        return true;
    }
}
function CompareDate(){
    if(dbDate.GetText()!="")
    {
        if(Endate.GetText()<dbDate.GetText())
        {
            alert("截止日期必须大于申请日期");
            Endate.SetText("");
            return;
            
        }
    }
}
