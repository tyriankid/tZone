﻿function _FormLoad() {
    cbState.SetSelectedIndex(0);
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    dialog.show("TP_Prj_Termination_Edit.aspx?type=view&rowid=" + gd.item("rowid"),680,650,function(s){
    });
}

function Search(){
    var sql = "select a.prjid,a.wfid,a.rowid,a.PrjCode,a.PrjName,dbo.clip(a.appdep,':',1) appdep"
    sql += ",case a.state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' when 3 then '结束' end state";
    sql += ",dbo.clip(b.PrjUser,':',1) prjuser,a.AppDate";
    sql += " from TP_Prj_Termination a left join tp_prj_baseinfo b on a.prjid = b.rowid where b.PrjType IN (1,2)";
    if (txtPrjCode.GetText().Trim() != "") {
        sql += " and a.prjcode like '%" + txtPrjCode.GetText().Trim() + "%'";
    }
    if (txtPrjName.GetText().Trim() != "") {
        sql += " and a.prjname like '%" + txtPrjName.GetText().Trim() + "%'";
    }
    if (cbState.GetText().Trim() != "全部") {
        sql += " and a.state = '" + cbState.GetValue().Trim() + "'";
    }
    if (AppDate1.GetText() != "") {
        sql += " and a.AppDate >= '" + AppDate1.GetText() + "'";
    }
    if (AppDate2.GetText() != "") {
        sql += " and a.AppDate <= '" + AppDate2.GetText() + "'";
    }

    //alert(sql);
    gd.Open(sql);
}

function Add(){
    dialog.show("TP_Prj_Termination_Edit.aspx?type=add&rowid=",680,650,function(s) {
        if (s == "ok") { gd.Refresh(); }
    });
}


function Edit(){
    if (gd.RowIndex < 1) {
        alert("请选择一行!");
        return;
    }
	if(gd.item("state")  != "新建")
	{
		alert("流程状态为新建时才能修改!");
		return
	}
    dialog.show("TP_Prj_Termination_Edit.aspx?type=edit&rowid=" + gd.item("rowid"),680,650,function(s) {
        if (s == "ok") { gd.Refresh(); }
    });
}

function Delete(){
    var count = 0;  /*用于判断是否勾选了至少一项信息*/
    var rids = "";    /*存放选中项的rowid*/
    var objstate = "";   /*存放项目状态 如果不是"新建"则不能删除*/
    for (var i = 1; i <= gd.RowCount(); i++) {
        if (gd.RowChecked(i) == true) {
            count++;
            rids += "," + gd.item("rowid",i);
            objstate = gd.item("state",i);
            if (objstate != "新建") {
                alert("已经启动过的项目无法删除!");
                return;
            }
        }
    }
    if (count == 0) {
        alert("请勾选要删除的项目!");
        return;
    }
    if (!confirm("是否确认删除")) return;
    rids = rids.substring(1); //把第一个"," 去掉
    Sql.AddCmd("delete from tp_prj_termination where charindex(rowid,'" + rids + "')>0"); //根据baseinfo表里的rowid删除项目信息
    
    ExecSql(function(s) {
        if (s == "") {
            alert("删除成功!");
            gd.Refresh();
        } else {
            alert(s);
            return;
        }
    });
}

//启动
function Startflow(){
    if (gd.RowIndex < 1) {
        alert("请选择一行记录");
        return;
    }
    if (!canStartflow(gd.Item("prjid"))) { return; }  //根据项目状态判断能否启动
    flow.StartFlow("TP_Prj_Termination",gd.Item("rowid"),function(wfid){
        if (wfid.length == 32) {
            var sql = "update TP_Prj_Termination set state=1 where wfid='" + wfid + "'";
            var sql2 = "update tp_prj_baseinfo set prjstate=9 where rowid='" + gd.Item("prjid") + "'"; //prjstate:9[终止中]
            Sql.AddCmd(sql);
            Sql.AddCmd(sql2);
            ExecSql(function(s){
                if (s === "") {
                    gd.Refresh();
                }
            });
        }
    });
}

function ReSet() {
    txtPrjCode.SetText("");
    txtPrjName.SetText("");
    AppDate1.SetText("");
    AppDate2.SetText("");
    cbState.SetSelectedIndex(0);
    Search();
}

//流程图
function ViewISOFlowRun() {
    if (gd.RowIndex === 0) {
        alert("请选定要提交审批的记录");
        return;
    }
    if (gd.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(gd.item("wfid"));
}

//启动项目前的判断
function canStartflow (prjid) {
    var sql = "select case prjstate when 1 then '立项中' when 3 then '实施中' when 5 then '上报中' ";
    sql += "when 7 then '检查中' when 9 then '终止中' when 10 then '已终止' ";
    sql += "when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 15 then '结题验收中' end prjstate";
    sql += " from tp_prj_baseinfo where rowid='" + prjid + "'";
    var oData = GetData(sql) || [];
    if (oData.length > 0) {  //如果prjstate在以上状态中,则不允许启动项目
        if (oData[0].prjstate == "") {
            return true;
        }
        alert("该项目状态为" + oData[0].prjstate + ",不能被启动!");
        return false;
    }
    
}