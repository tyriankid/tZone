﻿function _FormLoad() {
    button4.SetEnabled(false);
    if(Req("rowid") == "") {
        dbDate.SetText(S.date.day);
        txtYM.SetText(S.date.day.substring(0,7));
        _txtUser.SetText(uinfo);
        txtUser.SetText(uname);
        txtRowid.SetText(S.guid);
        var sql = "select bussiness_dep from hr_staff_details where staff_rowid = '" + uid + "'";
        var oData = GetData(sql) || [];
        if(oData.length > 0)
        {
            _txtDep.SetText(oData[0].bussiness_dep);       //当前用户所在部门为申请部门
            txtDep.SetText($ONM(oData[0].bussiness_dep));
        }
    } else {
        var sql = "select rowid prjid, PrjCode,PrjName,PrjUser,AppDep prjdep,LEFT(PrjStartDate, 4) prjyear";
        sql += ",dbo.Clip(PrjUser, ':', 1) PrjUsers,dbo.Clip(AppDep, ':', 1) PrjDeps from TP_Prj_BaseInfo a ";
        sql += " where CHARINDEX(PrjCode, '" + txtCodes.GetText() + "') > 0"
        //alert(sql);
        gd.Open(sql);

        txtOldTitle.SetText(txtTitle.GetText());
        txtUser.SetText($ONM(_txtUser.GetText()));
        txtDep.SetText($ONM(_txtDep.GetText()));

        if (Req("type") == "view") {
            button1.SetVisible(false);
            button2.SetVisible(false);
            button4.SetVisible(false);
        }
    }

    if(Req("type")=="addto")
    {
        isaddto.SetText(1);
    }
    else
    {
        isaddto.SetText(0);
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function View() {
    dialog.show("TP_Prj_Completion_All_View.aspx?crid=&hzid=" + txtRowid.GetText(),820,460,function(s){
    });
}

//单击一行
function gdClick() {
    button4.SetEnabled(true);
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        var type = "add";
        if (Req("type") == "view") type = "view";
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=" + type + "&rowid=" + txtRowid.GetText());
    }
}

function SelectPrj() {
    dialog.show("TP_Prj_SelectPrjs.aspx?type=1,2",680,500,function(s){
        if (s !== "close" && s.length > 0) {
            for (var i = 0; i < s.length; i++) {
                var isexist = false;
                for (var j = 1; j <= gd.RowCount(); j++) {
                    if (gd.Item("PrjID", j) == s[i].prjid) {
                        isexist = true;
                        break;
                    }
                }
                if (!isexist) {
                    gd.AddRow({ rowid: "",
                                PrjID: s[i].prjid,
                                PrjYear: s[i].prjyear,
                                PrjCode: s[i].prjcode,
                                PrjName: s[i].prjname,
                                PrjUser: s[i].prjuser,
                                PrjUsers: $ONM(s[i].prjuser),
                                PrjDep: s[i].prjdep,
                                PrjDeps: $ONM(s[i].prjdep),
                                isaddto:isaddto.GetText()
                              });
                }
            }
        }
    });
}

function DelPrj() {
    gd.DelRow(gd.RowIndex);
    button4.SetEnabled(false);
}

function Save() {
    gd.UptCell();
    txtYM.SetText(dbDate.GetText().substring(0,7));
    txtM.SetText(dbDate.GetText().substring(5,7));
    if (Req("rowid") == "") {
        if(isExist()) { 
            dsInfo.Insert(Data); 
        }
    } else {
        if (txtTitle.GetText() != txtOldTitle.GetText()) {
            if(isExist()) { 
                dsInfo.Update(Data); 
            }
        } else {
            dsInfo.Update(Data);
        }
    }
}

function Data(s){
    if(s == "") {
         var prjusers = "";
        var prjcodes="";
        var Crid = "";
         var sql="";
        // alert(isaddto.GetText()=="0");
        if(isaddto.GetText()=="0")
        {
        sql = "delete from TP_Prj_Completion_Info where CRID = '" + txtRowid.GetText() + "'";
        Sql.AddCmd(sql);
        sql = "delete from TP_Prj_Request_Info where CRID = '" + txtRowid.GetText() + "'";
        Sql.AddCmd(sql);
      
        for(var i = 1; i <= gd.RowCount(); i++) {
            sql = "INSERT INTO TP_Prj_Completion_Info(HZRID ,PrjID ,PrjCode ,PrjName ,PrjUser ,PrjDep ,PrjYear ,PrjMonth)";
            sql += "values('" + txtRowid.GetText() + "','" + gd.item("PrjID", i) + "','" + gd.item("PrjCode", i) + "'";
            sql += ",'" + gd.item("PrjName", i) + "', '" + gd.item("PrjUser", i) + "', '" + gd.item("PrjDep", i) + "'";
            sql += ", '" + gd.item("PrjYear", i) + "', '" + txtM.GetText() + "')";
            Sql.AddCmd(sql);

            sql = "INSERT INTO TP_Prj_Request_Info(HZRID ,PrjID ,PrjCode ,PrjName ,PrjUser ,PrjDep ,PrjYear ,PrjMonth)";
            sql += "values('" + txtRowid.GetText() + "','" + gd.item("PrjID", i) + "','" + gd.item("PrjCode", i) + "'";
            sql += ",'" + gd.item("PrjName", i) + "', '" + gd.item("PrjUser", i) + "', '" + gd.item("PrjDep", i) + "'";
            sql += ", '" + gd.item("PrjYear", i) + "', '" + txtM.GetText() + "')";
            Sql.AddCmd(sql);
            prjcodes += "," + gd.item("PrjCode", i);
            
        }
        if (prjcodes != "") prjcodes = prjcodes.substring(1);
        sql = "update TP_Prj_Completion_All set PrjCodes = '" + prjcodes + "' where rowid = '" + txtRowid.GetText() + "'";
        Sql.AddCmd(sql);
        }
        else
        {
             for(var i = 1; i <= gd.RowCount(); i++) {
	             if(gd.item("isaddto",i)=="1")
	             {
	                sql = "INSERT INTO TP_Prj_Completion_Info(HZRID ,PrjID ,PrjCode ,PrjName ,PrjUser ,PrjDep ,PrjYear ,PrjMonth,isaddto)";
	                sql += "values('" + txtRowid.GetText() + "','" + gd.item("PrjID", i) + "','" + gd.item("PrjCode", i) + "'";
	                sql += ",'" + gd.item("PrjName", i) + "', '" + gd.item("PrjUser", i) + "', '" + gd.item("PrjDep", i) + "'";
	                sql += ", '" + gd.item("PrjYear", i) + "', '" + txtM.GetText() + "','1')";
	                Sql.AddCmd(sql);
	    
	                sql = "INSERT INTO TP_Prj_Request_Info(HZRID ,PrjID ,PrjCode ,PrjName ,PrjUser ,PrjDep ,PrjYear ,PrjMonth,isaddto)";
	                sql += "values('" + txtRowid.GetText() + "','" + gd.item("PrjID", i) + "','" + gd.item("PrjCode", i) + "'";
	                sql += ",'" + gd.item("PrjName", i) + "', '" + gd.item("PrjUser", i) + "', '" + gd.item("PrjDep", i) + "'";
	                sql += ", '" + gd.item("PrjYear", i) + "', '" + txtM.GetText() + "','1')";
	                Sql.AddCmd(sql);
	                
	             }  
				prjcodes += "," + gd.item("PrjCode", i);              
            }
			if (prjcodes != "") prjcodes = prjcodes.substring(1);
			sql = "update TP_Prj_Completion_All set PrjCodes = '" + prjcodes + "' where rowid = '" + txtRowid.GetText() + "'";
			Sql.AddCmd(sql);
        }
         
        var rtn = ExecSql();
        if (rtn != "") {
           alert("保存失败，原因：\n\n" + rtn);
        }else {
            if(isaddto.GetText()=="0")
            {
            var obj1=GetData("select rowid,prjuser,prjdep from TP_Prj_Completion_Info where HZRID='"+ txtRowid.GetText() +"' order by PrjUser")||[];
            var obj2=GetData("select rowid,prjuser,prjdep from TP_Prj_Request_Info where HZRID='"+ txtRowid.GetText() +"' order by PrjUser")||[];
            }
            else
            {
            var obj1=GetData("select rowid,prjuser,prjdep from TP_Prj_Completion_Info where HZRID='"+ txtRowid.GetText() +"' and isaddto='1' order by PrjUser")||[];
            var obj2=GetData("select rowid,prjuser,prjdep from TP_Prj_Request_Info where HZRID='"+ txtRowid.GetText() +"' and isaddto='1' order by PrjUser")||[];
            }
            if(obj1.length>0)
            {
                for(var j=0;j<obj1.length;j++)
                {
                    if(prjusers!=obj1[j].prjuser)
                    {
                        Crid=GUID();
                        sql="insert into TP_Prj_Completion_Request(rowid,Title,AppUser,AppDep,AppDate,YearMonth,isaddto)";
                        sql+="values('"+ Crid +"','"+ txtYM.GetText() +"项目进度及经费上报','"+ obj1[j].prjuser +"','"+ obj1[j].prjdep +"','"+ S.date.day +"','"+ txtYM.GetText() +"','"+ isaddto.GetText() +"')"
                        Sql.AddCmd(sql);   
                        prjusers=obj1[j].prjuser;
                    }
                    
                    Sql.AddCmd("update TP_Prj_Completion_Info set CRID='"+ Crid +"' where rowid='"+obj1[j].rowid  +"'");
                    Sql.AddCmd("update TP_Prj_Request_Info set CRID='"+ Crid +"' where rowid='"+obj2[j].rowid  +"'");
                }
            }
                  var rtn = ExecSql();
            if (rtn != "") {
               alert("保存失败，原因：\n\n" + rtn);
               }
               else{
                alert("保存成功！");
                dialog.close("ok");
            }
        }
        
    } else {
        alert(s);
        return;
    }
}

function isExist(){
    var title = txtTitle.GetText();
    var sql = "SELECT * FROM TP_Prj_Completion_All WHERE Title ='"+ title +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) {
        alert("项目完成情况及经费上报标题重复!");
        return false;
    } else{
        return true;
    }
}
