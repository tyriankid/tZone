﻿function _FormLoad() {
    cbState.SetSelectedIndex(0);
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    dialog.show("TP_Prj_Process_Inspection_Edit.aspx?type=view&rowid=" + gd.item("rowid"),570,550,function(s) {
            
        });
}

//查询
function Search(){
    var sql="select wfid,rowid,Title,dbo.clip(AppDep,':',1) AppDep"
    sql +=",case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' when 3 then '结束' end state";
    sql +=",dbo.clip(AppUser,':',1) AppUser,AppDate";
    sql += " from TP_Prj_Process_Inspection where AppUser = '" + uinfo + "'";
    
    if(txtTiitle.GetText().Trim() != ""){
        sql += " and Title like '%"+ txtTiitle.GetText().Trim() +"%'";
    }
    if(dbBegin.GetText() != ""){
        sql += " and AppDate >= '"+ dbBegin.GetText() +"'";
    }
    if(dbEnd.GetText() != ""){
        sql += " and AppDate <= '"+ dbEnd.GetText() +"'";
    }
    if(cbState.GetText().Trim() != "全部"){
        sql += " and state = '"+ cbState.GetValue().Trim() +"'";
    }
    sql += "order by AppDate Desc";
    //alert(sql);
    gd.Open(sql);
}

//重置
function ReSet(){
    txtTiitle.SetText("");
    dbBegin.SetText("");
    dbEnd.SetText("");
    cbState.SetSelectedIndex(0);
    Search();
}

//添加或编辑
function Add(f) {
    if (f == "New") {
        dialog.show("TP_Prj_Process_Inspection_Edit.aspx?type=add",570,550,function(s) {
            if(s == "OK") {
                gd.Refresh();
            }
        });
    } else {
        if(gd.RowIndex < 1){
            alert("请选择一行!");
            return;
        }
		if(gd.Item("wfid")!= ""){ 
			alert("流程已经启动,无法再做修改!");
			return ; 
		}
        dialog.show("TP_Prj_Process_Inspection_Edit.aspx?type=edit&rowid=" + gd.item("rowid"),570,550,function(s) {
            if(s == "OK") {
                gd.Refresh();
            }
        });
    }
}

function Delete() {
    if(gd.RowIndex < 1){
        alert("请选择一行!");
        return;
    }
    if(gd.Item("state") != "新建"){
        alert("已经启动流程的项目无法删除!");
        return;
    }

    if(!confirm("是否确认删除")) return;
    Sql.AddCmd("delete from TP_Prj_Process_Inspection where rowid = '" + gd.Item("rowid") + "'"); 
    Sql.AddCmd("delete from TP_Prj_Process_Info where PcsID = '" + gd.Item("rowid") + "'"); 
    Sql.AddCmd("delete from Base_FileList where objid = '" + gd.Item("rowid") + "'"); 
    ExecSql(function(s){
        if(s=="") {
            alert("删除成功!");
            gd.Refresh();
        } else {
            alert(s);
            return;
        }
    });
}

//启动
function Startflow(){
    if(gd.RowIndex < 1) {
        alert("请选择一行记录");
        return;
    }
    var sql2="select a.prjid from tp_prj_process_info a  right join "
    sql2 +="TP_Prj_Process_Inspection b on a.pcsid = b.rowid where b.rowid = '"+ gd.Item("rowid") +"' ";
    var oData2 = GetData(sql2) || [];
    if(oData2.length > 0)
        {
            for(var i = 0; i < oData2.length ; i++)
            {
                if(!canStartflow(oData2[i].prjid)) { return; };
            }
        }
    

    flow.StartFlow("TP_Prj_Process_Inspection",gd.Item("rowid"),function(wfid) {
        if(wfid.length == 32) {

            var sql="select a.prjid from tp_prj_process_info a  right join "
            sql +="TP_Prj_Process_Inspection b on a.pcsid = b.rowid where b.rowid = '"+ gd.Item("rowid") +"' ";
            var oData = GetData(sql) || [];
            if(oData.length > 0)
                {
                    for(var i = 0; i < oData.length ; i++)
                    {
                        //alert(oData[i].prjid);
                        //if(!canStartflow(oData[i].prjid)) { return; };
                        Sql.AddCmd("update tp_prj_baseinfo set prjstate = 7 where rowid='"+oData[i].prjid+"'");
                    }
                }
            
            Sql.AddCmd("update TP_Prj_Process_Inspection set state=1 where wfid = '" + wfid + "'");
            
            ExecSql(function(s){
                if(s === ""){
                    gd.Refresh();
                }
            });
        }
     });
}
//启动流程前的判断
function canStartflow (prjid) {
    var sql="select case prjstate when 1 then '立项中' when 3 then '实施中' when 5 then '上报中' ";
    sql += "when 7 then '检查中' when 9 then '终止中' when 10 then '已终止' ";
    sql += "when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 15 then '结题验收中' end prjstate";
    sql += " from tp_prj_baseinfo where rowid='"+ prjid +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0){  //如果prjstate在以上状态中,则不允许启动项目
        if(oData[0].prjstate == ""){
            return true;
        }
        alert("该项包含了"+oData[0].prjstate+"的项目,流程不能被启动!");
        return false;
    }
}

//流程图
function ViewFlowRun() {
    if(gd.RowIndex === 0){
        alert("请选择一行");
        return;
    }
    if (gd.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(gd.item("wfid"));
}
