﻿function _FormLoad() {
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Search(){
    var sql="SELECT rowid,prjname,prjid FROM prj_baseinfo where 1=1";
    if (txtPrjId.GetText() != "")
    {
        sql +=" and prjid like '%"+ txtPrjId.GetText().Trim() +"%'";
    }
    if (txtPrjName.GetText() != "")
    {
        sql +=" and prjname like '%"+ txtPrjName.GetText().Trim() +"%'";
    }
    gd.Open(sql);
}

function ReSet(){
    txtPrjId.SetText("");
    txtPrjName.SetText("");
}

function Okay(){
    if(gd.RowIndex<1)
    {
        alert("请选择一行!");
    }
    var obj = {prjid:gd.Item("rowid"),prjcode:gd.Item("prjid"),prjname:gd.Item("prjname")};
    dialog.close(obj);
}