﻿
var baseid="";
var tabname ="tp_prj_termination"; //表名
function _FormLoad() {
    cbPrjType.SetSelectedIndex(3);
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    AppEndDate.SetEnabled(false);
	btntxtPrjCode.SetEnabled(false);
    baseid = Req("wfid");
    if(baseid != ""){
        AppEndDate.SetEnabled(false);
        GetValues();
    }
    
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    var sql=[];
    if (obj.NodeID.indexOf("p003") > 0) {
        if (obj.SubmitOption === "不同意") {  
            sql.push("update TP_Prj_Termination set state = 2 where wfid = '" + obj.FlowID + "'");
        } else {
            sql.push("update TP_Prj_Termination set state = 3 where wfid = '" + obj.FlowID + "'");
            sql.push("update TP_Prj_BaseInfo set prjstate = 10 where prjcode = '" + btntxtPrjCode.GetText() + "'");
        }
    } else {
		if (obj.SubmitOption === "不同意") {  
            sql.push("update TP_Prj_Termination set state = 2 where wfid = '" + obj.FlowID + "'");
        }
	}
    flow.BSSQL = sql;
    return true;
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    

}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}




var prj3_S_Rowid="";
var prjType=0;
var prjCode="";
var prjName="";
var prjUser="";
var appDep="";


function GetValues(){
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?&type=add&rowid=" + baseid);
    }
}