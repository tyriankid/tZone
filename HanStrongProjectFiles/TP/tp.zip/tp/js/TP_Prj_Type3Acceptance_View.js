﻿function _FormLoad() {
    cbState.SetSelectedIndex(0);
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    dialog.show("TP_Prj_Type3Acceptance_Edit.aspx?type=view&rowid=" + gd.item("rowid"),620,680,function(s){
    });
}

function Search() {
    var sql = "select ReportFilePath,state,rowid,prjid,wfid,prjcode,prjname,dbo.clip(PrjUser,':',1) prjuser,prjstartdate,prjenddate,dbo.clip(appdep,':',1) appdep,appdate,";
    sql +="case state when 0 then '新建' when 1 then '审批中' when 2 then '退回修改' when 3 then '结束' end states";
    sql += " from TP_Prj_results_acceptance where 1=1";
    if(txtPrjCode.GetText().Trim() != ""){
        sql += "and prjcode like '%"+ txtPrjCode.GetText().Trim() +"%'";
    }
    if(txtPrjName.GetText().Trim() != ""){
        sql += "and prjname like '%"+ txtPrjName.GetText().Trim() +"%'";
    }
    if(cbState.GetText().Trim() != "全部"){
        sql += " and state = '"+ cbState.GetValue() +"'";
    }
    if(txtAccept1.GetText() != ""){
        sql += " and AppDate >= '"+ txtAccept1.GetText() +"'";
    }
    if(txtAccept2.GetText() != ""){
        sql += " and AppDate <= '"+ txtAccept2.GetText() +"'";
    }
    
    gd.Open(sql);
}

function Add() {
    dialog.show("TP_Prj_Type3Acceptance_Edit.aspx?type=add",620,680,function(s) {
        if(s == "ok"){gd.Refresh();}
    });
}

function Edit() {
    if(gd.RowIndex < 1){
        alert("请选择一行!");
        return;
    }
    if(gd.item("states") != "新建")
    {
        alert("流程状态为新建时才能被修改!");
        return;
    }
    dialog.show("TP_Prj_Type3Acceptance_Edit.aspx?type=edit&rowid=" + gd.item("rowid"),620,680,function(s) {
        if(s == "ok"){gd.Refresh();}
    });
}

//打印报表
function PrintReport(){
     if(gd.RowIndex<1){
        alert("请选择一行");
        return;
    }
    if (gd.Item("ReportFilePath") == "" || (gd.Item("state") >0  && gd.Item("state") <=3 )){
        //alert("a");
        ajax.run("TP_Prj_Report.aspx",{cmd:"Type3Acceptance",rowid:gd.Item("rowid")},function(o){
            //alert(o.split("<-->")[0]);
            //alert(o);
            if (o.split("<-->")[0] == "") {
                dialog.show("word.aspx?docid=" + gd.Item("rowid") + "&type=Type3Acceptance" ,800,600,function(s) {
                });   
            } else {
                alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
                return;
            }
        });
    } else {
        //alert("b");
        dialog.show("word.aspx?docid=" + gd.Item("rowid") + "&type=Type3Acceptance" ,800,600,function(s) {
        });
    }
}



function Delete(){
    var count= 0 ;  /*用于判断是否勾选了至少一项信息*/
    var rids="";    /*存放选中项的rowid*/
    var objstate="" ;   /*存放项目状态 如果不是"新建"则不能删除*/
    for(var i=1 ;i<=gd.RowCount() ;i++)
    {
        if(gd.RowChecked(i)==true)
        {
            count++;
            rids +="," + gd.item("rowid",i);
            objstate = gd.item("states",i);
            if(objstate!="新建"){
                alert("已经启动过的项目无法删除!");
                return;
            }
        }
    }
    if(count==0)
    {
        alert("请勾选要删除的项目!");
        return;
    }
    if(!confirm("是否确认删除")) return;
    rids=rids.substring(1); //把第一个"," 去掉
    Sql.AddCmd("delete from TP_Prj_Results_Acceptance where charindex(rowid,'"+ rids +"')>0"); //根据baseinfo表里的rowid删除项目信息
    
    ExecSql(function(s){
            if(s=="")
            {
                alert("删除成功!");
                gd.Refresh();
            }
            else
            {
                alert(s);
                return;
            }
        }
    );
}

//启动
function Startflow(){
        if(gd.RowIndex<1){
            alert("请选择一行记录");
            return;
        }
     if(!canStartflow(gd.Item("prjid"))){ return; }
     flow.StartFlow("tp_prj_results_acceptance",gd.Item("rowid"),function(wfid){
        if(wfid.length==32){
            var sql="update tp_prj_results_acceptance set state=1 where wfid='"+wfid+"'";
            var sql2="update tp_prj_baseinfo set prjstate=11 where rowid='"+ gd.Item("prjid") +"'";
            Sql.AddCmd(sql);
            Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s===""){
                    gd.Refresh();
                }
            });
        }
     });
}

//启动项目前的判断
function canStartflow (prjid) {
    var sql="select case prjstate when 1 then '立项中' when 3 then '实施中' when 5 then '上报中' ";
    sql += "when 7 then '检查中' when 9 then '终止中' when 10 then '已终止' ";
    sql += "when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 15 then '结题验收中' end prjstate";
    sql += " from tp_prj_baseinfo where rowid='"+ prjid +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0){  //如果prjstate在以上状态中,则不允许启动项目
        if(oData[0].prjstate == ""){
            return true;
        }
        alert("该项目状态为"+oData[0].prjstate+",不能被启动!");
        return false;
    }
}

//流程图
function ViewISOFlowRun() {
    if(gd.RowIndex === 0){
        alert("请选定要提交审批的记录");
        return;
    }
    if (gd.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(gd.item("wfid"));
}

function Reset() {
    txtPrjCode.SetText("");
    txtPrjName.SetText("");
    txtAccept1.SetText("");
    txtAccept2.SetText("");
    cbState.SetSelectedIndex(0);
    Search();
}


