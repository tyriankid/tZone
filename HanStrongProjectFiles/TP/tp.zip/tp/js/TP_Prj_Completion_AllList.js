﻿function _FormLoad() {
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//查询
function Search(){
    var sql="select rowid,Title,dbo.clip(AppDep,':',1) AppDep";
    sql +=",dbo.clip(AppUser,':',1) AppUser,AppDate,YearMonth";
    sql += ",(SELECT SUM(state) FROM TP_Prj_Completion_Request WHERE appuser IN (SELECT prjuser FROM TP_Prj_Request_Info WHERE hzrid=a.rowid) AND yearmonth=a.yearmonth) state from TP_Prj_Completion_All a where 1=1";
    
    if(txtTiitle.GetText().Trim() != ""){
        sql += " and Title like '%"+ txtTiitle.GetText().Trim() +"%'";
    }
    if(dbBegin.GetText() != ""){
        sql += " and AppDate >= '"+ dbBegin.GetText() +"'";
    }
    if(dbEnd.GetText() != ""){
        sql += " and AppDate <= '"+ dbEnd.GetText() +"'";
    }
    sql += "order by AppDate Desc";
    //alert(sql);
    jq.Open(sql);
}


//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
     dialog.show("TP_Prj_Completion_All_Edit.aspx?rowid="+jq.Item("rowid")+"&type=view",559,546,function(s) {
        
    });
}

function Add() {
    dialog.show("TP_Prj_Completion_All_Edit.aspx",559,546,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Edit(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
    if(jq.item("state")>0)
    {
        alert("已提交流程无法编辑");
        return;
    }
    dialog.show("TP_Prj_Completion_All_Edit.aspx?rowid="+jq.Item("rowid"),559,546,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Del(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
	if(jq.item("state")>0)
    {
        alert("已提交流程无法删除");
        return;
    }
    
    if(!confirm("是否确定删除?")) return;
     Sql.AddCmd("delete from TP_Prj_Completion_All where rowid='"+ jq.Item("rowid") +"'");
      Sql.AddCmd("delete from TP_Prj_Request_Info where hzrid='"+ jq.Item("rowid") +"'");
       Sql.AddCmd("delete from TP_Prj_Completion_Info where hzrid='"+ jq.Item("rowid") +"'");
    ExecSql(function(s){
        if(s=="")
        {
            alert("删除成功");
            jq.Refresh();
        }
        else
        {
            alert(s);
            return;
        }
    });

}
function ReSet(){
    txtTiitle.SetText("");
    dbBegin.SetText("");
    dbEnd.SetText("");
    Search();

}
function Excel()
{
    var sql="";
    var sqlwhere="";
       if(txtTiitle.GetText().Trim() != ""){
        sql += " and a.Title like '%"+ txtTiitle.GetText().Trim() +"%'";
    }
    if(dbBegin.GetText() != ""){
        sql += " and a.AppDate >= '"+ dbBegin.GetText() +"'";
    }
    if(dbEnd.GetText() != ""){
        sql += " and a.AppDate <= '"+ dbEnd.GetText() +"'";
    }
      sql="select a.prjyear,ROW_NUMBER() over (order by a.crttime) as atuoid,dbo.Clip(a.prjdep,':',1)prjdep,a.prjcode,a.prjname,dbo.Clip(a.prjuser,':',1)prjuser,b.prjmoney,b.purpose,a.completion from TP_Prj_Completion_Info a  INNER JOIN TP_Prj_Request_Info b ON a.hzrid=b.hzrid  where 1=1  ";
        sql += sqlwhere;
        _ExOption = {sql:sql, fldname:"prjyear,atuoid,prjdep,prjcode,prjname,prjuser,prjmoney,purpose,completion", fldesc:"年份,序号,部门,项目编号,项目名称,项目负责人,经费,用途,完成情况", fldict:"", xlsdesc:"项目进度及经费计划表"};
        ExportExcel(_ExOption);
}
//追加
function AddTo(){
      if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
     dialog.show("TP_Prj_Completion_All_Edit.aspx?rowid="+jq.Item("rowid")+"&type=addto",559,546,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
    
}