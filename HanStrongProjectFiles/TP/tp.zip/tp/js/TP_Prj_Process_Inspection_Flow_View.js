﻿function _FormLoad() {
    var sql = "select *,dbo.Clip(PrjUser,':',1) PrjUsers from TP_Prj_Process_Info where PcsID = '" + txtRowid.GetText() + "'";
    gd.Open(sql);

    txtOldTitle.SetText(txtTitle.GetText());
    txtUser.SetText($ONM(_txtUser.GetText()));
    txtDep.SetText($ONM(_txtDep.GetText()));

}

//流程保存操作调用的方法
function _SaveForm(obj) {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    var sql=[];
    if (obj.NodeID.indexOf("p003") > 0) {
        if (obj.SubmitOption === "不同意") {  
            sql.push("update TP_Prj_Process_Inspection set state = 2 where wfid = '" + obj.FlowID + "'");
        }
    }
    if (obj.NodeID.indexOf("p004") > 0) {
        if (obj.SubmitOption === "不同意") {  
            sql.push("update TP_Prj_Process_Inspection set state = 2 where wfid = '" + obj.FlowID + "'");
        } else {
            sql.push("update TP_Prj_Process_Inspection set state = 3 where wfid = '" + obj.FlowID + "'");
            for(var i = 1; i <= gd.RowCount(); i++) {
                sql.push("update TP_Prj_BaseInfo set prjstate = 8 where rowid = '" + gd.Item("PrjID", i) + "'");
            }
        }
    }
    flow.BSSQL = sql;
    return true;
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//单击一行
function gdClick() {
    
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
        var type = "add";
        if (Req("type") == "view") type = "view";
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=" + type + "&rowid=" + txtRowid.GetText());
    }
}

function Save() {
    gd.UptCell();
    for(var i = 1; i <= gd.RowCount(); i++) {
        //sql = ;
        Sql.AddCmd("update TP_Prj_Process_Info set Content = '" + gd.Item("Content", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set OldPlan = '" + gd.Item("OldPlan", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set MoneyUsed = '" + gd.Item("MoneyUsed", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
        Sql.AddCmd("update TP_Prj_Process_Info set NextPlan = '" + gd.Item("NextPlan", i) + "' where rowid = '" + gd.Item("rowid", i) + "'");
    }
    var rtn = ExecSql();
    if (rtn != "") {
       alert("保存失败，原因：\n\n" + rtn);
       return;
    }
}

function isExist(){
    var title = txtTitle.GetText();
    var sql = "SELECT * FROM TP_Prj_Process_Inspection WHERE Title ='"+ title +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) {
        alert("项目中期检查标题重复!");
        return false;
    } else{
        return true;
    }
}
