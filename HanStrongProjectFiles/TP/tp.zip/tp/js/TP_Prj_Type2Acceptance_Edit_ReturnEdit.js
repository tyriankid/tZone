﻿
var baseid = "";
function _FormLoad() {
    
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    btntxtPrjCode.SetEnabled(false);
    baseid=Req("wfid");
    if(baseid != ""){
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm() {
    Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.nodeid.indexOf("p002")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            var sql="update tp_prj_subject_acceptance set state = 1 where wfid='"+ baseid/*此时为wfid*/ +"'";
            ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
        }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
      
            ds.Update(Data); 
    
}

function Data(s){
    if(s=="")
    {
        //alert("保存成功");
    }
    else
    {
        alert(s);
        return;
    }
}

var prj2_S_Rowid="";
var prjCode="";
var prjName="";
var prjType=0;
function SelectPrj() {
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=1,2&type=ktacceptance",680,500,function(s){
        
        if(s.prjid=="" || s.prjid == null)
        {
            return;
        }
        prj2_S_Rowid=s.prjid;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjType=s.prjtype;

        if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
        else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
        else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
        else{cbPrjType.SetSelectedIndex(0);}  //type
        btntxtPrjCode.SetText(prjCode); //code
        txtPrjName.SetText(prjName);  //name
        txtPrjId.SetText(prj2_S_Rowid);  //prjid
    });
}

function GetValues() {
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
    var sql ="select prjtype,prjtypename from tp_prj_baseinfo where rowid = '"+ txtPrjId.GetText() +"'";
        
        var obj = GetData(sql)||[];
        if(obj.length > 0) {
            if(obj[0].prjtype == "1")
            {
                cbPrjType.SetSelectedIndex(1);
            }
            if(obj[0].prjtype == "2")
            {
                cbPrjType.SetSelectedIndex(2);
            }
        }
    cbPrjType.SetEnabled(false);
    
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText();
    var sql="SELECT prjcode FROM tp_prj_subject_acceptance WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}
