﻿function _FormLoad() {
    
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}
function Add(){
    jq.AddRow({
        ObjID:Req("objid"),
        Title:"",
        Model:"",
        Price:"0.00",
        Memo:""
    });
}
function Del(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
    jq.DelRow();
}
function Save(){
    jq.uptcell();
    var chk="";
	Sql.AddCmd("delete from TP_Prj_Budget_Detail where objid='"+ Req("objid") +"'");
    for(var i=1;i<=jq.RowCount();i++){
        if(jq.item("title",i)==""||jq.item("model",i)=="")
        {
            chk="No";
        }
        Sql.AddCmd("insert into TP_Prj_Budget_Detail(ObjID,Title,Model,Price,Memo)values('"+ jq.item("objid",i) +"','"+ jq.item("title",i) +"','"+ jq.item("model",i) +"',"+ jq.item("price",i)*100000/100000 +",'"+ jq.item("memo",i) +"')");
    }
    if(chk!="")
    {
        alert("请将信息帖写完整");
        return;
    }
    ExecSql(function(s){
        if(s=="")
        {
            alert("保存成功");
            dialog.close("ok");
        }
        else
        {
            alert(s);
            return;
        }
    });
}
