﻿function _FormLoad() {
    
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}
function Save(){
   var str="";
  for(var i=1;i<=jq.RowCount();i++)
  {
      if(jq.RowChecked(i))
    {
        str+=",";
        str+=jq.Item("ContractID",i);
        //str+="{'htno':'"+jq.Item("ContractID",i)+"'}";
    }
      
  }
      if(str=="")
    {
        alert("请至少选择一行");
        return;
    }
    str=str.substring(1);

    str=eval("([{'htno':'"+str+"'}])");
    dialog.close(str);    
}
function Query(){
	var sql="select * from ContractInfo where ContractSortID='"+ Req("sortid")+ "'";
	if(txtCode.GetText()!="")
	{
		sql+=" and ContractID like '%"+ txtCode.GetText() +"%'";
	}
	if(txtName.GetText()!="")
	{
		sql+=" and ContractName like '%"+ txtName.GetText() +"%'";
	}
	jq.Open(sql);
}
function ReSet(){
	txtCode.SetText("");
	txtName.SetText("");
	Query();
}