﻿function _FormLoad() {
    cbPrjType.SetSelectedIndex(0);
    Query();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

//载入查询
function Query(){
    var sql="SELECT state,a.rowid,dbo.clip(a.appdep,':',1) appdep,a.prjname,a.prjcode,dbo.clip(a.prjuser,':',1) prjuser,a.prjtypename, ";
    sql +="a.CooperationUnit,SUBSTRING(a.PrjContent,1,50) prjcontent,a.SelfMoney,a.SubsidizeMoney,a.prjstartdate,a.prjenddate, ";
    sql +="EntrustingParty = (select top 1 EntrustingParty from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime), ";
    sql +="ContractMeony = (select top 1 ContractMeony from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime), ";
    sql +="wfid,ReportFilePath,TakenMoney=(select top 1 (SelfMoney+SubsidizeMoney) - Balance from TP_Prj_Registration_Prices where prjid = a.rowid order by crttime) ";
    sql +="from tp_prj_baseinfo a where prjtype != '3'";
    if(txtPrjCode.GetText().Trim()!="")
    {
        sql += " and a.PrjCode like '%"+ txtPrjCode.GetText() +"%'";
    }
    if(txtPrjUser.GetText().Trim()!="")
    {
        sql += " and PrjUser like '%"+ txtPrjUser.GetText() +"%'";
    }
    if(txtCooperationUnit.GetText().Trim()!="")
    {
        sql += " and CooperationUnit like '%"+ txtCooperationUnit.GetText() +"%'";
    }
    if(txtPrjName.GetText().Trim()!="")
    {
        sql += " and a.PrjName like '%"+ txtPrjName.GetText() +"%'";
    }
    if(txtEntrustingParty.GetText().Trim()!="")
    {
        sql += " and (select top 1 EntrustingParty from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime) like '%"+ txtEntrustingParty.GetText() +"%'";
    }
    if(txtAppDep.GetText().Trim()!="")
    {
        sql += " and a.AppDep like '%"+ txtAppDep.GetText() +"%'";
    }
    if(txtContractMeony.GetText().Trim()!="")
    {
        sql += " and (select top 1 ContractMeony from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime) = "+ txtContractMeony.GetText() +" ";
    }
    if(txtSelfMoney.GetText().Trim()!="")
    {
        sql += " and a.SelfMoney = "+ txtSelfMoney.GetText() +" ";
    }
    if(txtSubsidizeMoney.GetText().Trim()!="")
    {
        sql += " and a.SubsidizeMoney = "+ txtSubsidizeMoney.GetText() +" ";
    }
    if(txtTakenMoney.GetText().Trim()!="")
    {
        sql += " and (select top 1 (SelfMoney+SubsidizeMoney) - Balance from TP_Prj_Registration_Prices where prjid = a.rowid order by crttime) = "+ txtTakenMoney.GetText() +" ";
    }
    if(SDate.GetText() != ""){
        sql += " and prjstartdate >= '"+ SDate.GetText() +"'";
    }
    if(EDate.GetText() != ""){
        sql += " and prjenddate <= '"+ EDate.GetText() +"'";
    }
    if(cbPrjType.GetText() != "全部"){
        sql += " and prjtype = '"+ cbPrjType.GetValue() +"'";
    }
    
    jq.Open(sql);
}

function Excel() {
    var sql="";
    var sqlwhere = "";
    var _ExOption = null;
    if(txtPrjCode.GetText().Trim()!="")
    {
        sqlwhere += " and a.PrjCode like '%"+ txtPrjCode.GetText() +"%'";
    }
    if(txtPrjUser.GetText().Trim()!="")
    {
        sqlwhere += " and PrjUser like '%"+ txtPrjUser.GetText() +"%'";
    }
    if(txtCooperationUnit.GetText().Trim()!="")
    {
        sqlwhere += " and CooperationUnit like '%"+ txtCooperationUnit.GetText() +"%'";
    }
    if(txtPrjName.GetText().Trim()!="")
    {
        sqlwhere += " and a.PrjName like '%"+ txtPrjName.GetText() +"%'";
    }
    if(txtEntrustingParty.GetText().Trim()!="")
    {
        sqlwhere += " and (select top 1 EntrustingParty from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime) like '%"+ txtEntrustingParty.GetText() +"%'";
    }
    if(txtAppDep.GetText().Trim()!="")
    {
        sqlwhere += " and a.AppDep like '%"+ txtAppDep.GetText() +"%'";
    }
    if(txtContractMeony.GetText().Trim()!="")
    {
        sqlwhere += " and (select top 1 ContractMeony from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime) = "+ txtContractMeony.GetText() +" ";
    }
    if(txtSelfMoney.GetText().Trim()!="")
    {
        sqlwhere += " and a.SelfMoney = "+ txtSelfMoney.GetText() +" ";
    }
    if(txtSubsidizeMoney.GetText().Trim()!="")
    {
        sqlwhere += " and a.SubsidizeMoney = "+ txtSubsidizeMoney.GetText() +" ";
    }
    if(txtTakenMoney.GetText().Trim()!="")
    {
        sqlwhere += " and (select top 1 (SelfMoney+SubsidizeMoney) - Balance from TP_Prj_Registration_Prices where prjid = a.rowid order by crttime) = "+ txtTakenMoney.GetText() +" ";
    }
    if(SDate.GetText() != ""){
        sqlwhere += " and prjstartdate >= '"+ SDate.GetText() +"'";
    }
    if(EDate.GetText() != ""){
        sqlwhere += " and prjenddate <= '"+ EDate.GetText() +"'";
    }
    if(cbPrjType.GetText() != "全部"){
        sqlwhere += " and prjtype = '"+ cbPrjType.GetValue() +"'";
    }
    sql ="select dbo.clip(appdep,':',1) appdep,prjtypename,prjname,prjcode,dbo.clip(prjuser,':',1) prjuser,"
    sql +="CooperationUnit,SUBSTRING(PrjContent,1,50) prjcontent,prjstartdate,prjenddate,SelfMoney,SubsidizeMoney,";
    sql +="EntrustingParty = (select top 1 EntrustingParty from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime), ";
    sql +="ContractMeony = (select top 1 ContractMeony from TP_Prj_Contract_Info where prjid = a.rowid order by a.crttime), ";
    sql +="TakenMoney=(select top 1 (SelfMoney+SubsidizeMoney) - Balance from TP_Prj_Registration_Prices where prjid = a.rowid order by crttime) ";
    sql +="from tp_prj_baseinfo a where prjtype != '3' ";
    sql += sqlwhere;
    _ExOption = {sql:sql, fldname:"appdep,prjtypename,prjname,prjcode,prjuser,cooperationunit,prjcontent,prjstartdate,prjenddate,selfmoney,subsidizemoney,entrustingparty,contractmeony,takenmoney", fldesc:"申请部门,项目类别,项目名称,项目编号,项目负责人,合作单位,主要内容,开始日期,结束日期,自筹经费,外拨经费,外委单位,外委合同额,已使用经费", fldict:"", xlsdesc:"一\二类科技项目信息表"};
    ExportExcel(_ExOption);
}

function Reset() {
    txtPrjCode.SetText("");
    txtPrjUser.SetText("");
    txtCooperationUnit.SetText("");
    txtPrjName.SetText("");
    txtEntrustingParty.SetText("");
    txtAppDep.SetText("");
    txtContractMeony.SetText("");
    txtSelfMoney.SetText("");
    txtSubsidizeMoney.SetText("");
    txtTakenMoney.SetText("");
    SDate.SetText("");
    EDate.SetText("");
    cbPrjType.SetSelectedIndex(0);
    Query();
}

function Detail() {
    if(jq.RowIndex<1)
    {
      alert("请选择一行");
      return;
    }
    dialog.show("TP_Prj_TotalSearch_Detail.aspx?rowid=" + jq.item("rowid"),1050,700,function(s) {
        
    });
}