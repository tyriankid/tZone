﻿
var baseid = "";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(0); //默认1,2类
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    baseid=Req("rowid");
    if(Req("type") == "add")
    {
        baseid = GUID();
        txtAppDate.SetText(GetDate("YYYY-MM-DD"));
        txtBaseId.SetText(baseid);
        _txtAppUser.SetText(uinfo);         //当前用户为验收申请人
        txtAppUser.SetText(uname);
        var sql="select bussiness_dep from hr_staff_details where staff_rowid = '"+ uid +"'";
        var oData = GetData(sql) || [];
        if(oData.length > 0)
        {
            _txtAppDep.SetText(oData[0].bussiness_dep);       //当前用户所在部门为验收申请部门
            txtAppDep.SetText($ONM(oData[0].bussiness_dep));
        }
    }
    else if(Req("type") == "edit")
    {
        GetValues();
       
    }
    else if(Req("type") == "view")
    {
        GetValues();
        btnSave.SetVisible(false);
        txtTitle.SetEnabled(false);
        btntxtPrjCode.SetEnabled(false);
        txtAppDate.SetEnabled(false);
        txaMemo.SetEnabled(false);
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
    if(Req("type") == "add"){
        if(isPrjCodeExist()){ 
            ds.Insert(Data); 
        }
    
    }
    else if(Req("type") == "edit"){
        ds.Update(Data);
    }
}

function Data(s){
    if(s=="")
    {
        alert("保存成功");
        dialog.close("ok");
    }
    else
    {
        alert(s);
        return;
    }
}

var prj2_S_Rowid="";
var prjCode="";
var prjName="";
var prjType=0;
function SelectPrj() {
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=1,2&type=ktacceptance",680,500,function(s){
        prj2_S_Rowid=s.prjid;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjType=s.prjtype;

        if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
        else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
        else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
        else{cbPrjType.SetSelectedIndex(0);}  //type
        btntxtPrjCode.SetText(prjCode); //code
        txtPrjName.SetText(prjName);  //name
        txtPrjId.SetText(prj2_S_Rowid);  //prjid
    });
}

function GetValues() {
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
    var sql ="select prjtype,prjtypename from tp_prj_baseinfo where rowid = '"+ txtPrjId.GetText() +"'";
        
        var obj = GetData(sql)||[];
        if(obj.length > 0) {
            if(obj[0].prjtype == "1")
            {
                cbPrjType.SetSelectedIndex(1);
            }
            if(obj[0].prjtype == "2")
            {
                cbPrjType.SetSelectedIndex(2);
            }
        }
    cbPrjType.SetEnabled(false);
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText();
    var sql="SELECT prjcode FROM tp_prj_subject_acceptance WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}
