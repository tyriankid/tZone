﻿function _FormLoad() {
   
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Query(){
    var sql="select *,dbo.Clip(PrjUser,':',1)PrjUsers,dbo.Clip(AppDep,':',1)AppDeps,case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' else '结束' end states,case prjstate when 0 then '新建' when 1 then '立项中' when 2 then '已立项' when 3 then '实施中' when 4 then '已实施' when 5 then '上报中' when 6 then '已上报' when 7 then '检查中' when 8 then '已检查' when 9 then '终止中' when 10 then '已终止' when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 14 then '课题验收完成' when 15 then '结题验收中' else '结题验收完成' end prjstates from TP_Prj_BaseInfo where  prjtype<>3 and state=3 and prjstate=2";
    if(txtbh.GetText()!="")
    {
        sql+="and PrjCode like '%"+ txtbh.GetText() +"%'";
    }
    if(txtmc.GetText()!="")
    {
        sql+="and PrjName like '%"+ txtmc.GetText() +"%'";
    }
    
    //alert(sql);
    jq.Open(sql);
}

function ReSet(){
    txtbh.SetText("");
    txtmc.SetText("");
    Query();
}
function BtnOk(){
     var str="";
      if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
     str+=",";
     str+="{'rowid':'"+jq.Item("rowid")+"'}";
    str=str.substring(1);
    str=eval("(["+str+"])");
    dialog.close(str);
}