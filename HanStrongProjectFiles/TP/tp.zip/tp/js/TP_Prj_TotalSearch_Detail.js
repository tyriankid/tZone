﻿function _FormLoad() {
    txtAppDep.SetText($ONM(txtAppDep.GetText()));
    txtPrjUser.SetText($ONM(txtPrjUser.GetText()));
    txaParticipants.SetText($ONM(txaParticipants.GetText()));
    PrjStart();
    PrjPlan();
    PrjCompletion();
    PrjProcess();
    PrjTermination();
    PrjSubjectAcceptance();
    PrjFinalAcceptance();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    if(oGrid == jqStart){
        dialog.show("TP_Prj_BaseInfo_View.aspx?rowid="+jqStart.Item("rowid"),1040,502,function(s) {  });
    }
    if(oGrid == jqPlan){
        dialog.show("TP_Prj_Planning_Info_View.aspx?rowid="+jqPlan.Item("rowid"),1040,502,function(s) {  });
    }
    if(oGrid == jqFinalAcceptance){
        dialog.show("TP_Prj_Type2FinalAcceptance_Edit.aspx?type=view&rowid=" + jqFinalAcceptance.item("rowid"),620,680,function(s) {  });
    }
}

//jq立项信息载入
function PrjStart() {
        var sql="select *,dbo.Clip(PrjUser,':',1)PrjUsers,dbo.Clip(AppDep,':',1)AppDeps, ";
        sql +="case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' else '结束' end states, ";
        sql +="case prjstate when 0 then '新建' when 1 then '立项中' when 2 then '已立项' when 3 then '实施中' when 4 then '已实施' when 5 then'上报中' ";
        sql +="when 6 then '已上报' when 7 then '检查中' when 8 then '已检查' when 9 then '终止中' when 10 then '已终止' when 11 then '验收中' ";
        sql +="when 12 then '验收完成' when 13 then '课题验收中' when 14 then '课题验收完成' when 15 then '结题验收中' when 16 then '结题验收完成' "; 
        sql +="end prjstates from TP_Prj_BaseInfo where  rowid = '"+ Req("rowid") +"'";

        jqStart.Open(sql);
}

//jq项目实施信息载入
function PrjPlan() {
    var sql="select *,dbo.Clip(PrjUser,':',1)PrjUsers,dbo.Clip(AppDep,':',1)AppDeps,case state when 0 then '新建' when 1 then '审批中' ";
    sql += "when 2 then '打回修改' else '结束' end states from TP_Prj_Planning_Info where  prjid = '"+ Req("rowid")  +"'";

    jqPlan.Open(sql);
}

//项目经费上报信息载入
function PrjCompletion() {

}

//项目中期检查信息载入
function PrjProcess() {
    var sql = "select *,dbo.Clip(PrjUser, ':', 1) PrjUsers from TP_Prj_Process_Info where PrjId = '" + Req("rowid") + "'";
    jqProcess.Open(sql);
}

//项目终止信息载入
function PrjTermination() {
    var sql = "select a.prjid,a.wfid,a.rowid,a.PrjCode,a.PrjName,dbo.clip(a.appdep,':',1) appdep"
    sql += ",case a.state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' when 3 then '结束' end state";
    sql += ",dbo.clip(b.PrjUser,':',1) prjuser,a.AppDate";
    sql += " from TP_Prj_Termination a left join tp_prj_baseinfo b on a.prjid = b.rowid where b.PrjType IN (1,2) and b.rowid = '"+ Req("rowid") +"'";
    jqTermination.Open(sql);
}

//项目课题验收信息载入
function PrjSubjectAcceptance() {
    var sql = "select *,dbo.clip(PrjUser,':',1) PrjUsers,dbo.clip(appdep,':',1) appdeps,dbo.clip(appUser,':',1) appUsers,";
    sql += "case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' else '结束' end states ";
    sql += "from tp_prj_subject_acceptance where prjid = '"+ Req("rowid") +"'";
    jqSubjectAcceptance.Open(sql);
}

//项目结题验收信息载入
function PrjFinalAcceptance() {
    var sql ="select ReportFilePath,state,rowid,prjid,wfid,prjcode,prjname,dbo.clip(prjuser,':',1) prjuser,prjstartdate,prjenddate,appaddress,appdate,";
    sql +=   "case state when 0 then '新建' when 1 then '审批中' when 2 then '退回修改' when 3 then '结束' end states ";
    sql +=   "from TP_Prj_Final_Acceptance where prjid = '"+ Req("rowid") +"' ";
    jqFinalAcceptance.Open(sql);
}