﻿
function _FormLoad() {
    init();
    
    
}
var tabname ="tp_prj_baseinfo"; //表名
var prjcode ="" ;//该项目选用的工程code
var prjid= "";    //该项目选用的工程id "SELECT rowid FROM prj_baseinfo"
var prjname= "";//该项目选用的工程name
var baseid= ""; //该项目id
var prjNo="";//存储当前项目编号,用来在判断是否已经存在
//流程保存操作调用的方法
function _SaveForm() {
    

}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    //alert(obj.FlowID+" "+obj.sopt+" "+obj.nodeid);
    //alert(Req("nid")+" "+obj.SubmitOption);
    var sql =[];
    
    
    if(obj.SubmitOption != "打回修改")
    {
        if(Req("nid").indexOf("p001")>0 && obj.SubmitOption != "不同意立项") //专业组(项目专业组组长)
        {
            sql.push("update TP_Prj_BaseInfo set MajGroupUser='"+ uinfo +"',MajGroupDate='"+S.date.day+"',MajGroupIdea={IDEA} where wfid='"+obj.FlowID+"'");
            
        }
        if(Req("nid").indexOf("p002")>0 && obj.SubmitOption != "不同意立项") //分公司主工(项目部门主任工程师)
        {
            sql.push("update TP_Prj_BaseInfo set BranchUser='"+ uinfo +"',BranchDate='"+S.date.day+"',BranchIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }
        if(Req("nid").indexOf("p003")>0 && obj.SubmitOption != "不同意立项") //分管总工(项目部门分管总工)
        {
            sql.push("update TP_Prj_BaseInfo set ChargeUser='"+ uinfo +"',ChargeDate='"+S.date.day+"',ChargeIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }
        flow.BSSQL = sql;
        //alert(sql);
        return true;
    }
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
    if(obj.sopt != "打回修改")
    {
        
        if(obj.nodeid.indexOf("p003")>0 || obj.sopt == "不同意立项") 
        {
           sChange(tabname,3);  //state=3[结束]

           if(obj.sopt != "不同意立项") { 
                   
                psChange(tabname,3,2);
           }
           else {
                psChange(tabname,3,17);
           }
        }
        else if(obj.nodeid.indexOf("p004")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            sChange(tabname,1);  //state=1[审核中]
        }
        
        
    }
    else //打回修改
    {
        sChange(tabname,2);  //state=2[打回修改]
    }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}


function psChange(tablename,state,pstate) {
    var sql2="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    var sql ="update "+ tablename +" set prjstate = "+ pstate +" where wfid='"+ baseid +"'"; //更改项目状态为2[已立项]
    
    Sql.AddCmd(sql);
    Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function sChange(tablename,state) {
    var sql="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    
    ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}


//页面载入方法
function init(){
    txtPrjType.SetText("3");
    txtPrjTypeName.SetText("三类");
    btntxtboxprjname.SetEnabled(false);
    baseid = Req("wfid");
    tbPrjNum.SetEnabled(false);
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=Tp_prj_baseinfo&col=PrjContent&rowid="+txtrowidDs1.GetText());
     if(baseid != "")
    {
        btnChoicePeople.SetVisible(false);
        tbPrjNum.SetEnabled(false);
        tbPrjName.SetEnabled(false);
        txaChosenPeople.SetEnabled(false);
        btntxtboxprjuser.SetEnabled(false);
        tbZhuanye.SetEnabled(false);
        btntxtboxappbumen.SetEnabled(false);
        Date1.SetEnabled(false);
        DateStart.SetEnabled(false);
        DateEnd.SetEnabled(false);
        btntxtboxprjname.SetEnabled(false);
        //mtextbox2.SetEnabled(false);
        checkIsSC.SetEnabled(false);
        GetValues();
    }
}

function GetValues(){
        /*如果是编辑or查看模式,工程项目信息必须根据当前项目的rowid来获得*/
        tbPrjNum.SetEnabled(false); /*不允许更改项目编号*/
        /*根据隐藏控件绑定的ds字段来在相应的控件里显示出相应的数据 txaChosenPeople btntxtboxappbumen btntxtboxprjuser*/
        txaChosenPeople.SetText($ONM(_txaChosenPeople.GetText().Trim()));
        btntxtboxappbumen.SetText($ONM(_btntxtboxappbumen.GetText().Trim()));
        btntxtboxprjuser.SetText($ONM(_btntxtboxprjuser.GetText().Trim()));
        /*
        var sql="SELECT projectid,projectcode,projectname FROM tp_prj_relation WHERE prjid = ";
        sql +="(SELECT rowid FROM TP_Prj_BaseInfo WHERE wfid = '"+ baseid +"')";
        */
        var sql="SELECT projectid,projectcode,projectname FROM tp_prj_relation WHERE prjid = '"+ txtrowidDs1.GetText() +"'";
        var oData= GetData(sql) || [];
        if(oData.length > 0){       
            //如果当前的项目id在关系表tp_prj_relation可以查出消息,表示这个项目是工程项目
            //checkIsSC.SetChecked(true);
            //btntxtboxprjname.SetEnabled(true);
            prjcode=oData[0].projectcode;
            prjname=oData[0].projectname;
            prjid=oData[0].projectid;
            btntxtboxprjname.SetText(prjname);
        }
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
    }
}



