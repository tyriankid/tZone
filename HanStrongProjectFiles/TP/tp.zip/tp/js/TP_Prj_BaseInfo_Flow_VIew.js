﻿function _FormLoad() {
    if(Req("wfid")=="")
    {
                
        appdate.SetText(S.date.day);
        _appdep.SetText(GetRootDep().id+":"+GetRootDep().name);
        appdep.SetText(GetRootDep().name);
        textbox7.SetText(0);
        textbox8.SetText(0);
        textbox9.SetText(0);
        textbox10.SetText(0);
        textbox11.SetText(0);    
        txtrid.SetText(S.guid);
        combox1.SetSelectedIndex(0);
        textbox15.SetText(0);
        textbox16.SetText(0);
        textbox17.SetText(0);
        SelecPrjType();
    }
    else
    {
        txtfzr.SetText($ONM(_txtfzr.GetText()));
        appdep.SetText($ONM(_appdep.GetText()));
        txtworkplace.SetText($ONM(_txtworkplace.GetText()));
        if(_prjType.GetText()!="")
        {
            SetPrjType();
        }
        jq1.Open("SELECT * FROM ContractInfo WHERE  ContractID IN (SELECT ContractID FROM TP_Prj_Contract_Info WHERE PrjID='"+ txtrid.GetText() +"')");
        jq2.Open("select * from TP_Prj_Planning_Progress where objid='"+ txtrid.GetText() +"'");
        jq3.Open("select rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID,isPrjFzr from TP_Prj_Players_Info where objid='"+ txtrid.GetText() +"'");
    }
    jq4.Open("select  b.rowid,a.title coursetitle,isnull(b.TotalMoney,'0.00')TotalMoney,'<input id=''Text1''  value='+CAST(isnull(b.SubsidizeMoney,'0.00') as VARCHAR(20))+' type=''text'' onchange=''qmountChange(this)''  style=''width:95%'' />'SubsidizeMoney,'<input id=''Text2''  value='+CAST(isnull(b.SelfMoney,'0.00') as VARCHAR(20))+' type=''text'' onchange=''qmountChange(this)''  style=''width:95%'' />'SelfMoney,b.memo  from (select * from TP_Prj_Budget_info where [type]=1) a left join (select * from TP_Prj_Appropriation_Budget where objid='"+ txtrid.GetText() +"') b on a.title=b.CourseTitle");
    SetControl();
    
}
var tablist = [false,false,false,false,false,false,false,false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index === 1) {
      $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=view&tbl=TP_Prj_Content&col=PrjContent&rowid="+txtrid.GetText());
    }
    if (e.tab.index === 2) {
      $("#iframe3").attr("src","../tp/Tp_InsertRom.aspx?type=view&tbl=TP_Prj_Content&col=PrjBasis&rowid="+txtrid.GetText());
    }
    if (e.tab.index === 3) {
      $("#iframe4").attr("src","../tp/Tp_InsertRom.aspx?type=view&tbl=TP_Prj_Content&col=PrjTarget&rowid="+txtrid.GetText());
    }
    if (e.tab.index === 4) {
      $("#iframe5").attr("src","../tp/Tp_InsertRom.aspx?type=view&tbl=TP_Prj_Content&col=PrjMethod&rowid="+txtrid.GetText());
    }
    if (e.tab.index === 5) {
      $("#iframe6").attr("src","../tp/Tp_InsertRom.aspx?type=view&tbl=TP_Prj_Content&col=PrjPostulate&rowid="+txtrid.GetText());
    }
    if (e.tab.index === 9) {
      $("#iframe1").attr("src","../tp/HT_UpFile.aspx?&type=view&rowid="+txtrid.GetText());
    }
}
function SetControl(){
    button1.SetEnabled(false);
    combox1.SetEnabled(false);
    txtfzr.SetEnabled(false);
}
//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
      var sql=[];
       if(Req("nid").indexOf("p006")>0){  
                 if(obj.SubmitOption==="立项")
                 {
                sql.push("update TP_Prj_BaseInfo set state=3,prjstate=2,LeaderUser='"+ uinfo +"',LeaderDate='"+S.date.day+"',LeaderIdea={IDEA} where wfid='"+obj.FlowID+"'");
                }
                 if(obj.SubmitOption==="不立项")
                 {
                    sql.push("update TP_Prj_BaseInfo set state=3,prjstate=17,LeaderUser='"+ uinfo +"',LeaderDate='"+S.date.day+"',LeaderIdea={IDEA} where wfid='"+obj.FlowID+"'");
                 }
                 if(obj.SubmitOption==="打回修改")
                 {
                     sql.push("update TP_Prj_BaseInfo set state=2 where wfid='"+obj.FlowID+"'");
                 }
        }
        if(Req("nid").indexOf("p000")>0)
        {
             if(obj.SubmitOption==="不通过"){       
                sql.push("update TP_Prj_BaseInfo set state=2 where wfid='"+obj.FlowID+"'");
            }
            else
            {
                sql.push("update TP_Prj_BaseInfo set ComDepUser='"+ uinfo +"',ComDepDate='"+S.date.day+"',ComDetIdea={IDEA} where wfid='"+obj.FlowID+"'");
            }
        }
        if(Req("nid").indexOf("p005")>0)
        {
           if(obj.SubmitOption==="通过"){
               sql.push("update TP_Prj_BaseInfo set QSHEUser='"+ uinfo +"',QSHEDate='"+S.date.day+"',QSHEIdea={IDEA} where wfid='"+obj.FlowID+"'");
            }
        }

        flow.BSSQL = sql;
        return true;
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
     if(Cmd==="浏览" && oGrid===jq1)
   {
    //dialog.show("Default.aspx?rowid=" + jq1.Item("rowid") + "&filepath="+escape(jq1.Item("filename")),1050,700,function(s){});    
    dialog.show("ht_ContractInfo_Edit.aspx?flag="+jq1.Item("rowid")+"&act=view",652,643,function(s){
        
      });
   }
}
//通过负责人查询相关信息
function FzrInfo(){
    var sql="select staff_sex,age,bussiness_dep,groupname,title from HR_Staff_Details where staff_rowid='"+ $OID(_txtfzr.GetText()) +"'";
    var obj=GetData(sql)||[];
    if(obj.length>0)
    {
        txtworkplace.SetText($ONM(obj[0].bussiness_dep));
        _txtworkplace.SetText(obj[0].bussiness_dep);
        textbox4.SetText(obj[0].age);
        textbox5.SetText(obj[0].staff_sex);
        if(obj[0].GroupName!="")
        {
            textbox19.SetText($ONM(obj[0].groupname));
        }
        textbox6.SetText(obj[0].title);
    }
}
//选择负责人
function SelectFzr(){
     var str= SelObject({type:"u",selcount:1,modal:"div",ctrl:"txtfzr"},function(str){
     if(str.length>0)
     {
        FzrInfo();
     }
     });
}
//选择项目分类
function SelectPrjType(){
    var strType="";
    if(checkbox1.GetChecked())
    {
        strType+=","+checkbox1.GetText();
    }
    if(checkbox2.GetChecked())
    {
        strType+=","+checkbox2.GetText();
    }
    if(checkbox3.GetChecked())
    {
        strType+=","+checkbox3.GetText();
    }
    if(checkbox4.GetChecked())
    {
        strType+=","+checkbox4.GetText();
    }
    if(checkbox5.GetChecked())
    {
        strType+=","+checkbox5.GetText();
    }
    /*
    if(checkbox6.GetChecked())
    {
        strType+=","+checkbox6.GetText();
    }
    if(checkbox7.GetChecked())
    {
        strType+=","+checkbox7.GetText();
    }
    if(checkbox8.GetChecked())
    {
        strType+=","+checkbox8.GetText();
    }
    */
    strType=strType.substring(1);
    _prjType.SetText(strType);
}
function SetPrjType(){
    var tot=_prjType.GetText();
     if(tot.indexOf(checkbox1.GetText())>-1)
    {
        checkbox1.SetChecked(true);
    }
    if(tot.indexOf(checkbox2.GetText())>-1)
    {
        checkbox2.SetChecked(true);
    }
    if(tot.indexOf(checkbox3.GetText())>-1)
    {
        checkbox3.SetChecked(true);
    }
    if(tot.indexOf(checkbox4.GetText())>-1)
    {
        checkbox4.SetChecked(true);
    }
    if(tot.indexOf(checkbox5.GetText())>-1)
    {
        checkbox5.SetChecked(true);
    }
    /*
    if(tot.indexOf(checkbox6.GetText())>-1)
    {
        checkbox6.SetChecked(true);
    }
    if(tot.indexOf(checkbox7.GetText())>-1)
    {
        checkbox7.SetChecked(true);
    }
    if(tot.indexOf(checkbox8.GetText())>-1)
    {
        checkbox8.SetChecked(true);
    }
    */
} 
//项目人数
function TotalUsers(){
    var a=textbox8.GetText()-0;
    var b=textbox9.GetText()-0;
    var c=textbox10.GetText()-0;
    var d=textbox11.GetText()-0;
    var tot=a*1+b*1+c*1+d*1;
    if(CheckNum(tot)!="ok")
    {
        alert("人数请填写正整数");
        return;
    }
    textbox7.SetText(tot);
}
//选择合同
function ConSelect(){
    dialog.show("TP_Prj_Contract_Select.aspx?sortid=E4EDBFB4869B4251B68DA1B900F53D4A",864,446,function(s){
    if(s.length>0&&s!="_null")
    {
        jq1.Open("SELECT * FROM ContractInfo WHERE CHARINDEX(ContractID,'"+ s[0].htno +"')>0 OR ContractID IN (SELECT ContractID FROM TP_Prj_Contract_Info WHERE PrjID='"+ txtrid.GetText() +"')");
    }
    });
}
//项目计划新建
function PrjPlanAdd(){
    if(datebox3.GetText()==""||datebox4.GetText()==""||mtextbox1.GetText()=="")
    {
        alert("请填写完整信息再保存");
        return;
    }
    var txtcon=mtextbox1.GetText();
    txtcon=txtcon.Replace("'","‘");
    var sql="insert into TP_Prj_Plan_Status(prjid,PlanContent,PlanStartDate,PlanEndDate,Executor,ExecDep)value('"+ txtrid.GetText() +"','"+ txtcon +"','"+ datebox3.GetText() +"','"+ datebox4.GetText() +"','"+ uinfo +"','"+ _appdep.GetText() +"')";
    Sql.AddCmd(sql);
    ExecSql(function(s){
        if(s=="")
        {
            alert("保存成功");
            datebox3.SetText("");
            datebox4.SetText("");
            mtextbox1.SetText("");
        }
        else
        {
            alert(s);
            return;
        }
    });

}  
//项目计划修改
function PrjPlanEdit(){
    if(jq2.RowIndex<1)
    {
        alert("请选择需要修改的信息");
        return;
    }
    var txtcon=mtextbox1.GetText();
    txtcon=txtcon.Replace("'","‘");
    var sql="update TP_Prj_Plan_Status set PlanContent='"+ txtcon +"',PlanStartDate='"+ datebox3.GetText() +"',PlanEndDate='"+ datebox4.GetText() +"' where rowid='"+ jq2.item("rowid") +"'";
    Sql.AddCmd(sql);
    ExecSql(function(s){
        if(s=="")
        {
            alert("修改成功");
            datebox3.SetText("");
            datebox4.SetText("");
            mtextbox1.SetText("");
        }
        else
        {
            alert(s);
            return;
        }
    });

}
//修改计划日期时
function OnChangeDate(){
    if(datebox3.GetText()>datebox4.GetText())
    {
        alert("开始时间不能大于结束时间");
        return;
    }
}
//选择成员
function SelectMeber(){
     var users="";
     var str= SelObject({type:"u",selcount:0,modal:"div"},function(str){
        if(str.length>0)
        {
            for(var i=0;i<str.length;i++)
            {
                users+=","+str[i].id;
            }
            //rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID
         var sql="SELECT dbo.GetGUID() rowid,staff_name username,age,dbo.clip(current_position,':',1) Position,title Qualification,case groupname when '' then '' else substring(dbo.clip(groupname,':',1),0,len(dbo.clip(groupname,':',1))-1) end Major,''DivisionScope,staff_rowid userid from HR_Staff_Details where CHARINDEX(staff_rowid,'"+ users +"')>0";
         sql+="union all select rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID from TP_Prj_Players_Status where PrjID='"+ txtrid.GetText() +"'";
         jq3.Open(sql);
        }
     });
}
function Save(){
    
    if(CheckSave()!="ok")
    {
        return;
    }
    var objjq = $("#jq4_grid").find("tr");
    var conmoney=0;
    Sql.AddCmd("delete from TP_Prj_Contract_Info where prjid='"+ txtrid.GetText() +"'");
    Sql.AddCmd("delete from TP_Prj_Players_Status where prjid='"+ txtrid.GetText() +"'");
    Sql.AddCmd("delete from TP_Prj_Budget_Status where PrjID='"+ txtrid.GetText() +"'");
    jq1.uptcell();
    for(var i=1;i<=jq1.RowCount();i++)
    {
        if(jq1.item("ContractMeony",i)!="") conmoney=jq1.item("ContractMeony",i);
        Sql.AddCmd("insert into TP_Prj_Contract_Info(PrjID,ContractID,ContractName,ContractMeony,EntrustingParty)values('"+ txtrid.GetText() +"','"+ jq1.item("ContractID",i) +"','"+ jq1.item("ContractName",i) +"',"+ conmoney +",'"+ jq1.item("EntrustingParty",i) +"')");
    }
    jq3.uptcell();
    for(var j=1;j<=jq3.RowCount();i++)
    {
        Sql.AddCmd("insert into TP_Prj_Players_Status(PrjID,UserID,UserName,Age,Position,Qualification,Major,DivisionScope)values('"+ txtrid.GetText() +"','"+ jq3.item("UserID",j) +"','"+  jq3.item("username",j) +"',isnull('"+ jq3.item("age",j) +"',0),'"+  jq3.item("Position",j) +"','"+ jq3.item("Qualification",j) +"','"+ jq3.item("Major",j) +"','"+ jq3.item("DivisionScope",j) +"')");
    }
    jq4.uptcell();
    for(var k=1;k<=jq4.RowCount();k++)
    {
         var budget1 = objjq.eq(k).find("td").eq(3).find("input").eq(0).val();
         var budget2 = objjq.eq(k).find("td").eq(4).find("input").eq(0).val();
         Sql.AddCmd("insert into TP_Prj_Budget_Status(PrjID,CourseTitle,SubsidizeMoney,SelfMoney,TotalMoney,Memo)values('"+ txtrid.GetText() +"','"+ jq4.item("CourseTitle",k) +"',"+ budget1 +","+ budget2 +","+ jq4.item("TotalMoney",k) +",'"+ jq4.item("memo",k) +"')");
    }
    ExecSql(function(s){
        if(s!="")
        {
            alert(s);
            return;
        }
        else
        {
            if(Req("rowid")=="")
            {
                ds2.Insert(Data);
            }
            else
            {
                ds2.Update(Data);
            }
        }
    });

}
function Data(s){
    if(s=="")
    {
        alert("保存成功");
    }
    else
    {
        alert(s);
        return;
    }
}
function CheckSave(){
    if(txtfzr.GetText()=="")
    {
        alert("请选择负责人");
        return "no";
    }
    if(datebox1.GetText()==""||datebox2.GetText()=="")
    {
        alert("请填写开始和结束日期");
        return "no";
    }

    return "ok";
}
function qmountChange(obj){
    var textobj = $(obj);
    var jqindex = textobj.parent().parent().attr("rowIndex");
    var objjq = $("#jq4_grid").find("tr");
    var total = 0;
    jq4.uptcell();
    var budget1 = objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val();
    var budget2 = objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val();
    if(budget1.indexOf(".")<0)
    {
        if(CheckNum(budget1)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val(budget1+".00");
            accountChange(budget1,jqindex);
        }
    }
    else
    {
        var part1=budget1.substring(0,budget1.indexOf("."));
        var part2=budget1.substring(budget1.indexOf(".")+1);
        if(CheckNum(part1)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            if(CheckNum(part2)!="ok")
            {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
            }
            else
            {
                if(part2.length>2)
                {
                   objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val(part1+"."+part2.substring(0,2));
                   accountChange(budget1,jqindex);
                }
                if(part2.length<2)
                {
                    objjq.eq(jqindex).find("td").eq(3).find("input").eq(0).val(budget1+"0");
                    accountChange(budget1,jqindex);
                }
            }
        }
    }
    
     if(budget2.indexOf(".")<0)
    {
        if(CheckNum(budget2)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val(budget2+".00");
            accountChange(budget2,jqindex);
        }
    }
    else
    {
        var part1=budget2.substring(0,budget2.indexOf("."));
        var part2=budget2.substring(budget2.indexOf(".")+1);
        if(CheckNum(part1)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            if(CheckNum(part2)!="ok")
            {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
            }
            else
            {
                if(part2.length>2)
                {
                   objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val(part1+"."+part2.substring(0,2));
                   accountChange(budget2,jqindex);
                }
                if(part2.length<2)
                {
                    objjq.eq(jqindex).find("td").eq(4).find("input").eq(0).val(budget2+"0");
                    accountChange(budget2,jqindex);
                }
            }
        }
    }
}
function CheckNum(text)
{
    var reg = /^\d+$/;/*正整数验证*/
    if(!reg.test(text)) { 
        return  "no";
    }else{
        return "ok";
    }
    
}
function CheckPrice(text)
{
    var reg = /^([1-9][\d]{0,7}|0)(\.[\d]{1,2})?$/;/*小数验证(2位)*/
    if(!reg.test(text)) { 
        return  "no";
    }else{
        return "ok";
    }
    
}
function accountChange(s,j){
    var objjq = $("#jq4_grid").find("tr");
    var total =0;
    jq4.uptcell();
    var budget1 = objjq.eq(j).find("td").eq(3).find("input").eq(0).val();
    var budget2 = objjq.eq(j).find("td").eq(4).find("input").eq(0).val();
    total=budget1*1.00+budget2*1.00;
    jq4.SetValue(j,3,total);
}
function Sendajax(){
    /*
    ajax.run("Tp_InsertRom.aspx",{tbl:"TP_Prj_Content",col:"PrjContent",rowid:txtrid.GetText()},function(o){
        //alert(o.split("<-->")[0]);
        //alert(o);
        if (o.split("<-->")[0] == "") {
               
        } else {
            alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
            return;
        }
    });
    ajax.run("Tp_InsertRom.aspx",{tbl:"TP_Prj_Content",col:"PrjBasis",rowid:txtrid.GetText()},function(o){
        //alert(o.split("<-->")[0]);
        //alert(o);
        if (o.split("<-->")[0] == "") {
               
        } else {
            alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
            return;
        }
    });
    ajax.run("Tp_InsertRom.aspx",{tbl:"TP_Prj_Content",col:"PrjTarget",rowid:txtrid.GetText()},function(o){
        //alert(o.split("<-->")[0]);
        //alert(o);
        if (o.split("<-->")[0] == "") {
               
        } else {
            alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
            return;
        }
    });
    ajax.run("Tp_InsertRom.aspx",{tbl:"TP_Prj_Content",col:"PrjMethod",rowid:txtrid.GetText()},function(o){
        //alert(o.split("<-->")[0]);
        //alert(o);
        if (o.split("<-->")[0] == "") {
               
        } else {
            alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
            return;
        }
    });
    ajax.run("Tp_InsertRom.aspx",{tbl:"TP_Prj_Content",col:"PrjPostulate",rowid:txtrid.GetText()},function(o){
        //alert(o.split("<-->")[0]);
        //alert(o);
        if (o.split("<-->")[0] == "") {
               
        } else {
            alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
            return;
        }
    });
    */
}
function SelecPrjType(){
    prjtypename.SetText(combox1.GetText());
}