﻿function _FormLoad() {
    cbState.SetSelectedIndex(0);
    Search();
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    dialog.show("TP_Prj_Completion_AllEdit.aspx?type=view&rowid=" + gd.item("rowid"),744,734,function(s) {
            
        });
}

//查询
function Search(){
    var sql="select wfid,rowid,Title,dbo.clip(AppDep,':',1) AppDep"
    sql +=",case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' when 3 then '结束' end state";
    sql +=",dbo.clip(AppUser,':',1) AppUser,AppDate,YearMonth";
    sql += " from TP_Prj_Completion_Request where AppUser = '" + uinfo + "'";
    
    if(txtTiitle.GetText().Trim() != ""){
        sql += " and Title like '%"+ txtTiitle.GetText().Trim() +"%'";
    }
    if(dbBegin.GetText() != ""){
        sql += " and AppDate >= '"+ dbBegin.GetText() +"'";
    }
    if(dbEnd.GetText() != ""){
        sql += " and AppDate <= '"+ dbEnd.GetText() +"'";
    }
    if(cbState.GetText().Trim() != "全部"){
        sql += " and state = '"+ cbState.GetValue().Trim() +"'";
    }
    sql += "order by AppDate Desc";
    //alert(sql);
    gd.Open(sql);
}

//重置
function ReSet(){
    txtTiitle.SetText("");
    dbBegin.SetText("");
    dbEnd.SetText("");
    cbState.SetSelectedIndex(0);
    Search();
}

//添加或编辑
function Add(f) {
    if (f == "New") {
        dialog.show("TP_Prj_Completion_Request_Edit.aspx?type=add",570,550,function(s) {
            if(s == "OK") {
                gd.Refresh();
            }
        });
    } else {
        if(gd.RowIndex < 1){
            alert("请选择一行!");
            return;
        }
        if(gd.item("state") != "新建")
        {
            alert("流程状态为新建时才能被修改!");
            return;
        }
        dialog.show("TP_Prj_Completion_AllEdit.aspx?type=edit&rowid=" + gd.item("rowid"),744,734,function(s) {
            if(s == "OK") {
                gd.Refresh();
            }
        });
    }
}

function Delete() {
    if(gd.RowIndex < 1){
        alert("请选择一行!");
        return;
    }
    if(gd.Item("state") != "新建"){
        alert("已经启动流程的项目无法删除!");
        return;
    }

    if(!confirm("是否确认删除")) return;
    Sql.AddCmd("delete from TP_Prj_Completion_Request where rowid = '" + gd.Item("rowid") + "'"); 
    Sql.AddCmd("delete from Base_FileList where objid = '" + gd.Item("rowid") + "'"); 
    ExecSql(function(s){
        if(s=="") {
            alert("删除成功!");
            gd.Refresh();
        } else {
            alert(s);
            return;
        }
    });
}

//启动
function Startflow(){
    if(gd.RowIndex < 1) {
        alert("请选择一行记录");
        return;
    }
    flow.StartFlow("TP_Prj_Completion_Request",gd.Item("rowid"),function(wfid) {
        if(wfid.length == 32) {
            var sql = "update TP_Prj_Completion_Request set state=1 where wfid = '" + wfid + "'";
            ExecSql(sql,function(s){
                if(s === ""){
                    gd.Refresh();
                }
            });
        }
     });
}

//流程图
function ViewFlowRun() {
    if(gd.RowIndex === 0){
        alert("请选择一行");
        return;
    }
    if (gd.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(gd.item("wfid"));
}
