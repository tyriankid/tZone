﻿
var baseid="";
var tabname ="tp_prj_termination"; //表名
function _FormLoad() {
    cbPrjType.SetSelectedIndex(3);
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    AppEndDate.SetEnabled(false);
    baseid = Req("wfid");
    //$("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjContent&rowid="+txtBaseId.GetText());
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Termination&col=Reason&rowid="+txtBaseId.GetText());
    $("#iframe3").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Termination&col=ResearchResults&rowid="+txtBaseId.GetText());
    if(baseid != ""){
        //txaResearchResults.SetEnabled(false);
        //txaReason.SetEnabled(false);
        AppEndDate.SetEnabled(false);
        btntxtPrjCode.SetEnabled(false);
        GetValues();
    }
    
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
    //alert(obj.FlowID+" "+obj.sopt+" "+obj.nodeid);
    //alert(Req("nid")+" "+obj.SubmitOption);
    var sql =[];

    if(obj.SubmitOption != "打回修改")
    {
        if(Req("nid").indexOf("p001")>0) //分公司主工意见(项目部主任工程师)BranchIdea
        {
            sql.push("update TP_Prj_Termination set BranchUser='"+ uinfo +"',BranchDate='"+S.date.day+"',BranchIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }
        if(Req("nid").indexOf("p000")>0) //申请部门领导意见(项目专业组组长)ComLeaderIdea
        {
            sql.push("update TP_Prj_Termination set ComLeaderUser='"+ uinfo +"',ComLeaderDate='"+S.date.day+"',ComLeaderIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }
        if(Req("nid").indexOf("p002")>0) //安质部领导意见(安质部领导)QSHELeaderIdea
        {
            sql.push("update TP_Prj_Termination set QSHELeaderUser='"+ uinfo +"',QSHELeaderDate='"+S.date.day+"',QSHELeaderIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }
        if(Req("nid").indexOf("p004")>0) //总工程师审查意见(分管总工)ChargeIdea
        {
            sql.push("update TP_Prj_Termination set ChargeUser='"+ uinfo +"',ChargeDate='"+S.date.day+"',ChargeIdea={IDEA} where wfid='"+obj.FlowID+"'");
        }

        flow.BSSQL = sql;
        //alert(sql);
        return true;
    }

}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    if(obj.sopt != "打回修改")
    {
        if(obj.nodeid.indexOf("p004")>0 ) 
        /*当前节点p003是最后一个审核节点,通过了后状态为结束,同时如果勾选了不同意立项也会结束*/
        {
           sChange(tabname,3); //state=3[结束]
           /*如果是以走完最后一个流程结束,prjState变更为2[已立项] 否则不变更]*/
           if(obj.sopt != "不同意立项") { psChange(tabname,3,10);} 
        }
        else if(obj.nodeid.indexOf("p003")>0)/*p003的节点是打回修改节点,通过了之后都是在审核中*/
        {
            sChange(tabname,1); //state=1[审核中]
        }
    }
    else //打回修改
    {
        sChange(tabname,2); //state=2[打回修改]
    }

}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function psChange(tablename,state,pstate) {
    var sql2="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    var sql ="update tp_prj_baseinfo set prjstate = "+ pstate +" where rowid='"+ txtRowid.GetText() +"'"; 
    
    Sql.AddCmd(sql);
    Sql.AddCmd(sql2);
            ExecSql(function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}

function sChange(tablename,state) {
    var sql="update "+ tablename +" set state = "+ state +" where wfid='"+ baseid +"'";
    
    ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
}





function GetValues(){
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}

var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      
    }
}