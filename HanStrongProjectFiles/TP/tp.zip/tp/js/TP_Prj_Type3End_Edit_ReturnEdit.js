﻿
var baseid="";
function _FormLoad() {
    cbPrjType.SetSelectedIndex(3);
    cbPrjType.SetEnabled(false);
    txtPrjName.SetEnabled(false);
    txtAppUser.SetEnabled(false);
    txtAppDep.SetEnabled(false);
    btntxtPrjCode.SetEnabled(false);
    AppEndDate.SetEnabled(false);
    baseid = Req("wfid");
    //$("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Content&col=PrjContent&rowid="+txtBaseId.GetText());
    $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Termination&col=Reason&rowid="+txtBaseId.GetText());
    $("#iframe3").attr("src","../tp/Tp_InsertRom.aspx?type=Single&tbl=TP_Prj_Termination&col=ResearchResults&rowid="+txtBaseId.GetText());
    
    if(baseid != ""){
        GetValues();
    }
}

//流程保存操作调用的方法
function _SaveForm() {
    Save();
}

//流程提交操作调用的方法
function _SubmitForm() {
    Save();
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
        if(obj.nodeid.indexOf("p003")>0)/*p004的节点是打回修改节点,通过了之后都是在审核中*/
        {
            var sql="update tp_prj_termination set state = 1 where wfid='"+ baseid/*此时为wfid*/ +"'";
            ExecSql(sql,function(s){
                if(s == ""){
                }
                else{
                    alert(s);
                    return;
                }
            });
        }
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
    
}

function Save(){
        
        ds.Update(Data);
}

function Data(s){
    if(s=="")
    {
        window.frames["iframe2"].Save();
        window.frames["iframe3"].Save();
    }
    else
    {
        alert(s);
        return;
    }
}

//判断项目编号是否重复
function isPrjCodeExist(){
    var prjcode=btntxtPrjCode.GetText().Trim();
    var sql="SELECT * FROM TP_Prj_Termination WHERE prjcode ='"+ prjcode +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0) //如果项目编号重复
    {
        alert("项目编号重复!");
        return false;
    }
    else
    {
        return true;
    }
}

var prj3_S_Rowid="";
var prjType=0;
var prjCode="";
var prjName="";
var prjUser="";
var appDep="";
//选择三类还没有验收的项目
function SelectPrj(){
    dialog.show("TP_Prj_SelectPrj.aspx?prjtype=3",680,500,function(s) {
        prj3_S_Rowid=s.prj3_S_Rowid;
        prjType=s.prjtype;
        prjCode=s.prjcode;
        prjName=s.prjname;
        prjUser=s.prjuser;
        appDep=s.appdep;
        //alert(prj3_S_Rowid+prjType+prjCode+prjName+prjUser+appDep);
    if(prjType == "1") {cbPrjType.SetSelectedIndex(1);}
    else if(prjType == "2") {cbPrjType.SetSelectedIndex(2);}
    else if(prjType == "3") {cbPrjType.SetSelectedIndex(3);}
    else{cbPrjType.SetSelectedIndex(0);}
    btntxtPrjCode.SetText(prjCode);
    txtPrjName.SetText(prjName);
    _txtAppUser.SetText(prjUser);
    _txtAppDep.SetText(appDep);
    txtRowid.SetText(prj3_S_Rowid);
    GetValues();
    });
}

function GetValues(){
    txtAppUser.SetText($ONM(_txtAppUser.GetText()));
    txtAppDep.SetText($ONM(_txtAppDep.GetText()));
}


var tablist = [false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    if (e.tab.index == 1) {
      if(Req("type") == "view")
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=view&rowid="+baseid);
      }
      else
      {
        $("#iframe1").attr("src","../tp/HT_UpFile.aspx?type=add&rowid="+baseid);
      }
    }
}