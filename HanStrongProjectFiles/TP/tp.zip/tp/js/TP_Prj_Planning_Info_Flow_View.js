﻿function _FormLoad() {
    if(Req("wfid")=="")
    {
        txtrid.SetText(S.guid)
        appdate.SetText(S.date.day);
        
    }
    else
    {
        txtfzr.SetText($ONM(_txtfzr.GetText()));
        appdep.SetText($ONM(_appdep.GetText()));
        jq1.Open("SELECT * FROM ContractInfo WHERE  ContractID IN (SELECT ContractID FROM TP_Prj_Contract_Info WHERE PrjID='"+ txtrid.GetText() +"')");
        jq2.Open("select * from TP_Prj_Planning_Progress where objid='"+ txtrid.GetText() +"'");
        jq3.Open("select rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID,InvestTime,isPrjFzr from TP_Prj_Players_Info where objid='"+ txtrid.GetText() +"'");
        jq4.Open("select  b.rowid,a.title coursetitle,'<input id=''Text1''  value='+CAST(isnull(b.TotalMoney,'0.00') as VARCHAR(10))+' type=''text'' onchange=''qmountChange(this)''  style=''width:95%'' />'TotalMoney,b.memo  from (select * from TP_Prj_Budget_info where [type]=2) a left join (select * from TP_Prj_Appropriation_Budget where objid='"+ _prjid.GetText() +"') b on a.title=b.CourseTitle");
    }
    //alert(2);
    combox1.SetEnabled(false);
    txtfzr.SetEnabled(false);
    datebox1.SetEnabled(false);
    datebox2.SetEnabled(false);
    
}
var tablist = [false,false,false,false,false,false,false,false,false];
function SwitchTab(s,e) {
    if (tablist[e.tab.index]) return;
    tablist[e.tab.index] = true;
    var optid="";
    if(Req("wfid")=="")
    {
        optid=_prjid.GetText();
    }
    else
    {
        optid=txtrid.GetText();
    }
    if (e.tab.index === 1) {
      $("#iframe2").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjBasis&rowid="+optid);
    }
    if (e.tab.index === 2) {
      $("#iframe3").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjPostulate&rowid="+optid);
    }
    if (e.tab.index === 3) {
      $("#iframe4").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjTarget&rowid="+optid);
    }
    if (e.tab.index === 4) {
      $("#iframe5").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjMethod&rowid="+optid);
    }
    /*
    if (e.tab.index === 5) {
      $("#iframe6").attr("src","../tp/Tp_InsertRom.aspx?&tbl=TP_Prj_Content&col=PrjPostulate&rowid="+optid);
    }
    */
    if (e.tab.index === 8) {
      $("#iframe1").attr("src","../tp/HT_UpFile.aspx?&type=add&rowid="+txtrid.GetText());
    }

}
//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm(obj) {
        var sql=[];
       if(Req("nid").indexOf("p000")>0){   
                 if(obj.SubmitOption==="不通过"){ 
                sql.push("update TP_Prj_Planning_Info set ComdepZgIdea={IDEA},state=2 where wfid='"+obj.FlowID+"'");
            }
            else
            {
                sql.push("update TP_Prj_Planning_Info set ComdepZgIdea={IDEA},ComdepZgDate='"+ S.date.day +"',ComdepZg='"+ uinfo +"' where wfid='"+obj.FlowID+"'");
            }
        }
        if(Req("nid").indexOf("p001")>0)
        {
               if(obj.SubmitOption==="不通过"){ 
                sql.push("update TP_Prj_Planning_Info set ComdepIdea={IDEA},state=2 where wfid='"+obj.FlowID+"'");
            }
            else
            {
                sql.push("update TP_Prj_Planning_Info set ComDepIdea={IDEA},ComDepDate='"+ S.date.day +"',ComDepUser='"+ uinfo +"' where wfid='"+obj.FlowID+"'");
            }
        }
        if(Req("nid").indexOf("p004")>0){   
                 if(obj.SubmitOption==="不通过"){ 
                sql.push("update TP_Prj_Planning_Info set ChargeIdea={IDEA},state=2 where wfid='"+obj.FlowID+"'");
            }
            else
            {
                sql.push("update TP_Prj_Planning_Info set ChargeIdea={IDEA},ChargeDate='"+ S.date.day +"',ChargeUser='"+ uinfo +"' where wfid='"+obj.FlowID+"'");
            }
        }
         if(Req("nid").indexOf("p002")>0){   
                 if(obj.SubmitOption==="不通过"){ 
                sql.push("update TP_Prj_Planning_Info set LeaderIdea={IDEA},state=2 where wfid='"+obj.FlowID+"'");
            }
            else
            {
                sql.push("update tp_prj_baseinfo set prjstate = 4 where rowid = '"+ _prjid.GetText() +"'");  //流程走完更新项目状态 已实施 
                sql.push("update TP_Prj_Planning_Info set state = 3,LeaderIdea={IDEA},LeaderDate='"+ S.date.day +"',Leader='"+ uinfo +"' where wfid='"+obj.FlowID+"'");
            }
        }

        flow.BSSQL = sql;
        return true;
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
      if(Cmd==="浏览" && oGrid==jq1)
   {
    //alert(jq1.Item("rowid"));
  //  dialog.show("Default.aspx?rowid=" + jq1.Item("rowid") + "&filepath="+escape(jq1.Item("ContractName")),1050,700,function(s){});  
  dialog.show("ht_ContractInfo_Edit.aspx?flag="+jq1.Item("rowid")+"&act=view",652,643,function(s){
        
      });  
   }
       if(Cmd==="删除" && oGrid==jq2)
   {
    //alert(jq1.Item("rowid"));
      if(!confirm("是否确定删除?")) return;
    Sql.AddCmd("delete from TP_Prj_Planning_Progress where rowid='"+ jq2.item("rowid") +"'"); 
    ExecSql(function (s){
        if(s=="")
        {
            alert("删除成功");
            jq2.Open("select * from TP_Prj_Planning_Progress where objid='"+ txtrid.GetText() +"'");
        }
        else
        {
            alert(s);
            return;
        }
    });
   }
    if(Cmd==="附件" && oGrid==jq4)
   {
    //alert(jq1.Item("rowid"));
    dialog.show("TP_Prj_Budget_DetailEdit.aspx?objid="+jq4.item("rowid"),1050,700,function(s){
        if(s=="ok")
        {
            var obj=GetData("select sum(Price) price from TP_Prj_Budget_Detail where objid='"+ jq4.item("rowid") +"'")||[];
            if(obj.length>0)
            {
                textbox12.SetText(textbox12.GetText()*1-jq4.item("TotalMoney")*1+obj[0].price*1);
                jq4.SetValue(jq4.RowIndex,2,obj[0].price);
            }
        }
    });    
   }
}
function SelectP(){
    dialog.show("TP_Prj_BaseInfo_Select.aspx",839,439,function(s){
        if(s!="_null"&&s.length>0)
        {
            SetSelectInfo(s.rowid);
        }
    });
}
function SetSelectInfo(prjid){
    _prjid.SetText(prjid);
    var sql="select prjcode,prjname,appdate,appdep,prjuser,prjstartdate,prjenddate,prjtype,prjmoney,prjtypename from TP_Prj_BaseInfo where rowid='"+ prjid +"'";
    var obj=GetData(sql)||[];
    if(obj.length>0)
    {
        //combox1.SetText(obj[0].prjtypename);
        combox1.SetValue(obj[0].PrjType);
        prjtypename.SetText(obj[0].prjtypename);
        textbox1.SetText(obj[0].prjcode);
        textbox2.SetText(obj[0].prjname);
        txtfzr.SetText($ONM(obj[0].prjuser));
        _txtfzr.SetText(obj[0].prjuser);
        appdep.SetText($ONM(obj[0].appdep));
        _appdep.SetText(obj[0].appdep);
        //appdate.SetText(obj[0].appdate);
        datebox1.SetText(obj[0].prjstartdate);
        datebox2.SetText(obj[0].prjenddate);
        textbox15.SetText(obj[0].prjmoney);
        textbox12.SetText(obj[0].prjmoney);
        jq1.Open("SELECT * FROM ContractInfo WHERE  ContractID IN (SELECT ContractID FROM TP_Prj_Contract_Info WHERE PrjID='"+ _prjid.GetText() +"')");
        jq2.Open("select * from TP_Prj_Planning_Progress where objid='"+ _prjid.GetText() +"'");
        jq3.Open("select rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID from TP_Prj_Players_Info where objid='"+ _prjid.GetText() +"'");
        jq4.Open("select  b.rowid,a.title coursetitle,'<input id=''Text1''  value='+CAST(isnull(b.TotalMoney,'0.00') as VARCHAR(10))+' type=''text'' onchange=''qmountChange(this)''  style=''width:95%'' />'TotalMoney,b.memo  from (select * from TP_Prj_Budget_info where [type]=1) a left join (select * from TP_Prj_Appropriation_Budget where objid='"+ _prjid.GetText() +"') b on a.title=b.CourseTitle");
    }
}
function Save(){
     if(CheckSave()!="ok")
    {
        return;
    }
    var objjq = $("#jq4_grid").find("tr");
    var conmoney=0;
    Sql.AddCmd("delete from TP_Prj_Contract_Info where prjid='"+ txtrid.GetText() +"'");
    Sql.AddCmd("delete from TP_Prj_Players_Info where objid='"+ txtrid.GetText() +"'");
    Sql.AddCmd("delete from TP_Prj_Appropriation_Budget where objid='"+ txtrid.GetText() +"'");
    Sendajax();
    jq1.uptcell();
    for(var i=1;i<=jq1.RowCount();i++)
    {
        if(jq1.item("ContractMeony",i)!="") conmoney=jq1.item("ContractMeony",i);
        Sql.AddCmd("insert into TP_Prj_Contract_Info(PrjID,ContractID,ContractName,ContractMeony,EntrustingParty)values('"+ txtrid.GetText() +"','"+ jq1.item("ContractID",i) +"','"+ jq1.item("ContractName",i) +"',"+ conmoney +",'"+ jq1.item("EntrustingParty",i) +"')");
    }
    jq3.uptcell();
    for(var j=1;j<=jq3.RowCount();i++)
    {
        Sql.AddCmd("insert into TP_Prj_Players_Info(objid,UserID,UserName,Age,Position,Qualification,Major,DivisionScope)values('"+ txtrid.GetText() +"','"+ jq3.item("UserID",j) +"','"+  jq3.item("username",j) +"',isnull('"+ jq3.item("age",j) +"',0),'"+  jq3.item("Position",j) +"','"+ jq3.item("Qualification",j) +"','"+ jq3.item("Major",j) +"','"+ jq3.item("DivisionScope",j) +"')");
    }
    jq4.uptcell();
    for(var k=1;k<=jq4.RowCount();k++)
    {
         var budget1 = objjq.eq(k).find("td").eq(3).find("input").eq(0).val();
         var budget2 = objjq.eq(k).find("td").eq(4).find("input").eq(0).val();
         Sql.AddCmd("insert into TP_Prj_Appropriation_Budget(objid,CourseTitle,SubsidizeMoney,SelfMoney,TotalMoney,Memo)values('"+ txtrid.GetText() +"','"+ jq4.item("CourseTitle",k) +"',"+ budget1 +","+ budget2 +","+ jq4.item("TotalMoney",k) +",'"+ jq4.item("memo",k) +"')");
    }
    ExecSql(function(s){
        if(s!="")
        {
            alert(s);
            return;
        }
        else
        {
            if(Req("rowid")=="")
            {
                ds2.Insert(Data);
            }
            else
            {
                ds2.Update(Data);
            }
        }
    });
}
function Data(s){
    if(s=="")
    {
        alert("保存成功");
        dialog.close("ok");
    }
    else
    {
        alert(s);
        return;
    }
}
function CheckSave(){
    if(txtfzr.GetText()=="")
    {
        alert("请选择负责人");
        return "no";
    }
    if(datebox1.GetText()==""||datebox2.GetText()=="")
    {
        alert("请填写开始和结束日期");
        return "no";
    }

    return "ok";
}
function qmountChange(obj){
    var textobj = $(obj);
    var jqindex = textobj.parent().parent().attr("rowIndex");
    var objjq = $("#jq4_grid").find("tr");
    var total = 0;
    jq4.uptcell();
    var budget1 = objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val();
    
    if(budget1.indexOf(".")<0)
    {
        if(CheckNum(budget1)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val(budget1+".00");
            accountChange(budget1,jqindex);
        }
    }
    else
    {
        var part1=budget1.substring(0,budget1.indexOf("."));
        var part2=budget1.substring(budget1.indexOf(".")+1);
        if(CheckNum(part1)!="ok")
        {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
        }
        else
        {
            if(CheckNum(part2)!="ok")
            {
            alert("请勿填写数字以外的内容");
            objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val("0.00");
            accountChange(s,jqindex);
            }
            else
            {
                if(part2.length>2)
                {
                   objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val(part1+"."+part2.substring(0,2));
                   accountChange(budget1,jqindex);
                }
                if(part2.length<2)
                {
                    objjq.eq(jqindex).find("td").eq(2).find("input").eq(0).val(budget1+"0");
                    accountChange(budget1,jqindex);
                }
            }
        }
    }
    
     
}
function CheckNum(text)
{
    var reg = /^\d+$/;/*正整数验证*/
    if(!reg.test(text)) { 
        return  "no";
    }else{
        return "ok";
    }
    
}
function CheckPrice(text)
{
    var reg = /^([1-9][\d]{0,7}|0)(\.[\d]{1,2})?$/;/*小数验证(2位)*/
    if(!reg.test(text)) { 
        return  "no";
    }else{
        return "ok";
    }
    
}
function accountChange(s,j){
    var objjq = $("#jq4_grid").find("tr");
    var total =0;
    jq4.uptcell();
   
   for(var i=1;i<=jq4.RowCount();i++)
     {
          var budget1 = objjq.eq(j).find("td").eq(2).find("input").eq(0).val();
         total=total*1+budget1*1;
     }
    
    textbox12.SetText(total);
}
//项目计划新建
function PrjPlanAdd(){
    if(datebox3.GetText()==""||datebox4.GetText()==""||mtextbox1.GetText()=="")
    {
        alert("请填写完整信息再保存");
        return;
    }
    var txtcon=mtextbox1.GetText();
    txtcon=txtcon.Replace("'","‘");
    var sql="insert into TP_Prj_Planning_Progress(objid,PlanContent,PlanStartDate,PlanEndDate,Executor,ExecDep)value('"+ txtrid.GetText() +"','"+ txtcon +"','"+ datebox3.GetText() +"','"+ datebox4.GetText() +"','"+ uinfo +"','"+ _appdep.GetText() +"')";
    Sql.AddCmd(sql);
    ExecSql(function(s){
        if(s=="")
        {
            alert("保存成功");
            datebox3.SetText("");
            datebox4.SetText("");
            mtextbox1.SetText("");
        }
        else
        {
            alert(s);
            return;
        }
    });

}  
//项目计划修改
function PrjPlanEdit(){
    if(jq2.RowIndex<1)
    {
        alert("请选择需要修改的信息");
        return;
    }
    var txtcon=mtextbox1.GetText();
    txtcon=txtcon.Replace("'","‘");
    var sql="update TP_Prj_Planning_Progress set PlanContent='"+ txtcon +"',PlanStartDate='"+ datebox3.GetText() +"',PlanEndDate='"+ datebox4.GetText() +"' where rowid='"+ jq2.item("rowid") +"'";
    Sql.AddCmd(sql);
    ExecSql(function(s){
        if(s=="")
        {
            alert("修改成功");
            datebox3.SetText("");
            datebox4.SetText("");
            mtextbox1.SetText("");
        }
        else
        {
            alert(s);
            return;
        }
    });

}
//修改计划日期时
function OnChangeDate(){
    if(datebox3.GetText()>datebox4.GetText())
    {
        alert("开始时间不能大于结束时间");
        datebox3.SetText("");
        datebox4.SetText("");
        return;
    }
}
//选择成员
function SelectMeber(){
     var users="";
     var str= SelObject({type:"u",selcount:0,modal:"div"},function(str){
        if(str.length>0)
        {
            for(var i=0;i<str.length;i++)
            {
                users+=","+str[i].id;
            }
            //rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID
         var sql="SELECT dbo.GetGUID() rowid,staff_name username,age,dbo.clip(current_position,':',1) Position,title Qualification,case groupname when '' then '' else substring(dbo.clip(groupname,':',1),0,len(dbo.clip(groupname,':',1))) end Major,''DivisionScope,staff_rowid userid from HR_Staff_Details where CHARINDEX(staff_rowid,'"+ users +"')>0";
         sql+="union all select rowid,UserName,Age,Position,Qualification,Major,DivisionScope,UserID from TP_Prj_Players_Info where objid='"+ txtrid.GetText() +"'";
         jq3.Open(sql);
        }
     });
}
function jq2Click(){
    datebox3.SetText(jq2.item("PlanStartDate"));
    datebox4.SetText(jq2.item("PlanEndDate"));
    mtextbox1.SetText(jq2.item("PlanContent"));
}