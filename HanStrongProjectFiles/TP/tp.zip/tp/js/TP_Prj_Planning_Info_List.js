﻿function _FormLoad() {
    combox1.SetSelectedIndex(0);
    //combox2.SetSelectedIndex(0);
}

//流程保存操作调用的方法
function _SaveForm() {
    
}

//流程提交操作调用的方法
function _SubmitForm() {
    
}

//流程提交成功回调方法(obj.wfid,obj.nodeid,obj.sopt)
function _SubmitCallback(obj) {
    
}

//JqGrid命令列调用方法
function JqGrid_CommandBtnsExec(oGrid, iRow, Cmd) {
        dialog.show("TP_Prj_Planning_Info_View.aspx?rowid="+jq.Item("rowid"),1040,502,function(s) {
        
    });
}
function Add() {
    dialog.show("TP_Prj_Planning_Info_Edit.aspx",1040,502,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Edit(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
    if(jq.item("state")!=0)
    {
        alert("已启动的流程无法修改");
        return;
    }
    dialog.show("TP_Prj_Planning_Info_Edit.aspx?rowid="+jq.Item("rowid"),1040,502,function(s) {
        if(s=="ok")
        {
            jq.Refresh();
        }
    });
}
function Del(){
    if(jq.RowIndex<1)
    {
        alert("请至少选择一行");
        return;
    }
     if(jq.item("state")!=0)
    {
        alert("非新建状态的信息无法删除");
        return;
    }
    if(!confirm("是否确定删除?")) return;
    Sql.AddCmd("delete from TP_Prj_Planning_Info where rowid='"+ jq.Item("rowid") +"'");
   // Sql.AddCmd("delete from TP_Prj_Content where prjid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Appropriation_Budget where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Players_Info where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Planning_Progress where objid='"+ jq.Item("rowid") +"'");
    Sql.AddCmd("delete from TP_Prj_Contract_Info where prjid='"+ jq.Item("rowid") +"'");
    

    ExecSql(function(s){
        if(s=="")
        {
            alert("删除成功");
            jq.Refresh();
        }
        else
        {
            alert(s);
            return;
        }
    });

}
function  StartFlow(){
    if(jq.RowIndex<1){
        alert("请选择一行记录");
        return;
    }
    
     if(!canStartflow(jq.Item("prjid"))){ return; }
     flow.StartFlow("TP_Prj_Planning_Info",jq.Item("rowid"),function(wfid){
        if(wfid.length==32){
            Sql.AddCmd ("update TP_Prj_Planning_Info set State=1 where wfid='"+wfid+"'");
            Sql.AddCmd ("update tp_prj_baseinfo set prjstate = 3 where rowid = '"+ jq.Item("prjid") +"'");
            ExecSql(function(s){
                if(s===""){
                    jq.Refresh();
                }
            });
        }
     });
} 

//启动项目前的判断
function canStartflow (prjid) {
    var sql="select case prjstate when 1 then '立项中' when 3 then '实施中' when 5 then '上报中' ";
    sql += "when 7 then '检查中' when 9 then '终止中' when 10 then '已终止' ";
    sql += "when 11 then '验收中' when 12 then '验收完成' when 13 then '课题验收中' when 15 then '结题验收中' end prjstate";
    sql += " from tp_prj_baseinfo where rowid='"+ prjid +"'";
    var oData = GetData(sql) || [];
    if(oData.length > 0){  //如果prjstate在以上状态中,则不允许启动项目
        if(oData[0].prjstate == ""){
            return true;
        }
        alert("该项目状态为"+oData[0].prjstate+",不能被启动!");
        return false;
    }
}

function FlowView(){
     if(jq.RowIndex === 0){
        alert("请选定要查看的记录");
        return;
    }
    if (jq.item("wfid") == "") {
        alert("当前选定的记录还没有提交");
        return;
    }
    flow.Monitor(jq.item("wfid"));
}
function PrintReport(){
     if(jq.RowIndex<1){
        alert("请选择一行");
        return;
    }
   
    if (jq.Item("ReportFilePath") == "" || (jq.Item("state") > 0 && jq.Item("state") <= 2)) {
        ajax.run("TP_Prj_Report_plan.aspx",{cmd:"apply",rowid:jq.Item("rowid")},function(o){
            //alert(o.split("<-->")[0]);
            alert(o);
            if (o.split("<-->")[0] == "") {
                dialog.show("word.aspx?docid=" + jq.Item("rowid") + "&type=plan" ,800,600,function(s) {
                });   
            } else {
                alert("生成失败, 原因:\n\n" + o.split("<-->")[0]);
                return;
            }
        });
    } else {
    alert(1);
        dialog.show("word.aspx?docid=" + jq.Item("rowid") + "&type=plan" ,800,600,function(s) {
        });
    }
}
function Query(){
    var sql="select *,dbo.Clip(PrjUser,':',1)PrjUsers,dbo.Clip(AppDep,':',1)AppDeps,case state when 0 then '新建' when 1 then '审批中' when 2 then '打回修改' else '结束' end states from TP_Prj_Planning_Info where  prjtype<> '3'";
    if(txtbh.GetText()!="")
    {
        sql+="and PrjCode like '%"+ txtbh.GetText() +"%'";
    }
    if(txtmc.GetText()!="")
    {
        sql+="and PrjName like '%"+ txtmc.GetText() +"%'";
    }
    if(datebox1.GetText()==""&&datebox2.GetText()!="")
    {
        sql+="and PrjEndDate<='"+datebox2.GetText()+"'";
    }
    if(datebox1.GetText()!=""&&datebox2.GetText()=="")
    {
        sql+="and PrjStartDate>='"+datebox1.GetText()+"'";
    }
    if(datebox1.GetText()!=""&&datebox2.GetText()!="")
    {
        sql+="and PrjStartDate>='"+datebox1.GetText()+"' and PrjEndDate<'"+datebox2.GetText()+"' ";
    }
    if(combox1.GetText()!="全部")
    {
        sql+="and State like '%"+ combox1.GetValue() +"%'";
    }
    //alert(sql);
    jq.Open(sql);
}
function ReSet(){
    txtbh.SetText("");
    txtmc.SetText("");
    datebox1.SetText("");
    datebox2.SetText("");
    combox1.SetSelectedIndex(0);
   // combox2.SetSelectedIndex(0);
    Query();
}