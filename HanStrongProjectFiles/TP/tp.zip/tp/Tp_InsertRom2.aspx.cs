﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


    public partial class Tp_InsertRom : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            init();
        }
         private void init()
         {
			 if (!IsPostBack)
            {
                tbl.Text = Request["tbl"].ToString();
                col.Text = Request["col"].ToString();
                if (tbl.Text == "" || col.Text == "")
                {
                    Response.Write("缺少参数，无法查询数据");
                    Response.End();
                }	
                if(IsExsit()!="no")
                {
					RomText.Text=IsExsit();
                }
              /* if(Request["type"].ToString()=="view")
                {
					RomText.Enabled = false;
                }
                else
				{
					RomText.Enabled = true;
				}*/
			}
         }
          private string IsExsit() {
            string sql = "";
            DataTable dt = null;
            sql = "select " + col.Text + " from " + tbl.Text + " where objid='" + Request["rowid"].ToString() + "'";
            try
            {
                dt = SqlDataAccess.SqlHelp.ExecuteDataTable(sql);
            }
            catch
            {
                dt = null;
            }
            if (dt == null || dt.Rows.Count == 0)
            {
				 return "no";
                
            }
            else
            {
               return dt.Rows[0][0].ToString();
            }
        }
        private void GetData()
        {
			
            string sql = ""; 
            int rtn ;
            DataTable dt = null;
            if (IsExsit()=="no")
            {
                //插入新数据
                sql = "insert into " + tbl.Text + " (" + col.Text + ",objid)values('"+ RomText.Text +"','" + Request["rowid"].ToString() + "')";
            }
            else
            {
                //更新数据行
                sql = "update " + tbl.Text + " set " + col.Text + "='" + RomText.Text + "' where objid='" + Request["rowid"].ToString() + "'";
            }
            try
            {
                rtn = SqlDataAccess.SqlHelp.ExecuteNonQuery(sql);
                //Response.Write(sql);
            }
            catch(Exception ex)
            {
                Response.Write("失败"+sql);
                Response.End();
            }
          
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GetData();
        }
    }
