﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Aspose.Words;
using Aspose.Words.Saving;
using Aspose.Words.Tables;
using Aspose.Words.BuildingBlocks;
using System.Data;

public partial class TP_Prj_Report : BasePage
{
    //private DataBaseProxy DBHelper;
    private string uploadfilepath = AppDomain.CurrentDomain.BaseDirectory + "uploadfile";

    protected void Page_Load(object sender, EventArgs e)
    {
        switch (Request["cmd"])
        {
            case "apply":
                Response.Write(Apply() + "<-->");
                break;
            default:
                break;
        }
    }

    #region 科技项目申请书
    private string Apply()
    {
        string result = "";
        string templatepath = uploadfilepath + "/TP_Template/PrjApply.doc";
        Document doc = new Document(templatepath.Replace("/", "\\"));
        DocumentBuilder builder = new DocumentBuilder(doc);

        DataTable dt = DBHelper.GetDataTableBySql(string.Format("SELECT *,dbo.Clip(PrjUser,':',1) PrjUsers,dbo.Clip(AppDep,':',1) AppDeps,dbo.Clip(Participants,':',1) Participant,dbo.Clip(workplace,':',1) workplaces FROM dbo.TP_Prj_BaseInfo WHERE rowid = '{0}'", Request["rowid"]));

        if (dt == null || dt.Rows.Count <= 0) return "请选择一行记录。";

        try
        {
            string PrjCode = dt.Rows[0]["PrjCode"].ToString(); //项目编号
            string PrjName = dt.Rows[0]["PrjName"].ToString(); //项目名称
            string SEDate = dt.Rows[0]["PrjStartDate"].ToString() + "至" + dt.Rows[0]["PrjEndDate"].ToString(); //起止日期
            string AppDate = dt.Rows[0]["AppDate"].ToString(); //申请日期
            string AppDep = dt.Rows[0]["AppDeps"].ToString();  //申请部门
            string PrjUser = dt.Rows[0]["PrjUsers"].ToString();//项目负责人
            string PrjUserSex = dt.Rows[0]["PrjUserSex"].ToString();//性别
            string PrjUserAge = dt.Rows[0]["PrjUserAge"].ToString();//年龄
            string PrjMajor = dt.Rows[0]["PrjMajor"].ToString();//专业
            string PrjUserQualification = dt.Rows[0]["PrjUserQualification"].ToString();//职称
            string PrjWorkplace = dt.Rows[0]["workplaces"].ToString();//工作单位
            string PrjClassify = dt.Rows[0]["PrjClassify"].ToString();//项目分类
            string PersonNum = dt.Rows[0]["PersonNum"].ToString();//项目人数
            string AdvNum = dt.Rows[0]["AdvNum"].ToString();//高级人数
            string MidNum = dt.Rows[0]["MidNum"].ToString();//中级人数
            string JunNum = dt.Rows[0]["JunNum"].ToString();//初级人数
            string GradNum = dt.Rows[0]["GradNum"].ToString();//研究生人数
            string CooperationUnit = dt.Rows[0]["CooperationUnit"].ToString();//协作单位
            string PrjMoney = dt.Rows[0]["PrjMoney"].ToString();//项目金额
            string SubsidizeMoney = dt.Rows[0]["SubsidizeMoney"].ToString();//资助金额
            string SelfMoney = dt.Rows[0]["SelfMoney"].ToString();//自筹金额
            string ComDetIdea = dt.Rows[0]["ComDetIdea"].ToString();//部门领导意见
            string ComDepUser = dt.Rows[0]["ComDepUser"].ToString();//部门领导
            string ComDepDate = dt.Rows[0]["ComDepDate"].ToString();//部门领导提交日期
            string QSHEIdea = dt.Rows[0]["QSHEIdea"].ToString();//安质部意见
            string QSHEUser = dt.Rows[0]["QSHEUser"].ToString();//安质部人员
            string QSHEDate = dt.Rows[0]["QSHEDate"].ToString();//安质部提交日期
            string LeaderIdea = dt.Rows[0]["LeaderIdea"].ToString();//院领导意见
            string LeaderUser = dt.Rows[0]["LeaderUser"].ToString();//院领导
            string LeaderDate = dt.Rows[0]["LeaderDate"].ToString();//院领导提交日期

            #region 替换书签
            builder.MoveToBookmark("FCode");
            builder.Write(PrjCode);

            builder.MoveToBookmark("FName");
            builder.Write(PrjName);

            builder.MoveToBookmark("FDate");
            builder.Write(SEDate);

            builder.MoveToBookmark("FDept");
            builder.Write(AppDep);

            builder.MoveToBookmark("FUser");
            builder.Write(PrjUser);

            builder.MoveToBookmark("FAppDate");
            builder.Write(AppDate);

            builder.MoveToBookmark("PrjName");
            builder.Write(PrjName);

            builder.MoveToBookmark("PrjDep");
            builder.Write(AppDep);

            builder.MoveToBookmark("PrjUnit");
            builder.Write(PrjWorkplace);

            builder.MoveToBookmark("PrjUser");
            builder.Write(PrjUser);

            builder.MoveToBookmark("Sex");
            builder.Write(PrjUserSex);

            builder.MoveToBookmark("Age");
            builder.Write(PrjUserAge);

            builder.MoveToBookmark("Major");
            builder.Write(PrjMajor);

            builder.MoveToBookmark("Qualification");
            builder.Write(PrjUserQualification);

            #region 项目分类
            string[] classlist = PrjClassify.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
            if (classlist.Length > 0)
            {
                foreach (string classify in classlist)
                {
                    switch (classify)
                    {
                        case "技术研究":
                            builder.MoveToBookmark("Classify1");
                            builder.Write("√");
                            break;
                        case "新技术开发":
                            builder.MoveToBookmark("Classify2");
                            builder.Write("√");
                            break;
                        case "引进消化":
                            builder.MoveToBookmark("Classify3");
                            builder.Write("√");
                            break;
                        case "成果转化":
                            builder.MoveToBookmark("Classify4");
                            builder.Write("√");
                            break;
                        case "技术改造":
                            builder.MoveToBookmark("Classify5");
                            builder.Write("√");
                            break;
                        case "施工装备":
                            builder.MoveToBookmark("Classify6");
                            builder.Write("√");
                            break;
                        case "科技推广":
                            builder.MoveToBookmark("Classify7");
                            builder.Write("√");
                            break;
                        case "产业变革":
                            builder.MoveToBookmark("Classify8");
                            builder.Write("√");
                            break;
                        default:
                            break;
                    }
                }
            }
            #endregion

            builder.MoveToBookmark("PersonNum");
            builder.Write(PersonNum);

            builder.MoveToBookmark("AdvNum");
            builder.Write(AdvNum);

            builder.MoveToBookmark("MidNum");
            builder.Write(MidNum);

            builder.MoveToBookmark("JunNum");
            builder.Write(JunNum);

            builder.MoveToBookmark("GradNum");
            builder.Write(GradNum);

            builder.MoveToBookmark("CooperationUnit");
            builder.Write(CooperationUnit);

            builder.MoveToBookmark("PrjMoney");
            builder.Write(PrjMoney);

            builder.MoveToBookmark("SubsidizeMoney");
            builder.Write(SubsidizeMoney);

            builder.MoveToBookmark("SelfMoney");
            builder.Write(SelfMoney);

            builder.MoveToBookmark("SEDate");
            builder.Write(SEDate);

            #region 项目内容
            DataTable dtContent = DBHelper.GetDataTableBySql(string.Format("SELECT * FROM dbo.TP_Prj_Content WHERE objid = '{0}'", Request["rowid"]));
            if (dtContent != null && dtContent.Rows.Count > 0)
            {
                builder.MoveToBookmark("PrjContent");
                builder.Write(dtContent.Rows[0]["PrjContent"].ToString());

                builder.MoveToBookmark("PrjBasis");
                builder.Write(dtContent.Rows[0]["PrjBasis"].ToString());

                builder.MoveToBookmark("PrjTarget");
                builder.Write(dtContent.Rows[0]["PrjTarget"].ToString());

                builder.MoveToBookmark("PrjMethod");
                builder.Write(dtContent.Rows[0]["PrjMethod"].ToString());

                builder.MoveToBookmark("PrjPostulate");
                builder.Write(dtContent.Rows[0]["PrjPostulate"].ToString());
            }
            #endregion

            #region 计划内容
            builder.MoveToBookmark("Progress");
            DataTable dtPlan = DBHelper.GetDataTableBySql(string.Format("SELECT * FROM dbo.TP_Prj_Planning_Progress WHERE ObjId = '{0}'", Request["rowid"]));
            if (dtPlan != null && dtPlan.Rows.Count > 0)
            {
                BuilderPlanTable(builder, dtPlan);
            }
            else
            {
                BuilderPlanTable(builder);
            }
            doc.Range.Bookmarks["Progress"].Text = "";
            builder.EndTable();
            #endregion

            #region 项目成员
            builder.MoveToBookmark("Players");
            DataTable dtPlayer = DBHelper.GetDataTableBySql(string.Format("SELECT * FROM dbo.TP_Prj_Players_Info WHERE ObjId = '{0}'", Request["rowid"]));
            if (dtPlayer != null && dtPlayer.Rows.Count > 0)
            {
                BuilderPlayerTable(builder, dtPlayer);
            }
            else
            {
                BuilderPlayerTable(builder);
            }
            doc.Range.Bookmarks["Players"].Text = "";
            builder.EndTable();
            #endregion

            #region 经费预算
            builder.MoveToBookmark("Budget");
            DataTable dtBuget = DBHelper.GetDataTableBySql(string.Format("SELECT * FROM dbo.TP_Prj_Appropriation_Budget WHERE ObjId = '{0}'", Request["rowid"]));
            if (dtBuget != null && dtBuget.Rows.Count > 0)
            {
                BuilderBugetTable(builder, dtBuget, PrjMoney, SubsidizeMoney, SelfMoney);
            }
            else
            {
                BuilderBugetTable(builder);
            }
            doc.Range.Bookmarks["Budget"].Text = "";
            builder.EndTable();
            #endregion

            #endregion

            //保存
            string systembuilderpath = "TP" + "/" + Request["rowid"];
            string systemfilename = "TP_" + Request["rowid"] + ".doc";
            Directory.CreateDirectory((uploadfilepath + "/" + systembuilderpath).Replace("/", "\\"));
            string reportfilepath = uploadfilepath + "/" + systembuilderpath + "/" + systemfilename;
            doc.Save(reportfilepath.Replace("/", "\\"));
            result = DBHelper.ExecuteSql(string.Format("UPDATE dbo.TP_Prj_BaseInfo SET ReportFilePath = '{1}' WHERE rowid = '{0}'", Request["rowid"], systembuilderpath + "/" + systemfilename));
        }
        catch (Exception ex)
        {
            return "读取报表文件失败，原因：" + ex.Message;
        }

        return result;
    }

    private void BuilderBugetTable(DocumentBuilder builder, DataTable dtBuget, string PrjMoney, string SubsidizeMoney, string SelfMoney)
    {
        #region 列头
        //第一列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 5.7;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("科      目");

        //第二列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("金 额");

        //第三列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("申请资助");

        //第四列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("自 筹");

        //第五列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.81;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("备 注");

        builder.EndRow();
        #endregion

        foreach (DataRow dr in dtBuget.Rows)
        {
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 5.7;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Left;//左对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dr["CourseTitle"].ToString());

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dr["TotalMoney"].ToString());

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dr["SubsidizeMoney"].ToString());

            //第四列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dr["SelfMoney"].ToString());

            //第五列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.81;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dr["Memo"].ToString());

            builder.EndRow();
        }

        #region 合计
        //第一列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 5.7;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("合     计");

        //第二列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write(PrjMoney);

        //第三列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write(SubsidizeMoney);

        //第四列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.49;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write(SelfMoney);

        //第五列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.81;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("");

        builder.EndRow();
        #endregion
    }

    private void BuilderBugetTable(DocumentBuilder builder)
    {
        DataTable dt = DBHelper.GetDataTableBySql(string.Format("SELECT * FROM dbo.TP_Prj_Budget_info WHERE type = 1 ORDER BY ordidx"));
        if (dt != null && dt.Rows.Count > 0)
        {
            #region 列头
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 5.7;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("科      目");

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("金 额");

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("申请资助");

            //第四列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("自 筹");

            //第五列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.81;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("备 注");

            builder.EndRow();
            #endregion

            foreach (DataRow dr in dt.Rows)
            {
                //第一列
                builder.InsertCell();// 添加一个单元格                    
                builder.CellFormat.Borders.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
                builder.CellFormat.Width = 5.7;
                builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
                builder.Font.Bold = dr["lev"].ToString() == "3" ? false : true;
                builder.Font.Size = 12;
                builder.Write(dr["title"].ToString());

                //第二列
                builder.InsertCell();// 添加一个单元格                    
                builder.CellFormat.Borders.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
                builder.CellFormat.Width = 2.49;
                builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
                builder.Font.Bold = true;
                builder.Font.Size = 12;
                builder.Write("");

                //第三列
                builder.InsertCell();// 添加一个单元格                    
                builder.CellFormat.Borders.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
                builder.CellFormat.Width = 2.49;
                builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
                builder.Font.Bold = true;
                builder.Font.Size = 12;
                builder.Write("");

                //第四列
                builder.InsertCell();// 添加一个单元格                    
                builder.CellFormat.Borders.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
                builder.CellFormat.Width = 2.49;
                builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
                builder.Font.Bold = true;
                builder.Font.Size = 12;
                builder.Write("");

                //第五列
                builder.InsertCell();// 添加一个单元格                    
                builder.CellFormat.Borders.LineStyle = LineStyle.Single;
                builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
                builder.CellFormat.Width = 2.81;
                builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
                builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
                builder.Font.Bold = true;
                builder.Font.Size = 12;
                builder.Write("");

                builder.EndRow();
            }

            #region 合计
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 5.7;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("合     计");

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("");

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("");

            //第四列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.49;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("");

            //第五列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.81;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = true;
            builder.Font.Size = 12;
            builder.Write("");

            builder.EndRow();
            #endregion
        }
    }

    private void BuilderPlayerTable(DocumentBuilder builder, DataTable dt)
    {
        #region 列头
        //第一列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 1.23;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("序号");

        //第二列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 1.8;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("姓名");

        //第三列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 1.51;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("年龄");

        //第四列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 1.9;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("职务");

        //第五列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.22;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("职称");

        //第六列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 2.76;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("专业");

        //第七列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 4.1;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("本项目中分工");

        builder.EndRow();
        #endregion

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.23;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write((i + 1).ToString());

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.8;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["UserName"].ToString());

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.51;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["age"].ToString());

            //第四列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.9;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["Position"].ToString());

            //第五列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.22;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["Qualification"].ToString());

            //第六列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.76;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["Major"].ToString());

            //第七列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 4.1;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["DivisionScope"].ToString());

            builder.EndRow();
        }
    }

    private void BuilderPlayerTable(DocumentBuilder builder)
    {
        for (int i = 0; i < 10; i++)
        {
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.23;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "序号" : "");

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.8;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "姓名" : "");

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.51;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "年龄" : "");

            //第四列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.9;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "职务" : "");

            //第五列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.22;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "职称" : "");

            //第六列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 2.76;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "专业" : "");

            //第七列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 4.1;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "本项目中分工" : "");

            builder.EndRow();
        }
    }

    private void BuilderPlanTable(DocumentBuilder builder, DataTable dt)
    {
        #region 插入列头
        //第一列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 1.27;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("序号");

        //第二列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 3.81;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("时间段");

        //第三列
        builder.InsertCell();// 添加一个单元格                    
        builder.CellFormat.Borders.LineStyle = LineStyle.Single;
        builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
        builder.CellFormat.Width = 10.71;
        builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
        builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
        builder.Font.Bold = true;
        builder.Font.Size = 12;
        builder.Write("内容");

        builder.EndRow();
        #endregion

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.27;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write((i + 1).ToString());

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 3.81;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["PlanStartDate"].ToString() == "" ? "" : dt.Rows[i]["PlanStartDate"].ToString() + "至" + dt.Rows[i]["PlanEndDate"].ToString());

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 10.71;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = false;
            builder.Font.Size = 12;
            builder.Write(dt.Rows[i]["PlanContent"].ToString());

            builder.EndRow();
        }
    }

    private void BuilderPlanTable(DocumentBuilder builder)
    {
        for (int i = 0; i < 10; i++)
        {
            //第一列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 1.27;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "序号" : "");

            //第二列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 3.81;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "时间段" : "");

            //第三列
            builder.InsertCell();// 添加一个单元格                    
            builder.CellFormat.Borders.LineStyle = LineStyle.Single;
            builder.CellFormat.Borders.Color = System.Drawing.Color.Black;
            builder.CellFormat.Width = 10.71;
            builder.CellFormat.VerticalAlignment = CellVerticalAlignment.Center;//垂直居中对齐
            builder.ParagraphFormat.Alignment = ParagraphAlignment.Center;//水平居中对齐
            builder.Font.Bold = i == 0 ? true : false;
            builder.Font.Size = 12;
            builder.Write(i == 0 ? "内容" : "");

            builder.EndRow();
        }
    }
    #endregion

}
