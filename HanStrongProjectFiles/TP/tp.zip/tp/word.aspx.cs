﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;

public partial class office_word : System.Web.UI.Page
{
    private string act = "";  //拟稿edit, 审核过程check, 签发sign, 给号allotbh, 套红redhead, 盖章stamp, 分发issue, 查看view
    private string wfid = "", doctitle = "";
    private bool signed = false, Isalloted = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        act = Request["act"];
        wfid = Request["wfid"];
        if (act == null) act = "";
        if (wfid == null) wfid = "";
    }

    public string GetFromURL() {
        try {
            return Request.UrlReferrer.PathAndQuery;
        } catch {
            return "";
        }
    }

    public string GetAction() {
        return act;
    }

    public string OutFlowbarHTML() {
        if (wfid == "") {
            if (doctitle == "") {
                return "<div id=\"_fwtl\" style=\"display:none;\">" + doctitle + "</div>";
            } else {
                return "<div id=\"_fwtl\">" + doctitle + "</div>";
            }
        } else {
            return "<div id=\"_fwtb\"></div><div id=\"_fwtl\">" + doctitle + "</div>";
        }
    }

    public string GetLoginUserName() {
        try {
            return Session["uname"].ToString();
        } catch {
            Response.Write("由于您长时间没有任何操作，为保护文档安全系统自动关闭您的连接");
            Response.End();
            return "";
        }
    }
}