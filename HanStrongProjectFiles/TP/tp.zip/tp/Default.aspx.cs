﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

    public partial class Default : System.Web.UI.Page
    {
        string FileURL = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["filepath"] != null)
            {
                string FileRowid = Request.QueryString["rowid"].ToString();
                DataTable dt;
                dt = DBHelper.GetDataTableBySql("select top 1 [filename] from Base_FileList where objid='" + FileRowid + "' ");
                FileURL = dt.Rows[0][0].ToString();
                
                FileURL =FileURL.Substring(0, FileURL.LastIndexOf(".")) + ".swf";
               // Response.Write("<script>alert('"+ Server.UrlDecode(FileURL)+"');</script>");
                //Response.Write("<script>alert('"+FileURL+"');</script>");
				//if (File.Exists( "\\\\10.165.3.102\\信息平台\\ria\\uploadfile\\SwfFile\\"+FileURL.ToLower()))
                if (File.Exists("\\\\10.165.3.98\\信息平台\\ria\\uploadfile\\SwfFile\\" + FileRowid + "\\" + FileURL.ToLower()))
				{
					//Response.Write("<script>alert('"+FileURL+"');</script>");
				  //ASPxObjectContainer1.ObjectUrl = "~/uploadfile/SwfFile/"+FileURL.ToLower();
                    ASPxObjectContainer1.ObjectUrl = "~/uploadfile/SwfFile/" + FileRowid + "/" + FileURL.ToLower();
				}
				else
				{
			     ASPxObjectContainer1.ObjectUrl = "~/uploadfile/SwfFile/error.swf";
				}
               
            }
        }
        
        
    }

