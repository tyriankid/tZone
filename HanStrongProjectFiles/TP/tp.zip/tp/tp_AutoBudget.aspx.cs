﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class tp_AutoBudget : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string cmd = Request["cmd"].ToString();
            if (cmd != "")
            {
                Response.Write(AutoCalculate(Request["objid"].ToString()) + "<-->");
            }
        }
        private string AutoCalculate(string objid)
        {
              DataTable dt1;
              DataTable dttemp;
            string sqlcmd = "",pold="",sqls="",rtn="";
            List<string> sqllist = new List<string>();
            sqlcmd = "SELECT a.*,b.rowid itemid,b.prowid,b.lev  FROM TP_Prj_Appropriation_Budget a LEFT JOIN TP_Prj_Budget_info b ON a.coursetitle=b.title WHERE objid='"+ objid +"'  ORDER BY b.lev desc,prowid";
            dt1 = DBHelper.GetDataTableBySql(sqlcmd);
              for (int i = 0; i < dt1.Rows.Count;i++ )
            {
            /*
                if (pold != dt1.Rows[i]["prowid"].ToString())
                {
                    sqllist.Add("update TP_Prj_Appropriation_Budget set totalmoney=0.00000,subsidizemoney=0.00000,selfmoney=0.00000 from TP_Prj_Appropriation_Budget a,TP_Prj_Budget_info b where a.coursetitle=b.title and b.rowid='" + dt1.Rows[i]["prowid"].ToString() + "' and a.objid='"+ Request["objid"].ToString() +"' ");
					//sqls+="update TP_Prj_Appropriation_Budget set totalmoney=0.00000,subsidizemoney=0.00000,selfmoney=0.00000 from TP_Prj_Appropriation_Budget a,TP_Prj_Budget_info b where a.coursetitle=b.title and b.rowid='" + dt1.Rows[i]["prowid"].ToString() + "' ";
                }
				 
                    sqlcmd = "update TP_Prj_Appropriation_Budget set totalmoney=totalmoney+" + dt1.Rows[i]["totalmoney"] + ", ";
                    sqlcmd+=" subsidizemoney=subsidizemoney+" + dt1.Rows[i]["subsidizemoney"] + " ,";
                    sqlcmd+=" selfmoney=selfmoney+" + dt1.Rows[i]["selfmoney"] + " from TP_Prj_Appropriation_Budget a,TP_Prj_Budget_info b where a.coursetitle=b.title and b.rowid='" + dt1.Rows[i]["prowid"].ToString() + "' and a.objid='"+ Request["objid"].ToString() +"' ";
                    sqllist.Add(sqlcmd);
                   // sqls+=sqlcmd;
                rtn = DBHelper.ExecuteSqlTrans(sqllist.ToArray());
                sqls+=rtn;
                pold = dt1.Rows[i]["prowid"].ToString();         
                sqllist.Clear();
                */
                sqlcmd="SELECT a.*,b.rowid itemid,b.prowid,b.lev  FROM TP_Prj_Appropriation_Budget a LEFT JOIN TP_Prj_Budget_info b ON a.coursetitle=b.title WHERE objid='"+ objid +"' and b.prowid='"+ dt1.Rows[i]["itemid"] +"'  ORDER BY b.lev desc,prowid";
                dttemp=DBHelper.GetDataTableBySql(sqlcmd);
                if (dttemp.Rows.Count>1)
                {
					sqlcmd="update TP_Prj_Appropriation_Budget set totalmoney=aaa,SubsidizeMoney=bbb,SelfMoney=ccc from (select sum(TotalMoney)aaa,SUM(SubsidizeMoney)bbb,SUM(SelfMoney)ccc from TP_Prj_Appropriation_Budget a left join TP_Prj_Budget_info b ON a.coursetitle=b.title where a.objid='"+ Request["objid"].ToString() +"' and b.prowid='"+ dt1.Rows[i]["itemid"] +"' )T WHERE rowid='"+ dt1.Rows[i]["rowid"] +"'";
					sqllist.Add(sqlcmd);
                }
            }
           // sqllist.Clear();
            sqllist.Add("update "+ Request["tbl"].ToString() +" set PrjMoney=aaa,SubsidizeMoney=bbb,SelfMoney=ccc from (select sum(TotalMoney)aaa,SUM(SubsidizeMoney)bbb,SUM(SelfMoney)ccc from TP_Prj_Appropriation_Budget a left join TP_Prj_Budget_info b ON a.coursetitle=b.title where a.objid='"+ Request["objid"].ToString() +"' and b.lev=1 )T WHERE rowid='"+ Request["objid"].ToString() +"'");
            rtn = DBHelper.ExecuteSqlTrans(sqllist.ToArray());
            sqls+=rtn;
           // Response.Write(sqls);
            return sqls;
            
        }
            
        
    }
