﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.IO;

public partial class office_read : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e) {
        DataTable dt = null;
        byte[] fbytes = null;
        try {            
            string sql = "";
            switch (Request["type"])
            {
                case "apply":
                    sql = "SELECT ReportFilePath FROM TP_Prj_BaseInfo WHERE rowid = '" + Request["docid"] + "'";
                    break;
                case "plan":
                    sql = "SELECT ReportFilePath FROM TP_Prj_Planning_Info WHERE rowid = '" + Request["docid"] + "'";
                    break;
                case "end":
                    sql = "SELECT ReportFilePath FROM TP_Prj_Termination WHERE rowid = '" + Request["docid"] + "'";
                    break;
                case "Type3Acceptance":
                    sql = "SELECT ReportFilePath FROM TP_Prj_results_acceptance WHERE rowid = '" + Request["docid"] + "'";
                    break;
                case "Type2FinalAcceptance":
                    sql = "SELECT ReportFilePath FROM TP_Prj_Final_Acceptance WHERE rowid = '" + Request["docid"] + "'";
                    break;
                default:
                    break;
            }
            
            dt = DBHelper.GetDataTableBySql(sql);
            string filepath = Server.MapPath("../../uploadfile/") + dt.Rows[0][0].ToString();
            fbytes = File.ReadAllBytes(filepath);

            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AddHeader("Content-Disposition", "inline;filename=view.doc");
            Response.BinaryWrite(fbytes);
            Response.End();
        } catch {

        } finally {
            fbytes = null;
        }
    }
}